package javax.xml.stream.XMLStreamWriterTest;

import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.XMLOutputFactory;
import java.io.StringWriter;

/**
 * See 6391922.
 * 
 * @author Kohsuke Kawaguchi
 */
public class NullUriDetectionTest extends Base {
    public void test1() throws Exception {
        xof.setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES,Boolean.TRUE);

        StringWriter sw = new StringWriter();
        XMLStreamWriter w = xof.createXMLStreamWriter(sw);
        w.writeStartDocument();
        w.writeStartElement("foo","bar","zot");
        w.writeDefaultNamespace(null);
        w.writeCharacters("---");
    }
}
