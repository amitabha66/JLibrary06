/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:23:28 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4991939;

import javax.xml.XMLConstants;
import javax.xml.namespace.QName;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    public void testXPath13() throws Exception {
        QName qname = new QName( XMLConstants.XML_NS_URI , "" );
        
        XPathFactory xpathFactory = XPathFactory.newInstance();
        assertNotNull(xpathFactory);
        
        XPath xpath = xpathFactory.newXPath();
        assertNotNull(xpath);
        
        try {
            xpath.evaluate("1+1",(Object)null,qname);
            fail("failed , expected IAE not thrown");
        } catch( IllegalArgumentException e ) {
            ; // as expected
        }
    }
}