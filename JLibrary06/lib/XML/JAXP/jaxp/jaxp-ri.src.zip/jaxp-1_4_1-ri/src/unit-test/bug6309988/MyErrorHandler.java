/*
 * MyErrorHandler.java
 *
 * Created on October 26, 2005, 10:52 AM
 * 
 */

package bug6309988;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.ErrorHandler;

/**
 *
 * @author Sunitha Reddy
 */
public class MyErrorHandler extends DefaultHandler {
    
    public boolean errorOccured=false;

    public void error (SAXParseException e)
        throws SAXException {
        
        System.err.println(
                "Error: "
                + "[[" + e.getPublicId() + "]"
                + "[" + e.getSystemId() + "]]"
                + "[[" + e.getLineNumber() + "]"
                + "[" + e.getColumnNumber() + "]] "
                + e);
        
        errorOccured = true;
    }
    
    public void fatalError (SAXParseException e)
        throws SAXException {
        
        System.err.println("Fatal Error: " + e);
        
        errorOccured=true;
    }


    public void warning (SAXParseException e)
        throws SAXException {
        
        System.err.println("Warning: " + e);
        
        errorOccured=true;
    }
}
