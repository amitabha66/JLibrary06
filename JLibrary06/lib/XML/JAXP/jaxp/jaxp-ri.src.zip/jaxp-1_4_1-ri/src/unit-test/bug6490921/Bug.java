/*
 * Bug.java
 *
 * used on November 6, 2006, 2:24 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6490921;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.stream.StreamResult;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import junit.framework.Assert;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
    
    public static class ReaderStub extends XMLFilterImpl {
        static boolean used = false;
        
        public ReaderStub() throws ParserConfigurationException, SAXException {
            super();
            super.setParent(SAXParserFactory.newInstance().newSAXParser().getXMLReader());
        }
        
        public void parse(InputSource input)
            throws SAXException, IOException {
            used = true;
            super.parse(input);
        }
                
        public void parse(String systemId)
            throws SAXException, IOException {
            used = true;
            super.parse(systemId);
        }        
    }
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    public void test01() {
        String xml = "<?xml version='1.0'?><root/>";
        ReaderStub.used = false;
        
        // Don't set 'org.xml.sax.driver' here, just use default        
        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            InputSource in = new InputSource(new StringReader(xml));
            SAXSource source = new SAXSource(in);
            StreamResult result = new StreamResult(new StringWriter());
            transformer.transform(source, result);
            Assert.assertTrue(!printWasReaderStubCreated());
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }
    
    public void test02() {
        String xml = "<?xml version='1.0'?><root/>";
        ReaderStub.used = false;
        
        System.setProperty("org.xml.sax.driver", ReaderStub.class.getName());
        
        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            InputSource in = new InputSource(new StringReader(xml));
            SAXSource source = new SAXSource(in);
            StreamResult result = new StreamResult(new StringWriter());
            transformer.transform(source, result);
            Assert.assertTrue(printWasReaderStubCreated());
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
    }
    
    public void test03() {
        String xsl = "<?xml version='1.0'?>\n"
                + "<xsl:stylesheet"
                + " xmlns:xsl='http://www.w3.org/1999/XSL/Transform'"
                + " version='1.0'>\n"
                + "   <xsl:template match='/'>Hello World!</xsl:template>\n"
                + "</xsl:stylesheet>\n";
        
        ReaderStub.used = false;
        
        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            if (transFactory.getFeature(SAXTransformerFactory.FEATURE) == false) {
                System.out.println("SAXTransformerFactory not supported");
            }
            InputSource in = new InputSource(new StringReader(xsl));
            SAXSource source = new SAXSource(in);
            
            transFactory.newTransformer(source);
            Assert.assertTrue(printWasReaderStubCreated());
        } catch (TransformerException e) {
            fail(e.getMessage());
        }
    }
    
    private static boolean printWasReaderStubCreated() {
        if (ReaderStub.used) {
            System.out.println("\tReaderStub is used.");
            return ReaderStub.used;
        } else {
            System.out.println("\tReaderStub is not used.");
            return ReaderStub.used;
        }
    }
}
