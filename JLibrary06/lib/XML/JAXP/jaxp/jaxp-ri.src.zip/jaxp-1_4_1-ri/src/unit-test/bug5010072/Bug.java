/*
 * @(#)$Id: Bug.java,v 1.2 2006/02/17 03:51:27 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug5010072;

import javax.xml.validation.SchemaFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    protected static class ErrorHandler extends DefaultHandler {
        public int errorCounter = 0;

        public void error(SAXParseException e) throws SAXException {
            
            System.err.println(
                    "Error: "
                    + "[[" + e.getPublicId() + "][" + e.getSystemId() + "]]"
                    + "[[" + e.getLineNumber() + "][" + e.getColumnNumber() + "]]"
                    + e);
            
            errorCounter++;
            
            throw e;
        }

        public void fatalError(SAXParseException e) throws SAXException {
            System.err.println("Fatal Error: " + e);
            errorCounter++;
        }
    }

    public void test1() throws Exception {
        SchemaFactory schemaFactory =
                SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");

        ErrorHandler errorHandler = new ErrorHandler();
        schemaFactory.setErrorHandler(errorHandler);

        try {
            schemaFactory.newSchema(Bug.class.getResource("test.xsd"));
            fail("should fail to compile");
        } catch( SAXException e ) {
            ; // as expected
        }
    }
}