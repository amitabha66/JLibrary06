
package bug6489502;

import java.io.File;
import javax.xml.stream.*;

import junit.framework.TestCase;
import junit.framework.Assert;
import junit.textui.TestRunner;

import java.io.FileWriter;

/**
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {
    
    public java.io.File input;
    public final String filesDir = "./";
    protected XMLInputFactory inputFactory = XMLInputFactory.newInstance();
    protected XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();
    
    private static String xml = "<?xml version=\"1.0\"?><PLAY><TITLE>The Tragedy of Hamlet, Prince of Denmark</TITLE></PLAY>";

    public static void main(String [] args) {
        TestRunner.run(Test.class);
    }
    
    public void testEventReader1() {
        try {
            // Check if event reader returns the correct event
            XMLEventReader e1 =
                    inputFactory.createXMLEventReader(
                        inputFactory.createXMLStreamReader(new java.io.StringReader(xml)));       
            Assert.assertEquals(e1.peek().getEventType(), 
                                XMLStreamConstants.START_DOCUMENT);
            
            // Repeat same steps to test factory state
            XMLEventReader e2 =
                    inputFactory.createXMLEventReader(
                        inputFactory.createXMLStreamReader(new java.io.StringReader(xml)));            
            Assert.assertEquals(e2.peek().getEventType(), 
                                XMLStreamConstants.START_DOCUMENT);  
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }    
    
    public void testEventReader2() {
        try {
            // Now advance underlying reader and then call peek on event reader
            XMLStreamReader s1 = 
                    inputFactory.createXMLStreamReader(new java.io.StringReader(xml));
            Assert.assertEquals(s1.getEventType(), 
                                XMLStreamConstants.START_DOCUMENT);
            s1.next(); s1.next();    // advance to <TITLE>
            Assert.assertTrue(s1.getLocalName().equals("TITLE"));
            
            XMLEventReader e3 = inputFactory.createXMLEventReader(s1);
            Assert.assertEquals(e3.peek().getEventType(), 
                                XMLStreamConstants.START_ELEMENT);     
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }        
}
