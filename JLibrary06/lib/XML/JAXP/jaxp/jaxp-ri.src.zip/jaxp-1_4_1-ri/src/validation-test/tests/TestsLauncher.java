/*
 * @(#)$Id: TestsLauncher.java,v 1.1 2005/06/10 04:24:00 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package tests;

import java.io.File;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * JUnit test launcher. 
 * 
 * <p>
 * Since JAXP RI unit tests need a rather complicated bootstrap
 * classpath setting, Ant 1.5.x cannot launch JUnit tests.
 * 
 * That's why we have this launcher.
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class TestsLauncher {
    public static void main(String[] args) {
        TestSuite ts = new TestSuite();
        for( int i=0; i<args.length; i++ )
            ts.addTest(collectTests(new File(args[i]),""));
        TestRunner.run(ts);
    }

    private static Test collectTests(File dir, String packageName) {
        TestSuite ts = new TestSuite();
        File[] children = dir.listFiles();
        for( int i=0; i<children.length; i++ ) {
            File child = children[i];
            
            if( child.isDirectory() ) {
                ts.addTest(collectTests(child,append(packageName,child.getName())));
            }
            if( child.getName().endsWith("Test.class") ) {
                String className = child.getName();
                className = className.substring(0, className.length()-6 );
                className = append(packageName,className);
                try {
                    Object o = Class.forName(className).newInstance();
                    if( o instanceof Test )
                        ts.addTest( (Test)o );
                } catch( Exception e ) {
                    System.out.println("failed to load "+className); 
                }
            }
        }
        return ts;
    }

    /**
     * Combines the package name with a class name.
     */
    private static String append(String packageName, String className) {
        if( packageName.equals("") )
            return className;
        else
            return packageName+'.'+className;
    }
}
