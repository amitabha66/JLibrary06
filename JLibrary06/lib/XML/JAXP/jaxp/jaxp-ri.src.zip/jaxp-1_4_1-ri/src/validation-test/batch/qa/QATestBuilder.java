/*
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package batch.qa;

import java.io.File;

import batch.core.JAXPTest;
import batch.core.TestBuilder;
import batch.util.ConfigFailureTest;

/**
 * JUnit {@link Test} builder for ECMAScript-based test cases
 * (those tests that use testspec.meta files)
 * 
 * Call the build method to build tests.
 * 
 * @author
 * 	Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class QATestBuilder implements TestBuilder {
    public JAXPTest createTest(File testSpecFile) {
        try {
            return createTest( new QATestDescriptor(testSpecFile) );
        } catch( Exception e ) {
            return new ConfigFailureTest(testSpecFile,e);
        }
    }

    /**
     * 
     * <p>
     * Chance for a derived class to change the test case class.
     */
    protected JAXPTest createTest(QATestDescriptor descriptor) {
        return new QATestCase(descriptor);
    }
}
