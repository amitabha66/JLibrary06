package javax.xml.transform;

import junit.framework.TestCase;

import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;

import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import junit.textui.TestRunner;

/**
 * <p>Test {@link javax.xml.transform.Transformer} for
 * CR 6401137:
 * 6401137 Null Pointer Exception in Java 1.5
 * </p>
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 * @see http://issues.apache.org/jira/browse/XALANJ-2108
 */
public class CR6401137Test extends TestCase {

    public static void main(String [] args){
        TestRunner.run(CR6401137Test.class);
    }
    
    /**
     * <p>Inspired by:
     * 6401137 Null Pointer Exception in Java 1.5.</p>
     *
     * @throws TransformerException If error during transformation.
     *
     * @see http://issues.apache.org/jira/browse/XALANJ-2108
     */
    public final void testTransform() {

        try {
            String str = new String();
            ByteArrayOutputStream  byte_stream = new ByteArrayOutputStream();
            File inputFile = new File("./jaxp-ri/src/unit-test/javax/xml/transform/CR6401137.xml");
            FileReader in = new FileReader(inputFile);
            int c;

            while ((c = in.read()) != -1) {
                str = str + new Character((char)c).toString();
            }

            in.close();

            System.out.println(str);
            byte buf[]= str.getBytes();
            byte_stream.write(buf);
            String style_sheet_uri ="./jaxp-ri/src/unit-test/javax/xml/transform/CR6401137.xsl";
            byte[] xml_byte_array = byte_stream.toByteArray();
            InputStream xml_input_stream = new ByteArrayInputStream(xml_byte_array);

            Source xml_source = new StreamSource(xml_input_stream);

            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();
            StreamSource source = new StreamSource(style_sheet_uri);
            transformer = tFactory.newTransformer(source);

            ByteArrayOutputStream result_output_stream = new ByteArrayOutputStream();
            Result result = new StreamResult(result_output_stream);
            transformer.transform(xml_source, result);
            result_output_stream.close();

            // expected success
        } catch (Exception e) {
            // unexpected failure
            e.printStackTrace();
            fail(e.toString());
        }
    }
}
