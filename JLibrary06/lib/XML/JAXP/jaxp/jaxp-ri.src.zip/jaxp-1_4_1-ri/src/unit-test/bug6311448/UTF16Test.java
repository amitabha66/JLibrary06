/*
 * Bug.java
 *
 * used on November 6, 2006, 2:24 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6311448;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.StringWriter;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class UTF16Test extends TestCase {
    
    public UTF16Test(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(UTF16Test.class);
    }
    
    public void test01() {
        try {
            String attrKey = "key";
            String attrValue = "\ud800\udc00";    // 17-bit code point in UTF-16
            
            // Some obvious assertions for documentation purposes
            assertTrue(Character.isSurrogatePair('\ud800', '\udc00'));
            assertTrue(Character.toCodePoint('\ud800', '\udc00') == 65536);
            assertTrue(Character.charCount(Character.toCodePoint('\ud800', '\udc00')) == 2);
            
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            Transformer t = TransformerFactory.newInstance().newTransformer();
            
            // Create a DOM with 'attrValue' in it
            Document doc = dbf.newDocumentBuilder()
                    .getDOMImplementation()
                    .createDocument(null, null, null);            
            Element xmlRoot =  doc.createElement("root");
            xmlRoot.setAttribute(attrKey, attrValue);
            doc.appendChild(xmlRoot);
                        
            // Serialize DOM into a byte array
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            t.setOutputProperty("encoding", "utf-8");
            t.transform(new DOMSource(doc), new StreamResult(baos));
            
            // Re-parse byte array back into a DOM
            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            doc = dbf.newDocumentBuilder().parse(bais);
            String newValue = doc.getDocumentElement().getAttribute(attrKey);
            assertTrue(newValue.charAt(0) == '\ud800' &&
                       newValue.charAt(1) == '\udc00');
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }        
    }
    
}
