/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: ValidatorTest.java,v 1.3 2006/07/25 22:58:54 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.validation;

import javax.xml.XMLConstants;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stax.StAXResult;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.ErrorHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;

/**
 * Tests validate(...) method of Validator.
 *
 * @author Sunitha Reddy
 * @author <a href="mailto:Jeff.Suttor@Sun.com>Jeff Suttor</a>
 */
public class ValidatorTest extends TestCase {

    /**
     * Creates a new instance of ValidatorTest.
     *
     * @param name Name of test.
     */
    public ValidatorTest(String name) {
        super(name);
    }

    /**
     * Main method to run from command line.
     *
     * @param args Standard command line args.
     */
    public static void main(String[] args) {
        TestRunner.run(ValidatorTest.class);
    }

    /**
     * Validate a StAX source/result.
     */
    public void testValidateStAX() {

        File resultFile = null;
        try {
            resultFile = new File("stax.result");
            if (resultFile.exists()) {
                resultFile.delete();
            }

            Result xmlResult = new javax.xml.transform.stax.StAXResult(
                    XMLOutputFactory.newInstance().createXMLStreamWriter(
                        new FileWriter(resultFile)));
            Source xmlSource = new javax.xml.transform.stax.StAXSource(
                    getXMLEventReader("toys.xml"));
            validate("toys.xsd", xmlSource, xmlResult);

            ((StAXResult) xmlResult).getXMLStreamWriter().close();
            assertTrue("result file is not created", resultFile.exists());

       } catch (Exception ex) {
           ex.printStackTrace();
           fail("Exception : " + ex.getMessage());
       } finally {
           if (resultFile != null && resultFile.exists()) {
               resultFile.delete();
           }
       }
   }

    /**
     * Test validating a Stream.
     */
    public void testValidateStream() {

        File resultFile = null;
        try {
            resultFile = new File("stax.result");
            if (resultFile.exists()) {
                resultFile.delete();
            }

            // Validate this instance document against the
            // Instance document supplied
            Result xmlResult = new javax.xml.transform.stream.StreamResult(
                    resultFile);
            Source xmlSource = new javax.xml.transform.stream.StreamSource(
                    new File(ValidatorTest.class.getResource(
                        "toys.xml").toURI()));

            validate("toys.xsd", xmlSource, xmlResult);
            assertTrue("result file is not created", resultFile.exists());
        } catch (Exception ex) {
           ex.printStackTrace();
           fail("Exception : " + ex.getMessage());
       } finally {
           if (resultFile != null && resultFile.exists()) {
               resultFile.delete();
           }
       }
    }

    /**
     * Test validating valid/invalid xs:gMonth's.
     */
    public void testValidateGMonth() {

        // test valid gMonths
        File resultFile = null;
        try {
            resultFile = new File("gMonths.result.xml");
            if (resultFile.exists()) {
                resultFile.delete();
            }

            // Validate this instance document against the
            // Instance document supplied
            Result xmlResult = new javax.xml.transform.stream.StreamResult(
                    resultFile);
            Source xmlSource = new javax.xml.transform.stream.StreamSource(
                    new File(ValidatorTest.class.getResource(
                        "gMonths.xml").toURI()));

            validate("gMonths.xsd", xmlSource, xmlResult);

            assertTrue(
                    "result file is not created",
                    resultFile.exists());
        } catch (Exception ex) {
           ex.printStackTrace();
           fail("Exception : " + ex.getMessage());
       } finally {
           if (resultFile != null && resultFile.exists()) {
               resultFile.delete();
           }
       }

       // test invalid gMonths
        File invalidResultFile = null;
        try {
            invalidResultFile = new File("gMonths-invalid.result.xml");
            if (invalidResultFile.exists()) {
                invalidResultFile.delete();
            }

            // Validate this instance document against the
            // Instance document supplied
            Result xmlResult = new javax.xml.transform.stream.StreamResult(
                    resultFile);
            Source xmlSource = new javax.xml.transform.stream.StreamSource(
                    new File(ValidatorTest.class.getResource(
                        "gMonths-invalid.xml").toURI()));

            validate("gMonths.xsd", xmlSource, xmlResult);

            // should have failed with an Exception due to invalid gMonths
            fail("invalid gMonths were accepted as valid in "
                    + ValidatorTest.class.getResource(
                        "gMonths-invalid.xml").toURI());
        } catch (Exception ex) {
            // expected failure
            System.out.println("Expected failure: " + ex.toString());
       } finally {
           if (invalidResultFile != null && invalidResultFile.exists()) {
               invalidResultFile.delete();
           }
       }
    }

    /**
     * Validate the f]given src against xsdFile producing result.
     *
     * @param xsdFile XSD to validate against.
     * @param src Source to validate
     * @param result Result of validation.
     *
     * @throws Exception If error processing source.
     */
    private void validate(
            final String xsdFile,
            final Source src,
            final Result result)
        throws Exception {
        try {
            SchemaFactory sf = SchemaFactory.newInstance(
                    XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = sf.newSchema(
                    new File(ValidatorTest.class.getResource(xsdFile).toURI()));

            // Get a Validator which can be used to validate instance document
            // against this grammar.
            Validator validator = schema.newValidator();
            ErrorHandler eh = new ErrorHandlerImpl();
            validator.setErrorHandler(eh);

            // Validate this instance document against the
            // Instance document supplied
            validator.validate(src, result);
        } catch (Exception ex) {
            throw ex;
        }
    }

    /**
     * Get the XMLEventReader for a given file.
     *
     * @param filename Filename to create reader for.
     *
     * @return XMLEventReader for given filename.
     */
    private XMLEventReader getXMLEventReader(final String filename) {

        XMLInputFactory xmlif = null;
        XMLEventReader xmlr = null;
        try {
            xmlif = XMLInputFactory.newInstance();
            xmlif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,
                    Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,
                    Boolean.FALSE);
            xmlif.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);

            //FileInputStream fis = new FileInputStream(filename);
            FileInputStream fis = new FileInputStream(
                    new File(
                        ValidatorTest.class.getResource(filename).toURI()));
            xmlr =  xmlif.createXMLEventReader(filename, fis);
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Exception : " + ex.getMessage());
        }
        return xmlr;
    }
}
