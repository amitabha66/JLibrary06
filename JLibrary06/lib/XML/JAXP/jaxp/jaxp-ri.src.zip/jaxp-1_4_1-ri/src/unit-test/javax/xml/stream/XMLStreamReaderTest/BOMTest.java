/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: BOMTest.java,v 1.1 2006/07/17 23:03:10 lindstro Exp $
 * %W% %E%
 *
 * Copyright 2006 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.stream.XMLStreamReaderTest;

/**
 * This test case was initiated by CR 6218794 (Support for Byte Order Mark)
 *
 * @author Jeff Suttor
 * @author Ana Lindstrom-Tamer
 */
import java.io.*;
import java.util.Iterator;
import javax.xml.stream.*;
import javax.xml.stream.events.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;



public class BOMTest extends TestCase {
    
    // UTF-8 BOM test file
    private static final String INPUT_FILE1 = "UTF8-BOM.xml";
    
    // UTF-16 Big Endian test file
    private static final String INPUT_FILE2 = "UTF16-BE.wsdl";

    
    /** Creates a new instance of Bug */
    public BOMTest(String name) {
         super(name);
    }   
    
    public static void main(String[] args) {
    	TestRunner.run(BOMTest.class);
    }
    
    public void testBOM(){
        
        XMLInputFactory ifac = XMLInputFactory.newInstance();
        
 
        try{
               
            XMLStreamReader re = ifac.createXMLStreamReader(this.getClass().getResource(INPUT_FILE1).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE1));
                        
            while (re.hasNext()){
		int event = re.next();
	    }
 

            XMLStreamReader re2 = ifac.createXMLStreamReader(this.getClass().getResource(INPUT_FILE2).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE2));
                        
            while (re2.hasNext()){
		int event = re2.next();
	    }
 
  

        } catch(Exception e) {
            e.printStackTrace();
            fail("Exception occured: " + e.getMessage());
        }
 
    }    
}
