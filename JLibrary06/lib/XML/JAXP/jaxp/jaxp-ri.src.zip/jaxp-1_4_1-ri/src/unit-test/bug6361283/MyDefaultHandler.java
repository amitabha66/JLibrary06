/*
 * MyDefaultHandler.java
 *
 * Created on December 9, 2005, 7:19 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6361283;

/**
 *
 * @author Sunitha Reddy
 */
    
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.xml.sax.ext.*;

/**
 *
 * @author Sunitha Reddy
 */
public class MyDefaultHandler extends DefaultHandler{
    
    private Locator myLocator = null;
    String xmlVersion = "";
    
    public void setDocumentLocator(Locator locator){
            myLocator = locator;
    }

    public void startElement(String uri,String localName,String qName,Attributes attributes){
        try{
            xmlVersion = ((Locator2)myLocator).getXMLVersion();
        }catch(Exception e){   
        }
    }
    
}
