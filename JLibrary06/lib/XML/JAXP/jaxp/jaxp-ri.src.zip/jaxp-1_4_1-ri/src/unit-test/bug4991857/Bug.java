/*
 * @(#)$Id: Bug.java,v 1.4 2007/01/12 19:27:27 spericas Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 */
package bug4991857;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
    
    Document d = null;
            
    XPathFactory xpathFactory = XPathFactory.newInstance();
            
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    public void testXPath09() throws Exception {
        try {
            XPath xpath = xpathFactory.newXPath();
            assertNotNull(xpath);
        
            Double result = (Double)xpath.evaluate(
                    "1+2", d, XPathConstants.NUMBER);
        } 
        catch (XPathExpressionException _) {
            fail("Unexpected XPathExpressionException thrown");
        }
    }
    
    public void testXPath10() throws Exception {
        try {
            XPath xpath = xpathFactory.newXPath();
            assertNotNull(xpath);
            
            xpath.evaluate(".", d, XPathConstants.STRING);
            fail("XPathExpressionException not thrown");
        } 
        catch (XPathExpressionException e) {
            // Expected exception as context node is null            
        }
    }
    
    public void testXPath11() throws Exception {
        try {
            Document d = null;
            
            XPathFactory xpathFactory = XPathFactory.newInstance();
            assertNotNull(xpathFactory);
            
            XPath xpath = xpathFactory.newXPath();
            assertNotNull(xpath);
            
            String quantity = (String)xpath.evaluate(
                    "/widgets/widget[@name='a']/@quantity", d, XPathConstants.STRING);
            fail("XPathExpressionException not thrown");
        } 
        catch (XPathExpressionException e) {
            // Expected exception as context node is null          
        }
    }
}