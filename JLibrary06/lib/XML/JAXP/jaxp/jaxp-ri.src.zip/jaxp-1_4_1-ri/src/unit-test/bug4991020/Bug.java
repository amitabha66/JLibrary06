/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:24:40 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4991020;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    protected static SAXParser createParser() throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        spf.setValidating(true);
        SAXParser parser = spf.newSAXParser();
        parser.setProperty(
                "http://java.sun.com/xml/jaxp/properties/schemaLanguage",
        "http://www.w3.org/2001/XMLSchema");

        return parser;
    }

    public void test1() throws Exception {
        SAXParser parser = createParser();
        parser.parse(
                Bug.class.getResource("test.xml").toExternalForm(),
                new util.DraconianErrorHandler());
    }
}