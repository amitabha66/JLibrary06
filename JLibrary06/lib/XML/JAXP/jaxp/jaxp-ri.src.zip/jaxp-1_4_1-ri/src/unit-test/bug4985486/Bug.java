/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:23:56 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4985486;

import javax.xml.parsers.SAXParserFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    public void test1() throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        System.out.println(spf.getClass().getName());
        spf.setNamespaceAware(true);
        spf.newSAXParser().parse(Bug.class.getResourceAsStream("test.xml"),new Handler());
    }
    
    private class Handler extends DefaultHandler {
        StringBuffer buf = new StringBuffer();
        
        public void characters(char[] ch, int start, int length) throws SAXException {
            buf.append(ch,start,length);
        }

        public void endDocument() throws SAXException {
            String contents = buf.toString();
            assertTrue( contents.endsWith("[END]") );
            while(contents.length()>=10) {
                assertTrue( contents.startsWith("0123456789") );
                contents = contents.substring(10);
            }
        }

    }
}