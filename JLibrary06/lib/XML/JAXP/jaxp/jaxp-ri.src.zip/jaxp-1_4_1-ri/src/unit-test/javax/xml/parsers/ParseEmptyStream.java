package javax.xml.parsers;

import java.io.StringReader;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author  Santiago.PericasGeertsen@sun.com
 */
public class ParseEmptyStream extends TestCase {
    
    SAXParserFactory factory = null;
    
    public ParseEmptyStream(String name) {
        super(name);
        
        try {            
            factory = SAXParserFactory.newInstance();
            factory.setNamespaceAware(true);
        }
        catch (Exception ex) {
            fail(ex.getMessage());
        }            
    }
    
    public void testEmptyStream() {        
        try {            
            SAXParser parser = factory.newSAXParser();
            InputSource source = new InputSource(new StringReader(""));
            parser.parse(source, new MyHandler());
            fail("Inputstream without document element accepted");
        }
        catch (Exception ex) {
            System.out.println("Exception thrown: " + ex.getMessage());
            // Premature end of file exception expected
        }
    }
    
    public void testXmlDeclOnly() {        
        try {            
            SAXParser parser = factory.newSAXParser();
            InputSource source = new InputSource(new StringReader("<?xml version='1.0' encoding='utf-8'?>"));
            parser.parse(source, new MyHandler());
            fail("Inputstream without document element accepted");
        }
        catch (Exception ex) {
            System.out.println("Exception thrown: " + ex.getMessage());
            // Premature end of file exception expected 
        }            
    }
    
    static class MyHandler extends DefaultHandler {
        public void startDocument() {
            System.out.println("Start document called");
        }
        public void endDocument() {
            System.out.println("End document called");
        }
    }
    
    public static void main(String [] args){
        TestRunner.run(ParseEmptyStream.class);
    }    
}
