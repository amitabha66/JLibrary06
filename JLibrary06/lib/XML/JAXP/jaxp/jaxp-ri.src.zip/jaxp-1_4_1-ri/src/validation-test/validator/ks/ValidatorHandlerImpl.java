/*
 * @(#)$Id: ValidatorHandlerImpl.java,v 1.1 2005/06/10 04:23:10 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package validator.ks;

import javax.xml.validation.TypeInfoProvider;
import javax.xml.validation.ValidatorHandler;

import org.apache.xerces.util.TypeInfoImpl;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

/**
 * Here's how this validator behaves.
 * 
 * TODO: 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
class ValidatorHandlerImpl extends ValidatorHandler {
    
    private ContentHandler output;
    private ErrorHandler errorHandler;
    private LSResourceResolver resourceResolver;
    
    private Attributes currentAtts;
    private String currentElementName;
    
    private final TypeInfoProvider typeInfoProvider = new TypeInfoProvider() {
        public TypeInfo getAttributeTypeInfo(int index) {
            return new TypeInfoImpl(
                currentAtts.getQName(index),
                currentAtts.getValue(index));
        }

        public TypeInfo getAttributeTypeInfo(String attributeUri, String attributeLocalName) {
            return getAttributeTypeInfo(currentAtts.getIndex(attributeUri,attributeLocalName));
        }

        public TypeInfo getAttributeTypeInfo(String attributeQName) {
            return getAttributeTypeInfo(currentAtts.getIndex(attributeQName));
        }

        public TypeInfo getElementTypeInfo() {
            return new TypeInfoImpl(null,currentElementName);
        }

        public boolean isIdAttribute(int index) {
            return currentAtts.getValue(index).equals("id");
        }

        public boolean isSpecified(int index) {
            return true;
        }
    };

    
    public void setContentHandler(ContentHandler receiver) {
        this.output = receiver;
    }

    public ContentHandler getContentHandler() {
        return output;
    }

    public boolean isValidSoFar() {
        return true;
    }

    public ErrorHandler getErrorHandler() {
        return errorHandler;
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        this.errorHandler = errorHandler;
    }

    public LSResourceResolver getResourceResolver() {
        return resourceResolver;
    }

    public void setResourceResolver(LSResourceResolver resourceResolver) {
        this.resourceResolver = resourceResolver;
    }

    public TypeInfoProvider getTypeInfoProvider() {
        return typeInfoProvider;
    }
    
    public void characters(char[] ch, int start, int length) throws SAXException {
        output.characters(ch, start, length);
    }

    public void endDocument() throws SAXException {
        output.endDocument();
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        output.endElement(uri, localName, qName);
    }

    public void endPrefixMapping(String prefix) throws SAXException {
        output.endPrefixMapping(prefix);
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        output.ignorableWhitespace(ch, start, length);
    }

    public void processingInstruction(String target, String data) throws SAXException {
        output.processingInstruction(target, data);
    }

    public void setDocumentLocator(Locator locator) {
        output.setDocumentLocator(locator);
    }

    public void skippedEntity(String name) throws SAXException {
        output.skippedEntity(name);
    }

    public void startDocument() throws SAXException {
        output.startDocument();
    }

    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        currentAtts = atts;
        currentElementName = localName;
        output.startElement(uri, localName, qName, atts);
        currentAtts = null;
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        output.startPrefixMapping(prefix, uri);
    }

}
