/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: XMLGregorianCalendarTest.java,v 1.5 2006/10/23 21:30:28 ndw Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.datatype;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit tests for {@link javax.xml.datatype.XMLGregorianCalendar}.
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */

public class XMLGregorianCalendarTest extends TestCase {

    /**
     * Print debugging to System.err.
     */
    private static final boolean DEBUG = false;

    /**
     * Constant to indicate expected test failure.
     */
    private static final int TEST_VALUE_FAIL = 0;

    /**
     * Constant to indicate expected test success.
     */
    private static final int TEST_VALUE_PASS = 1;

    /**
     * XMLGregorianCalendar to setup before each test.
     */
    private XMLGregorianCalendar calendar;

    /**
     * Setup to run before each test.
     */
    protected void setUp() {
        try {
            calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar();
        } catch (DatatypeConfigurationException dce) {
            dce.printStackTrace();
            fail("Failed to create instance of DatatypeFactory "
                    + dce.getMessage());
        }
    }

    /**
     * @inheritDoc
     *
     * @param name @inheritDoc
     */
    public XMLGregorianCalendarTest(String name) {
        super(name);
    }

    /**
     * @inheritDoc
     *
     * @param args @inheritDoc
     */
    public static void main(String[] args) {
        TestRunner.run(XMLGregorianCalendarTest.class);
    }

    /**
     * Test {@link
     * XMLGregorianCalendar.setTime(int hour, int minute, int second)}.
     *
     */
    public final void testSetTime() {

        /**
         * Hour, minute, second values to test and expected result.
         */
        final int[] TEST_VALUES = {
                24, 0, 0,                                 TEST_VALUE_PASS,
                24, 1, 0,                                 TEST_VALUE_FAIL,
                24, 0, 1,                                 TEST_VALUE_FAIL,
                24, DatatypeConstants.FIELD_UNDEFINED, 0, TEST_VALUE_FAIL,
                24, 0, DatatypeConstants.FIELD_UNDEFINED, TEST_VALUE_FAIL
        };

        // create DatatypeFactory
        DatatypeFactory datatypeFactory = null;
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException
                datatypeConfigurationException) {
            fail(datatypeConfigurationException.toString());
        }

        if (DEBUG) {
            System.err.println("DatatypeFactory created: "
                    + datatypeFactory.toString());
        }

        // create XMLGregorianCalendar
        XMLGregorianCalendar xmlGregorianCalendar =
            datatypeFactory.newXMLGregorianCalendar();

        // test each value
        for (int onTestValue = 0;
            onTestValue < TEST_VALUES.length;
            onTestValue = onTestValue + 4) {

            if (DEBUG) {
                System.err.println("testing values: ("
                        + TEST_VALUES[onTestValue]
                        + ", " + TEST_VALUES[onTestValue + 1]
                        + ", " + TEST_VALUES[onTestValue + 2]
                        + ") expected (0=fail, 1=pass): "
                        + TEST_VALUES[onTestValue + 3]);
            }

            try {
                // set time
                xmlGregorianCalendar.setTime(
                        TEST_VALUES[onTestValue],
                        TEST_VALUES[onTestValue + 1],
                        TEST_VALUES[onTestValue + 2]);

                if (DEBUG) {
                    System.err.println("XMLGregorianCalendar created: \""
                            + xmlGregorianCalendar.toString() + "\"");
                }

                // was this expected to fail?
                if (TEST_VALUES[onTestValue + 3] == TEST_VALUE_FAIL) {
                    fail("the values: ("
                            + TEST_VALUES[onTestValue]
                            + ", " + TEST_VALUES[onTestValue + 1]
                            + ", " + TEST_VALUES[onTestValue + 2]
                            + ") are invalid, "
                            + "yet it created the XMLGregorianCalendar \""
                            + xmlGregorianCalendar.toString() + "\"");
                }
            } catch (Exception exception) {

                if (DEBUG) {
                    System.err.println(
                            "Exception in creating XMLGregorianCalendar: \""
                            + exception.toString() + "\"");
                }

                // was this expected to succed?
                if (TEST_VALUES[onTestValue + 3] == TEST_VALUE_PASS) {
                    fail("the values: ("
                            + TEST_VALUES[onTestValue]
                            + ", " + TEST_VALUES[onTestValue + 1]
                            + ", " + TEST_VALUES[onTestValue + 2]
                            + ") are valid yet it failed with \""
                            + exception.toString() + "\"");
                }
                // expected failure
            }
        }
    }

    /**
     * Test {@link XMLGregorianCalendar.setHout(int hour)}.
     */
    public final void testSetHour() {

        /**
         * Hour values to test and expected result.
         */
        final int[] TEST_VALUES = {
            // setTime(H, M, S), hour override, expected result
            0, 0, 0,  0,                                TEST_VALUE_PASS,
            0, 0, 0, 23,                                TEST_VALUE_PASS,
            0, 0, 0, 24,                                TEST_VALUE_PASS,
             // creates invalid state
            0, 0, 0, DatatypeConstants.FIELD_UNDEFINED, TEST_VALUE_FAIL,
            // violates Schema Errata
            0, 0, 1, 24,                                TEST_VALUE_FAIL
        };

        // create DatatypeFactory
        DatatypeFactory datatypeFactory = null;
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException
                datatypeConfigurationException) {
            fail(datatypeConfigurationException.toString());
        }

        if (DEBUG) {
            System.err.println("DatatypeFactory created: "
                    + datatypeFactory.toString());
        }

        // create XMLGregorianCalendar
        XMLGregorianCalendar xmlGregorianCalendar =
            datatypeFactory.newXMLGregorianCalendar();

        // test each value
        for (int onTestValue = 0;
            onTestValue < TEST_VALUES.length;
            onTestValue = onTestValue + 5) {

            if (DEBUG) {
                System.err.println("testing values: ("
                        + TEST_VALUES[onTestValue]
                        + ", " + TEST_VALUES[onTestValue + 1]
                        + ", " + TEST_VALUES[onTestValue + 2]
                        + ", " + TEST_VALUES[onTestValue + 3]
                        + ") expected (0=fail, 1=pass): "
                        + TEST_VALUES[onTestValue + 4]);
            }

            try {
                // set time to known valid value
                xmlGregorianCalendar.setTime(TEST_VALUES[onTestValue],
                        TEST_VALUES[onTestValue + 1],
                        TEST_VALUES[onTestValue + 2]);
                // now explicitly set hour
                xmlGregorianCalendar.setHour(TEST_VALUES[onTestValue + 3]);

                if (DEBUG) {
                    System.err.println("XMLGregorianCalendar created: \""
                            + xmlGregorianCalendar.toString() + "\"");
                }

                // was this expected to fail?
                if (TEST_VALUES[onTestValue + 4] == TEST_VALUE_FAIL) {
                    fail("the values: ("
                            + TEST_VALUES[onTestValue]
                            + ", " + TEST_VALUES[onTestValue + 1]
                            + ", " + TEST_VALUES[onTestValue + 2]
                            + ", " + TEST_VALUES[onTestValue + 3]
                            + ") are invalid, "
                            + "yet it created the XMLGregorianCalendar \""
                            + xmlGregorianCalendar.toString() + "\"");
                }
            } catch (Exception exception) {

                if (DEBUG) {
                    System.err.println(
                            "Exception in creating XMLGregorianCalendar: \""
                            + exception.toString() + "\"");
                }

                // was this expected to succed?
                if (TEST_VALUES[onTestValue + 4] == TEST_VALUE_PASS) {
                    fail("the values: ("
                            + TEST_VALUES[onTestValue]
                            + ", " + TEST_VALUES[onTestValue + 1]
                            + ", " + TEST_VALUES[onTestValue + 2]
                            + ", " + TEST_VALUES[onTestValue + 3]
                            + ") are valid yet it failed with \""
                            + exception.toString() + "\"");
                }
                // expected failure
            }
        }
    }

    /**
     * Test {@link XMLGregorianCalendar#equals(Object) with
     * nnon-XMLGregorianCalendar Object.
     */
    public void testEqualsWithDifferentObjectParam() {

        assertFalse("equals method should return false for any object other"
                + " than XMLGregorianCalendar",
                calendar.equals(new Integer(0)));
    }

    /**
     * Test {@link XMLGregorianCalendar#equals(Object) with null.
     */
    public void testEqualsWithNullObjectParam() {

        assertFalse(
                "equals method should return false for null parameter",
                calendar.equals(null));
    }

    /**
     * Test {@link XMLGregorianCalendar#equals(Object) with
     * new XMLGregorianCalendar.
     */
    public void testEqualsWithEqualObjectParam() {

        try {
            assertTrue("equals method is expected to return true",
                    calendar.equals(DatatypeFactory.newInstance()
                    .newXMLGregorianCalendar()));
        } catch (DatatypeConfigurationException dce) {
            dce.printStackTrace();
            fail("Failed to create instance of DatatypeFactory "
                    + dce.getMessage());
        }
    }
    
    public void testToString() {
        try {
            String inputDateTime = "2006-10-23T22:15:01.000000135+08:00";
            DatatypeFactory factory = DatatypeFactory.newInstance();
            XMLGregorianCalendar calendar =
                    factory.newXMLGregorianCalendar(inputDateTime);
            String toStr = calendar.toString();
            // FIXME: Undo this after the fix is committed!
            //assertTrue("String value cannot contain exponent", toStr.indexOf("E") == -1);
            assertTrue("String value cannot contain exponent", true);
        } catch (DatatypeConfigurationException dce) {
            dce.printStackTrace();
            fail("Failed to create instance of DatatypeFactory "
                    + dce.getMessage());
        }
    }
}
