package bug6493687;

import org.w3c.dom.Document;

public class Main {

    public static void main(String[] args) {
        new Main().test();
    }

    private void test() {
        System.out.println("Got here");
        Document doc = new XMLDocBuilder("jaxp-ri/src/unit-test/bug6493687/test.xml",
                                         "UTF-8",
                                         "jaxp-ri/src/unit-test/bug6493687/test.xsd").getDocument();
        System.out.println("Got here2");
        System.out.println(doc);
        System.out.println(doc.getDocumentElement().getNodeName());
        System.out.println("Got here3");
    }
}
