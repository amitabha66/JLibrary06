/*
 * Bug.java
 *
 * Created on November 17, 2005, 11:49 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */
package bug6341770;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;
/**
 *
 * @author Sunitha Reddy
 */
public class Bug extends TestCase{
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
    
     public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
     
     public void testNonAsciiURI(){
         try{
            File dir = File.createTempFile("sko\u0159ice", null);
            dir.delete();
            dir.mkdir();
            File main = new File(dir, "main.xml");
            PrintWriter w = new PrintWriter(new FileWriter(main));
            w.println("<!DOCTYPE r [<!ENTITY aux SYSTEM \"aux.xml\">]>");
            w.println("<r>&aux;</r>");
            w.flush();
            w.close();
            File aux = new File(dir, "aux.xml");
                       w = new PrintWriter(new FileWriter(aux));
            w.println("<x/>");
            w.flush();
            w.close();
            System.out.println("Parsing: " + main);
            SAXParserFactory.newInstance().newSAXParser().parse(main, new DefaultHandler() {
                public void startElement(String uri, String localname, String qname, Attributes attr) throws SAXException {
                    System.out.println("encountered <" + qname + ">");
                }
            }); 
         }catch(Exception e)
         {
             e.printStackTrace();
             fail("Exception: "+e.getMessage());
         }
        System.out.println("OK.");
     }
}
