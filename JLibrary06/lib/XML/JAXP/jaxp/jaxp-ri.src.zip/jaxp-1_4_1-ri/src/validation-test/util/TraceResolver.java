/*
 * @(#)$Id: TraceResolver.java,v 1.1 2005/06/10 04:23:33 jeffsuttor Exp $
 * 
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc. Use
 * is subject to license terms.
 *  
 */

package util;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

/**
 * Resolver that does nothing (but show trace messages.)
 * 
 * @author Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class TraceResolver implements LSResourceResolver {

    public LSInput resolveResource(String type, String ns,String publicId, String systemId, String baseURI) {
        System.out.println("Resolver " + systemId);
        System.out.println("Resolver " + baseURI);
        return null;
    }
}
