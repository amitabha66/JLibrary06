/*
 * @(#)$Id: TypeInfoTest.java,v 1.1 2005/06/10 04:24:19 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package tests.dom;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import junit.textui.TestRunner;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.TypeInfo;

import tests.BaseTestCase;
import util.Which4J;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class TypeInfoTest extends BaseTestCase {
    
    /**
     * Uses K schema language to test a parser.
     */
    public void test1() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        System.out.println(Which4J.which(dbf.getClass()));
        dbf.setSchema(loadKSchema());
        DocumentBuilder db = dbf.newDocumentBuilder();
        
        Document dom = db.parse(createStringSource("<root att1='id' att2='text'/>"));
        Element root = dom.getDocumentElement();
        
        TypeInfo type = root.getSchemaTypeInfo();
        assertNull(type.getTypeNamespace());
        assertEquals("root",type.getTypeName());
        
        Attr a = root.getAttributeNode("att1");
        assertTrue(a.getSpecified());
        
        type = a.getSchemaTypeInfo();
        assertEquals("att1",type.getTypeNamespace());
        assertEquals("id",type.getTypeName());
    }

    /**
     * Uses XSD in Xerces to test validator impl. 
     */
    public void test2() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        System.out.println(Which4J.which(dbf.getClass()));
        dbf.setSchema(loadXsdSchema("Test2.xsd"));
        DocumentBuilder db = dbf.newDocumentBuilder();
        
        Document dom = db.parse(createStringSource("<root k='someId'/>"));
        Element root = dom.getDocumentElement();
        
        TypeInfo type = root.getSchemaTypeInfo();
        assertNull(type.getTypeNamespace());
        assertEquals("rootType",type.getTypeName());
        
        
        Attr a = root.getAttributeNode("i");
        assertNotNull(a);
        assertFalse(a.getSpecified());
        assertFalse(a.isId());
        
        type = a.getSchemaTypeInfo();
        assertEquals("http://www.w3.org/2001/XMLSchema",type.getTypeNamespace());
        assertEquals("int",type.getTypeName());

    
        
        a = root.getAttributeNode("j");
        assertNotNull(a);
        assertFalse(a.getSpecified());
        assertFalse(a.isId());
        
        type = a.getSchemaTypeInfo();
        assertEquals("http://www.w3.org/2001/XMLSchema",type.getTypeNamespace());
        assertEquals("string",type.getTypeName());

    
        
        a = root.getAttributeNode("k");
        assertNotNull(a);
        assertTrue(a.getSpecified());
        assertTrue(a.isId());
        
        type = a.getSchemaTypeInfo();
        assertEquals("http://www.w3.org/2001/XMLSchema",type.getTypeNamespace());
        assertEquals("ID",type.getTypeName());
    }
    
    
    public static void main(String[] args) {
    	TestRunner.run(TypeInfoTest.class);
    }
}
