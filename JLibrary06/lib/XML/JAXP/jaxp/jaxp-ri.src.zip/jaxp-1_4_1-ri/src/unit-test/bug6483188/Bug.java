/*
 * Bug.java
 *
 * Created on November 9, 2006, 3:44 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6483188;

import java.net.URL;
import javax.xml.validation.*;
import javax.xml.XMLConstants;
import junit.textui.TestRunner;

import junit.framework.*;
import org.xml.sax.SAXParseException;

/**
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
   
    SchemaFactory sf = 
            SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String [] args) {
        TestRunner.run(Bug.class);
    }
    
    public void testLargeElementNoSecurity() {
        try {
            sf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.FALSE);
            URL url = getClass().getResource("test-element.xsd");
            Schema s = sf.newSchema(url);
            Validator v = s.newValidator();
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }
    
    public void testLargeElementWithSecurity() {
        try {
            sf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.TRUE);
            URL url = getClass().getResource("test-element.xsd");
            Schema s = sf.newSchema(url);
            Validator v = s.newValidator();
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }
    
    public void testLargeSequenceWithSecurity() {
        try {
            sf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.TRUE);
            URL url = getClass().getResource("test-sequence.xsd");
            Schema s = sf.newSchema(url);
            Validator v = s.newValidator();
            fail("Schema was accepted even with secure processing enabled.");
        } 
        catch (SAXParseException e) {
            // falls through - exception expected
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }
    
}
