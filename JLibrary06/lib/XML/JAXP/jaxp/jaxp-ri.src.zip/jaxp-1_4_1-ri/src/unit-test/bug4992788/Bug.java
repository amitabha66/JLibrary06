/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:23:58 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4992788;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.xml.sax.InputSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    protected static SAXParser createParser() throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        spf.setValidating(true);
        SAXParser parser = spf.newSAXParser();
        parser.setProperty(
                "http://java.sun.com/xml/jaxp/properties/schemaLanguage",
        "http://www.w3.org/2001/XMLSchema");

        return parser;
    }

    private static String expression = "/widgets/widget[@name='a']/@quantity";
    
    // test for XPath.evaluate(java.lang.String expression, InputSource source) - default returnType is String
    // source is null , should throw NPE
    public void testXPath23() throws Exception {
        try {
            createXPath().evaluate(expression, (InputSource)null);
            fail();
        } catch( NullPointerException e ) {
            ; // as expected
        }
    }

    // test for XPath.evaluate(java.lang.String expression, InputSource source, QName returnType)
    //  source is null , should throw NPE
    public void testXPath28() throws Exception {
        try {
            createXPath().evaluate(expression, (InputSource)null, XPathConstants.STRING);
            fail();
        } catch( NullPointerException e ) {
            ; // as expected
        }
    }

    private XPath createXPath() throws XPathFactoryConfigurationException {
        XPathFactory xpathFactory = XPathFactory.newInstance();
        assertNotNull(xpathFactory);
        XPath xpath = xpathFactory.newXPath();
        assertNotNull(xpath);
        return xpath;
    }
}