package javax.xml.stream.XMLStreamReaderTest;

import java.io.StringReader;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class BugTest extends TestCase {

    public BugTest(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(BugTest.class);
    }
    
    public static void test1() throws Exception {
        XMLInputFactory xif = XMLInputFactory.newInstance(); //  new com.sun.xml.stream.ZephyrParserFactory();
        XMLStreamReader r = xif.createXMLStreamReader(
            new StringReader("<foo/>"));
        assertEquals(XMLStreamConstants.START_DOCUMENT,r.getEventType());
    }
}
