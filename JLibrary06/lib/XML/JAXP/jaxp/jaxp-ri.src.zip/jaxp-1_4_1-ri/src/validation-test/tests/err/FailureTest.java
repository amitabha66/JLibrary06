/*
 * @(#)$Id: FailureTest.java,v 1.1 2005/06/10 04:24:16 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package tests.err;

import javax.xml.validation.SchemaFactory;

import junit.textui.TestRunner;

import org.xml.sax.SAXException;

import tests.BaseTestCase;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class FailureTest extends BaseTestCase {
    public void testSchemaParseError() throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        try {
            sf.newSchema(this.getClass().getResource("err.xsd"));
            fail("should fail");
        } catch( SAXException e ) {// as expected
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        TestRunner.run(FailureTest.class);
    }
}
