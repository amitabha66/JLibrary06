
/*
 * TestEventTransformer.java
 */

/**
 *
 * @author pv156767
 */

package transforms;
 
import java.io.StringReader;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.Templates;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.stream.*;
import javax.xml.stream.events.* ;
import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import java.io.*;    

public class TestEventTransformer {
    public static void main(String[] args) throws Exception {
       // Locale.setDefault(new Locale("fr", "FR"));
        String xslt =
            "<xsl:stylesheet version='1.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform'>\n" +
            "    <xsl:output method='xml' indent='yes' omit-xml-declaration='yes'/>\n" +
            "    <xsl:template match='/'>\n" +
            "        <hello/>\n" +
            "    </xsl:template>\n" +
            "</xsl:stylesheet>";
        System.out.println("the stylesheet :  " + args[0].toString());
        //InputSource is = new InputSource(new FileInputStream(args[0].toString())); 
        //SAXSource ss = new SAXSource (is);
        try {
        javax.xml.transform.Source source = new javax.xml.transform.stax.StAXSource(getXMLEventReader(args[0].toString()));
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer(source);
        System.out.println();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
        private static XMLEventReader getXMLEventReader(String filename){
    
    	XMLInputFactory xmlif = null ;
        XMLEventReader xmlr = null;
        try{
            xmlif = XMLInputFactory.newInstance();
            xmlif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,Boolean.FALSE);
            xmlif.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE , Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_COALESCING , Boolean.TRUE);
                        
            FileInputStream fis = new FileInputStream(filename);
            xmlr =  xmlif.createXMLEventReader(filename, fis);            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return xmlr;
    }
}
    


