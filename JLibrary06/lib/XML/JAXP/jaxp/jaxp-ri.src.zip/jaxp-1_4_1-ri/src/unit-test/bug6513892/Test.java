
package bug6513892;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;

/**
 * Unit test for CR 6513892. Ensure that the output encoding of the
 * transform is the same as that of the redirect extension, in this
 * case UTF-8 in both cases. 
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {
    
    public static void main(String [] args){
        TestRunner.run(Test.class);
    }
    
    public void test0() {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();            
            Transformer t = tf.newTransformer(
                    new StreamSource(getClass().getResourceAsStream("redirect.xsl"),
                    getClass().getResource("redirect.xsl").toString()));

            StreamSource src1 = new StreamSource(
                    getClass().getResourceAsStream("redirect.xml"));
            t.transform(src1, new StreamResult("redirect1.xml"));
                        
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            
            Document d1 = db.parse(new File("redirect1.xml"));
            Document d2 = db.parse(new File("redirect2.xml"));
            
            assertTrue(d1.getDocumentElement().getFirstChild().getNodeValue().equals(
                    d2.getDocumentElement().getFirstChild().getNodeValue()));                        
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }
    
}
