/*
 * @(#)$Id: InterpreterEx.java,v 1.1 2005/06/10 04:24:16 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package batch.util;

import java.io.PrintStream;
import java.io.Reader;

import bsh.EvalError;
import bsh.Interpreter;
import bsh.NameSpace;

/**
 * {@link Interpreter} that redirects stderr to stdout.
 * 
 * We don't wat scripts from cluttering stderr, which is
 * reserved for the test harness. 
 */
public class InterpreterEx extends Interpreter {
    public Object eval(Reader in, NameSpace nameSpace, String sourceFileInfo) throws EvalError {
        PrintStream stderr = System.err;
        try {
            System.setErr(System.out);
            return super.eval(in, nameSpace, sourceFileInfo);
        } finally {
            System.setErr(stderr);
        }
    }

    public Object eval(Reader in) throws EvalError {
        PrintStream stderr = System.err;
        try {
            System.setErr(System.out);
            return super.eval(in);
        } finally {
            System.setErr(stderr);
        }
    }

    public Object eval(String statements, NameSpace nameSpace) throws EvalError {
        PrintStream stderr = System.err;
        try {
            System.setErr(System.out);
            return super.eval(statements, nameSpace);
        } finally {
            System.setErr(stderr);
        }
    }

    public Object eval(String statements) throws EvalError {
        PrintStream stderr = System.err;
        try {
            System.setErr(System.out);
            return super.eval(statements);
        } finally {
            System.setErr(stderr);
        }
    }

}
