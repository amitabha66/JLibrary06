package validation;

/*
 * ErrorHandlerImpl.java
 *
 * Created on December 7, 2004, 9:54 AM
 */

/**
 *
 * @author  Neeraj Bajaj, Sun Microsystems.
 */
public class ErrorHandlerImpl implements org.xml.sax.ErrorHandler{
    
    /** Creates a new instance of ErrorHandlerImpl */
    public ErrorHandlerImpl() {
    }
    

    public void error(org.xml.sax.SAXParseException sAXParseException) throws org.xml.sax.SAXException {
        System.out.println("ERROR: sAXParseException = " + sAXParseException.toString());
    }

    public void fatalError(org.xml.sax.SAXParseException sAXParseException) throws org.xml.sax.SAXException {
        System.out.println("FATAL ERROR: sAXParseException = " + sAXParseException.toString());
    }

    public void warning(org.xml.sax.SAXParseException sAXParseException) throws org.xml.sax.SAXException {
        System.out.println("WARNING: sAXParseException = " + sAXParseException.toString());
    }
    
}
