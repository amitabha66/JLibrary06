package bug6451633;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.helpers.AttributesImpl;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;

/**
 * @author Kohsuke Kawaguchi
 */
public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    public void test() throws Exception {
        TransformerHandler th =
            ((SAXTransformerFactory)TransformerFactory.newInstance()).newTransformerHandler();

        DOMResult result = new DOMResult();
        th.setResult(result);

        th.startDocument();
        th.startElement("","root","root",new AttributesImpl());
        th.characters(new char[0],0,0);
        th.endElement("","root","root");
        th.endDocument();

        // there's no point in having empty text --- we should remove it
        assertEquals(0,((Document)result.getNode()).getDocumentElement().getChildNodes().getLength());
    }
}
