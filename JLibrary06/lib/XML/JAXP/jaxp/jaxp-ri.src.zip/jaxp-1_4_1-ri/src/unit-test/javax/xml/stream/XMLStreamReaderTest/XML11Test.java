/*
 * XML11Test.java
 *
 * Created on June 6, 2006, 11:41 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package javax.xml.stream.XMLStreamReaderTest;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLEventReader;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy
 */
public class XML11Test extends TestCase{
    
    /** Creates a new instance of XML11Test */
    public XML11Test() {
    }
 
     public static void main(String[] args) {
    	TestRunner.run(XML11Test.class);
    }
    
     /* Tests support of XML 1.1 for StAX parser.
      * bug#6421893
      */
    public void test() {
        try{
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLEventReader reader = xif.createXMLEventReader(this.getClass().getResourceAsStream("xml11.xml")); 
            while (reader.hasNext())
                reader.next();
            
        }catch(Exception e){
            e.printStackTrace();
            fail(e.toString());
        }
    }
}
