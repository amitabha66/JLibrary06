/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

package javax.xml.stream.XMLStreamReaderTest;

/**
 * Test parsing Voice XML DTD
 *
 * @author Santiago.PericasGeertsen@sun.com
 */

import java.io.*;
import java.util.Iterator;
import javax.xml.stream.*;
import javax.xml.stream.events.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * @author Santiago.PericasGeertsen@sun.com
 */
public class VoiceXMLDTDTest extends TestCase {
    
    private static final String INPUT_FILE1 = "voicexml.xml";
    
    public VoiceXMLDTDTest(String name) {
         super(name);
    }   
    
    public static void main(String[] args) {
    	TestRunner.run(VoiceXMLDTDTest.class);
    }
    
    public void test() {       
        XMLInputFactory ifac = XMLInputFactory.newInstance();        
 
        try {               
            XMLStreamReader re = ifac.createXMLStreamReader(
                    getClass().getResource(INPUT_FILE1).toExternalForm(),
                    this.getClass().getResourceAsStream(INPUT_FILE1));                        
            while (re.hasNext()){
		int event = re.next();
	    }
        } catch(Exception e) {
            e.printStackTrace();
            fail("Exception occured: " + e.getMessage());
        }
    }    
}
