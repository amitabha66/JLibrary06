/*
 * Bug.java
 *
 * Created on October 20, 2005, 2:40 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6308768;

import java.io.*;
import java.util.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy
 */
public class Bug extends TestCase{
    
    private Properties originalProps = new Properties();
    private Properties retrievedProps = new Properties();
    private static String PROPERTY_FILE_NAME = "temppropertyfile";
    private String FIRST_KEY_STR = "firstKey";
    private String FIRST_VALUE_STR = "";
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    protected void setUp()
    {
        originalProps = populatePropertyFileForCp875();
    }
    
    protected void tearDown()
    {
        
    }
    
    public void testCp875()
    {
        runTest("Cp875");
    }
    
    public void testUTF8()
    {
        runTest("UTF-8");
    }
    
    public void testUTF16()
    {
        runTest("UTF-16");
    }
    
     private void runTest(String encodingType) {

        try {
            //originalProps = populatePropertyFileForCp875();
            storeAndLoadPropertyFile(encodingType);
            verifyEncodedPropertyFile(FIRST_VALUE_STR);

            System.out.println("Test Passed!!");
        }catch(Exception ex) {
             ex.printStackTrace();
             fail("Exception thrown: " + ex.getMessage());
        }
    }
     
    private Properties populatePropertyFileForCp875()  {
	
            FIRST_VALUE_STR = "\u0020\u0391\u0392\u0393\u0394\u0395\u0396\u0397";
            originalProps.put(FIRST_KEY_STR, FIRST_VALUE_STR);
            return originalProps;
    }
    
   /*
    * 'Store' the populated 'Property' with the specified 'Encoding Type' as an
    * XML file. Retrieve the same XML file and 'load' onto a new 'Property' object.
    */
    private void storeAndLoadPropertyFile(String encoding) {
	try{
            // Destroy old test file if it exists
            File oldPropFile = new File(PROPERTY_FILE_NAME);
            oldPropFile.delete();

            //Creating Property file
            System.out.println("Create Property with specified encoding");
            OutputStream out = new FileOutputStream(PROPERTY_FILE_NAME);
            originalProps.storeToXML(out, "Property With Other Encoding",
                                     encoding);
            out.close();

            
            InputStream in = new FileInputStream(PROPERTY_FILE_NAME);
            retrievedProps.loadFromXML(in);
	}catch (Exception e)
        {
            e.printStackTrace();
            fail("Exception in storeAndLoadPropertyFile: " + e.getMessage());
        }
    }

   /*
    * This method verifies the first key-value with the original string.
    */
    private void verifyEncodedPropertyFile(String first_value_str) {
	try{
            //verify results - Comparing only the first key value
            String tempValueStr = retrievedProps.getProperty(FIRST_KEY_STR);
            System.out.println("\nOriginal String (First Value): " +first_value_str);
            System.out.println("Retrieved String (First value) : " +tempValueStr);
            if (! first_value_str.equals(tempValueStr)) 
                fail("Properties didn't match!");
       
        }catch (Exception e)
        {
            e.printStackTrace();
            fail("Exception in verifyEncodedPropertyFile: " +e.getMessage());
        }
                
    }
    
}
