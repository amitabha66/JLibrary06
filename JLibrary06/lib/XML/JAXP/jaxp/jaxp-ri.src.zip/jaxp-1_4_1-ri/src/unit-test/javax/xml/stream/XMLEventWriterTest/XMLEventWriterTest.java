/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: XMLEventWriterTest.java,v 1.3 2006/07/26 04:56:20 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2006 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.stream.XMLEventWriterTest;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.events.XMLEvent;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

/**
 * Test XMLEventWriter.
 *
 * @author <a href="mailtoJeff.Suttor@Sun.com>Jeff Suttor</a>, cribbed from CR 6245284 user provided test case.
 */
public class XMLEventWriterTest extends TestCase {

    /**
     * Creates a new instance of XMLStreamWriterTest.
     *
     * @param name Name of test.
     */
    public XMLEventWriterTest(String name) {
        super(name);
    }

    /**
     * Command line invokation.
     *
     * @param args Standard args.
     */
    public static void main(String [] args) {
        TestRunner.run(XMLEventWriterTest.class);
    }

    /**
     * Test XMLStreamWriter parsing a file with an external entity reference.
     */
    public void testXMLStreamWriter() {

        try {
            XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();
            XMLEventWriter eventWriter =
                    outputFactory.createXMLEventWriter(System.out);
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            File file = new File(XMLEventWriterTest.class.getResource(
                            "XMLEventWriterTest.xml").toURI());
            FileInputStream inputStream = new FileInputStream(file);
            XMLEventReader eventReader =
                    inputFactory.createXMLEventReader(inputStream);

            //adds the event to the consumer.
            eventWriter.add(eventReader);
            eventWriter.flush();
            eventWriter.close();

            // expected success
        } catch (Exception exception) {
            exception.printStackTrace();
            fail(exception.toString());
        }
    }

    /**
     * Inspired by CR 6245284 Sun Stax /sjsxp.jar does not behave properly
     * during merge of xml files.
     */
    public void testMerge() {

        try {
            // Create the XML input factory
            XMLInputFactory factory = XMLInputFactory.newInstance();

            // Create XML event reader 1
            InputStream inputStream1 = new FileInputStream(
                    new File(XMLEventWriterTest.class.getResource(
                        "merge-1.xml").toURI()));
            XMLEventReader r1 = factory.createXMLEventReader(inputStream1);

            // Create XML event reader 2
            InputStream inputStream2 = new FileInputStream(
                    new File(XMLEventWriterTest.class.getResource(
                        "merge-2.xml").toURI()));
            XMLEventReader r2 = factory.createXMLEventReader(inputStream2);

            // Create the output factory
            XMLOutputFactory xmlof = XMLOutputFactory.newInstance();

            // Create XML event writer
            XMLEventWriter xmlw = xmlof.createXMLEventWriter(System.out);

            // Read to first <product> element in document 1
            // and output to result document
            QName bName = new QName("b");

            while (r1.hasNext()) {
                // Read event to be written to result document
                XMLEvent event = r1.nextEvent();

                if (event.getEventType() == XMLEvent.END_ELEMENT) {

                    // Start element - stop at <product> element
                    QName name = event.asEndElement().getName();
                    if (name.equals(bName)) {

                        QName zName = new QName("z");

                        boolean isZr = false;

                        while (r2.hasNext()) {
                            // Read event to be written to result document
                            XMLEvent event2 = r2.nextEvent();
                            // Output event
                            if (event2.getEventType() == XMLEvent.START_ELEMENT
                                    && event2.asStartElement().getName().equals(zName)) {
                                isZr = true;
                            }

                            if (xmlw != null && isZr) {
                                xmlw.add(event2);
                            }

                            // stop adding events after </z>
                            // i.e. do not write END_DOCUMENT :)
                            if (isZr
                                    && event2.getEventType() == XMLEvent.END_ELEMENT
                                    && event2.asEndElement().getName().equals(zName)) {
                                isZr = false;
                            }
                        }
                        xmlw.flush();
                    }
                }

                // Output event
                if (xmlw != null) {
                    xmlw.add(event);
                }
            }

            // Read to first <product> element in document 1
            // without writing to result document
            xmlw.close();

            // expected success
        } catch (Exception ex) {
            ex.printStackTrace();
            fail(ex.toString());
        }
    }
}
