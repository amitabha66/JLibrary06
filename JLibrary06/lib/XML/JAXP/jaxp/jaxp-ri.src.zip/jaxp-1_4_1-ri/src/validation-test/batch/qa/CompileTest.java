/*
 * @(#)$Id: CompileTest.java,v 1.1 2005/06/10 04:24:07 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package batch.qa;

import javax.xml.validation.SchemaFactory;

import junit.framework.TestCase;

import org.xml.sax.SAXException;

import batch.core.om.Schema;

/**
 * Compiles a schema by using the validation API
 * and checks if it goes as expected.
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class CompileTest extends TestCase {
    
    private final Schema schema;
    
    private javax.xml.validation.Schema compiledSchema;
    
    public CompileTest( Schema s ) {
        this.schema = s;
    }
    
    public String toString() {
        return "compiling "+schema.schema;
    }

    public void runTest() {
        try {
            SchemaFactory sf = SchemaFactory.newInstance(schema.language);
            compiledSchema = sf.newSchema(schema.schema);
            assertFalse( "incorrect schema "+schema.schema+" was accepted", schema.isNegativeTest );
        } catch( SAXException e ) {
            System.out.println(e.getMessage());
            assertTrue( "corret schema was rejected", schema.isNegativeTest );
        }
    }
    
    public void dispose() {
        compiledSchema = null;
    }

    public javax.xml.validation.Schema getCompiledSchema() {
        return compiledSchema;
    }
}
