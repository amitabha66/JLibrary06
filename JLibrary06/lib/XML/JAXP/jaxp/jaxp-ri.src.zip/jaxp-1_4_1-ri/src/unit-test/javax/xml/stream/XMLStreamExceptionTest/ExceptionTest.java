/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */
/*
 * $Id: ExceptionTest.java,v 1.1 2006/05/20 03:30:13 sunithareddy Exp $
 * %W% %E%
 *
 * Copyright 2006 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.stream.XMLStreamExceptionTest;

import javax.xml.stream.*;
import java.io.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy, Sun Microsystems
 */

public class ExceptionTest extends TestCase{
    
    public ExceptionTest(String name) {
        super(name);
    }
    
    public static void main(String [] args) {
        TestRunner.run(ExceptionTest.class);
    }
    
    public void testException(){
        
        final String EXPECTED_OUTPUT = "Test XMLStreamException";
        try{
            Exception ex = new IOException("Test XMLStreamException");
            throw new XMLStreamException(ex);
        } catch(XMLStreamException e){
            assertTrue("XMLStreamException does not contain the message " +
                    "of the wrapped exception", 
                    e.getMessage().contains(EXPECTED_OUTPUT));
        }
    }
}
