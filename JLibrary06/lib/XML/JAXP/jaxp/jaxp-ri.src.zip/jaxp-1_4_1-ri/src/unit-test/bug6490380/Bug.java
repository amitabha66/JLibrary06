/*
 * Bug.java
 *
 * Created on November 6, 2006, 9:36 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6490380;

import java.io.StringWriter;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import junit.framework.Assert;

import java.net.URL;

/**
 * Make sure that a single DOCTYPE declaration is generated. Due to a
 * bug in XSLTC's output system, some times a DOCTYPE declaration was
 * generated before and after the XML declaration.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    public void test() {
        try {
            Transformer transformer = 
                    TransformerFactory.newInstance().newTransformer();  
            URL input = Bug.class.getResource("Bug4693341.xml");
            StreamSource source = new StreamSource(input.openStream(),
                    input.toString());            
            StringWriter sw = new StringWriter();
            transformer.transform(source, new StreamResult(sw));
            String s = sw.toString();
            Assert.assertEquals(s.indexOf("!DOCTYPE"),
                                s.lastIndexOf("!DOCTYPE"));
        } 
        catch (Exception ex) {
            fail(ex.getMessage());
        }
    }    
}
