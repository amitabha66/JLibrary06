/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:24:47 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug5025825;

import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    String schemaSource =
                      "<?xml version='1.0'?>\n"
                      + "<xsd:schema xmlns:xsd='http://www.w3.org/2001/XMLSchema'>\n"
                      + "  <xsd:element name='test101'>\n"
                      + "    <xsd:complexType>\n"
                      + "      <xsd:attribute name='attr'/>\n"
                      + "      <xsd:attribute name='attr2' default='DEF'/>\n"
                      + "    </xsd:complexType>\n"
                      + "  </xsd:element>\n"
                      + "</xsd:schema>\n";
    
    private Schema createSchema() throws SAXException {
        SchemaFactory schFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        return schFactory.newSchema(new StreamSource(new StringReader(schemaSource)));
    }
    public void test1() throws Exception {
        Schema sch = createSchema();
        assertNotNull(sch);
        
        SAXParserFactory spFactory = SAXParserFactory.newInstance();
        spFactory.setNamespaceAware(true);
        spFactory.setValidating(true);
        spFactory.setSchema(sch);
        
        SAXParser sParser = spFactory.newSAXParser();
        
        final String aSchemaLanguage = 
            "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
        final String aSchemaSource   = "http://java.sun.com/xml/jaxp/properties/schemaSource";
    
        try {
            sParser.setProperty(aSchemaLanguage, "http://www.w3.org/2001/XMLSchema");
            fail("---- Set schemaLanguage: " + sParser.getProperty(aSchemaLanguage));
        } catch( SAXException e ) {
            ; // as expected
        }
        
        try {
           sParser.setProperty(aSchemaSource, new InputSource(new StringReader(schemaSource)));
           fail("---- Set schemaSource: "+ sParser.getProperty(aSchemaSource));
        } catch (SAXException e) {
            ; // as expected
        }
    }
}
