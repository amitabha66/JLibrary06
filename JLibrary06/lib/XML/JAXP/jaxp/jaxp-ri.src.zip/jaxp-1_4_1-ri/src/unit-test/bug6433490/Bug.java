/*
 * Bug.java
 *
 * Created on October 22, 2005, 10:33 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6433490;

/**
 *
 * @author Norman Walsh
 */

import java.io.*;

import javax.xml.parsers.*;
import org.xml.sax.*;
import org.w3c.dom.Document;
import javax.xml.XMLConstants;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    DocumentBuilderFactory dbf = null;
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name );
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    /* URIs with spaces are supposed to be OK now.
     */
    public void testUnescapedURI()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("space sample.xml"));
        }catch(Exception e){
            fail("Exception " + e.getMessage());
        }
    }

}
