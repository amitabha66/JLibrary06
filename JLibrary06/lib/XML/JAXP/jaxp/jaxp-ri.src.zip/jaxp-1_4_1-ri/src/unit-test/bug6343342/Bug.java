/*
 * Main.java
 *
 * Created on August 4, 2006, 10:46 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6343342;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {

    public void test() {
	Class cls;

	try {
	    cls = Class.forName("com.sun.org.apache.xalan.internal.xsltc.runtime.CallFunction");
	} 
        catch (ClassNotFoundException cnfe) {
	    return;
	}
	throw new RuntimeException("Test failed. Bug exists");
    }
    
    public static void main(String[] args) {
        new Bug().test();
    }
}
