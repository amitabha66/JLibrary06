/*
 * Bug.java
 *
 * Created on February 2, 2006, 11:43 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6378112;

/**
 *
 * @author Sunitha Reddy
 */
import javax.xml.validation.*;

import java.io.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    static String SCHEMA_LANG = "http://www.w3.org/2001/XMLSchema";
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
         super(name);
    }   
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testSelectorXPath(){
        try{
            Schema schema = SchemaFactory.newInstance(SCHEMA_LANG).newSchema(this.getClass().getResource("idI009.xsd"));
        }catch(Exception e){
          e.printStackTrace();
          fail("Exception occured: "+e.getMessage());
        }
    }
}
