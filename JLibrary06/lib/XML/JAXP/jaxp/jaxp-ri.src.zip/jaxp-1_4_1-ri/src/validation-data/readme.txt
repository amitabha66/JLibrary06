This directory stores test data for the validation batch test.
