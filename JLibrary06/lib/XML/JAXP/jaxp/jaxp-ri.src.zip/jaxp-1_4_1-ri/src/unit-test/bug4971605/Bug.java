/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:24:59 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4971605;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    public void test1() throws Exception {
        String xsd =
            "<?xml version='1.0'?>\n"
                + "<schema xmlns='http://www.w3.org/2001/XMLSchema'\n"
                + "        xmlns:test='jaxp13_test1'\n"
                + "        targetNamespace='jaxp13_test1'\n"
                + "        elementFormDefault='qualified'>\n"
                + "    <element name='test'/>\n"
                + "</schema>\n";

        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        docBuilderFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        
        Node document = docBuilder.parse(new InputSource(new StringReader(xsd)));
        assertNotNull(document);
        
        SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        Schema schema = schemaFactory.newSchema(new Source[] { new DOMSource(document) });
        assertNotNull("Failed: newSchema returned null.",schema);
    }
}