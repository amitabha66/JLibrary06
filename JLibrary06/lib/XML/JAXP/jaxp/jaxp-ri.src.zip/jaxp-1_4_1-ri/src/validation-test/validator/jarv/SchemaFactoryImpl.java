/*
 * @(#)$Id: SchemaFactoryImpl.java,v 1.1 2005/06/10 04:23:42 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package validator.jarv;

import java.io.IOException;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.iso_relax.verifier.VerifierConfigurationException;
import org.iso_relax.verifier.VerifierFactory;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
class SchemaFactoryImpl extends SchemaFactory {

    private VerifierFactory factory;

    SchemaFactoryImpl(VerifierFactory factory) {
        this.factory = factory;
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
    }

    public ErrorHandler getErrorHandler() {
        return null;
    }

    public void setResourceResolver(LSResourceResolver resourceResolver) {
    }

    public LSResourceResolver getResourceResolver() {
        return null;
    }

    public Schema newSchema(Source[] schemas) throws SAXException {
        if( schemas.length!=1 )
            throw new UnsupportedOperationException();
        StreamSource s = (StreamSource)schemas[0];
        try {
            return new SchemaImpl( factory.compileSchema(toInputSource(s)) );
        } catch (VerifierConfigurationException e) {
            throw new SAXException(e);
        } catch (IOException e) {
            throw new SAXException(e);
        }
    }

    public Schema newSchema() throws SAXException {
        throw new UnsupportedOperationException();
    }

    public static final InputSource toInputSource( StreamSource in ) {
        if( in.getReader()!=null )
            return new InputSource(in.getReader());
        if( in.getInputStream()!=null )
            return new InputSource(in.getInputStream());
        
        return new InputSource(in.getSystemId());
    }
}
