/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:25:04 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4997818;

import java.io.StringReader;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    public void test1() throws Exception {
        String xsd1 = "<?xml version='1.0'?>\n"
            + "<schema xmlns='http://www.w3.org/2001/XMLSchema'\n"
            + "        xmlns:test='jaxp13_test1'\n"
            + "        targetNamespace='jaxp13_test1'\n"
            + "        elementFormDefault='qualified'>\n"
            + "    <import namespace='jaxp13_test2'/>\n"
            + "    <element name='test'/>\n"
            + "    <element name='child1'/>\n"
            + "</schema>\n";

        final NullPointerException EUREKA = new NullPointerException("NewSchema015");
        
        SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        StringReader reader = new StringReader(xsd1);
        StreamSource source = new StreamSource(reader);
        LSResourceResolver resolver = new LSResourceResolver() {
            public LSInput resolveResource(String type, String namespaceURI,
                    String publicId, String systemId, String baseURI) {
                LSInput input;
                if (namespaceURI != null && namespaceURI.endsWith("jaxp13_test2")) {
                    throw EUREKA;
                } else {
                    input = null;
                }

                return input;
            }
        };
        schemaFactory.setResourceResolver(resolver);

        try {
            schemaFactory.newSchema(new Source[] {source});
            fail("NullPointerException was not thrown.");
        } catch (RuntimeException e) {
            if(e!=EUREKA)   throw e;
        }
    }
}