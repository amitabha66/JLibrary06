package javax.xml.stream.XMLStreamReaderTest;

import junit.framework.TestCase;

import java.io.StringReader;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;


import junit.textui.TestRunner;
/**
 * See bug 6389307.
 * 
 * @author Kohsuke Kawaguchi
 */
public class DoubleXmlnsTest extends TestCase {

    public static void main(String[] args) {
    	TestRunner.run(DoubleXmlnsTest.class);
    }

    public void testDoubleNS() throws Exception {

        final String INVALID_XML =
                "<foo xmlns:xmli='http://www.w3.org/XML/1998/namespacei' xmlns:xmli='http://www.w3.org/XML/1998/namespacei' />";
        
        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(INVALID_XML));

            while(xsr.hasNext()) {
                xsr.next();
            }

            fail("Wellformedness error expected: "
                    + INVALID_XML);
        } catch (XMLStreamException e) {
            ; // this is expected
        }
    }
        
    public void testNestedNS() throws Exception {

        final String VALID_XML =
                "<foo xmlns:xmli='http://www.w3.org/XML/1998/namespacei'><bar xmlns:xmli='http://www.w3.org/XML/1998/namespaceii'></bar></foo>";

        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(VALID_XML));
            
            while(xsr.hasNext()) {
                xsr.next();
            }

            // expected success
        } catch (XMLStreamException e) {
            e.printStackTrace();

            fail("Wellformedness error is not expected: "
                    + VALID_XML
                    + ", "
                    + e.getMessage());
        }
    }
    
    public void testDoubleXmlns() throws Exception {

        final String INVALID_XML =
                "<foo xmlns:xml='http://www.w3.org/XML/1998/namespace' xmlns:xml='http://www.w3.org/XML/1998/namespace' ></foo>";

        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(INVALID_XML));
           
            while(xsr.hasNext()) {
                xsr.next();
            }

            fail("Wellformedness error expected :"
                    + INVALID_XML);
        } catch (XMLStreamException e) {
            ; // this is expected
        }
    }
    
    public void testNestedXmlns() throws Exception {
        
        final String VALID_XML =
                "<foo xmlns:xml='http://www.w3.org/XML/1998/namespace'><bar xmlns:xml='http://www.w3.org/XML/1998/namespace'></bar></foo>";

        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(VALID_XML));
           
            while(xsr.hasNext()) {
                xsr.next();
            }

            // expected success
        } catch (XMLStreamException e) {
            e.printStackTrace();
           fail("Wellformedness error is not expected: "
                   + VALID_XML
                   + ", "
                   + e.getMessage()); 
        }
    }
}
