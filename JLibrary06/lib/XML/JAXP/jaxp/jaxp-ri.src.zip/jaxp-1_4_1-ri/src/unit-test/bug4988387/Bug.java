/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:23:25 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4988387;

import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    public void test1() throws Exception {
        SchemaFactory schemaFactory =
            SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");

        try {
            schemaFactory.newSchema(Bug.class.getResource("test.xsd"));
            fail("incorrect XPath processed");
        } catch( SAXException e ) {
            assertTrue(e.getMessage().startsWith("c-general-xpath"));
        }
    }
}