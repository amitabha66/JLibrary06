/*
 * DOMSerialize.java
 *
 * Created on November 18, 2005, 4:33 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

/**
 *
 * @author Sunitha Reddy
 */
package bug6339023;

import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.w3c.dom.ls.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    /** Creates a new instance of DOMSerialize */
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    /* This test checks DOMConfiguration for DOM Level3 Load and Save implementation.
     */
    public void testLSSerializer(){
        try{
            DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            DOMImplementation impln = parser.getDOMImplementation();
            DOMImplementationLS lsImpln = (DOMImplementationLS)impln.getFeature("LS","3.0");
            LSSerializer serializer = lsImpln.createLSSerializer();
            DOMConfiguration domConfig = serializer.getDomConfig();
            System.out.println("DOMConfig: "+domConfig.toString());
            assertTrue(domConfig.getParameter("normalize-characters") == null);
            System.out.println("value: "+domConfig.getParameter("normalize-characters"));

            DOMStringList list = domConfig.getParameterNames();
            for (int i=0; i<list.getLength(); i++){
                System.out.println("Param Name: "+list.item(i));
                assertFalse(list.item(i).equals("normalize-characters"));
            }
            
            assertFalse(domConfig.canSetParameter("normalize-characters", Boolean.FALSE));
            assertFalse(domConfig.canSetParameter("normalize-characters", Boolean.TRUE));
            
            try{
                domConfig.setParameter("normalize-characters",Boolean.TRUE);
                fail("Exception expected as 'normalize-characters' is not supported");
            }catch(Exception e){}
            
            try{
                domConfig.setParameter("normalize-characters",Boolean.FALSE);
                fail("Exception expected as 'normalize-characters' is not supported");
            }catch(Exception e){}
            
        }catch(Exception e)
        {
            e.printStackTrace();
            fail("Exception: "+e.getMessage());
        }
    }
    
    /* This test checks DOMConfiguration for DOM Level3 Core implementation.
     */
    public void testLSParser(){
        try{
            DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            DOMImplementation impln = parser.getDOMImplementation();
            DOMImplementationLS lsImpln = (DOMImplementationLS)impln.getFeature("Core","3.0");
            LSParser lsparser = lsImpln.createLSParser(DOMImplementationLS.MODE_SYNCHRONOUS,"http://www.w3.org/2001/XMLSchema");
            DOMConfiguration domConfig = lsparser.getDomConfig();
            System.out.println("DOMConfig: "+domConfig.toString());
            assertTrue(domConfig.getParameter("normalize-characters").toString().equalsIgnoreCase("false"));
            System.out.println("value: "+domConfig.getParameter("normalize-characters"));

            DOMStringList list = domConfig.getParameterNames();
            boolean flag = false;
            for (int i=0; i<list.getLength(); i++){
                System.out.println("Param Name: "+list.item(i));
                if (list.item(i).equals("normalize-characters")){
                    flag = true;
                    break;
                }
            }
            assertTrue("'normalize-characters' doesnot exist in the list returned by domConfig.getParameterNames()", flag);
            
            assertTrue(domConfig.canSetParameter("normalize-characters", Boolean.FALSE));
            assertFalse(domConfig.canSetParameter("normalize-characters", Boolean.TRUE));
            
            try{
                domConfig.setParameter("normalize-characters",Boolean.TRUE);
                fail("Exception expected as 'normalize-characters' is not supported");
            }catch(Exception e){}
            
            try{
                domConfig.setParameter("normalize-characters",Boolean.FALSE);
            }catch(Exception e){
                e.printStackTrace();
                fail("Exception expected as 'normalize-characters' is not supported");
            }
            
        }catch(Exception e)
        {
            e.printStackTrace();
            fail("Exception: "+e.getMessage());
        }
    }
   
}
