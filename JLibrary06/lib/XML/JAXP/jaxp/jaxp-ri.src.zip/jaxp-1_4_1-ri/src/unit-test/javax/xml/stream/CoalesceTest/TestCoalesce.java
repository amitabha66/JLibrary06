/*
 * TestCoalesce.java
 *
 * Created on April 27, 2004, 3:30 PM
 */

package javax.xml.stream.CoalesceTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author  nb131165
 */
public class TestCoalesce extends TestCase {
    
    String countryElementContent =  "START India  CS}}}}}} India END" ;
    String descriptionElementContent =  "a&b" ;
    String fooElementContent = "&< cdatastart<><>>><>><<<<cdataend entitystart insert entityend";
    
    /** Creates a new instance of TestCoalesce */
    public TestCoalesce(String name) {
        super(name);
    }
    
    public void testCoalesceProperty(){
        try{
            XMLInputFactory xifactory = XMLInputFactory.newInstance() ;
            xifactory.setProperty(XMLInputFactory.IS_COALESCING, new Boolean(true)) ;
            File file = new File("./tests/Coalesce/coalesce.xml") ;            
            InputStream xml = new FileInputStream(file);
            XMLStreamReader streamReader = xifactory.createXMLStreamReader(xml);
            while(streamReader.hasNext()){
                int eventType = streamReader.next() ;
                if(eventType == XMLStreamConstants.START_ELEMENT && streamReader.getLocalName().equals("country")){
                    eventType = streamReader.next() ;
                    if(eventType == XMLStreamConstants.CHARACTERS){
                        String text = streamReader.getText() ;
                        if(!text.equals(countryElementContent)){
                            System.out.println("String dont match");
                            System.out.println("text = " + text ) ;
                            System.out.println("countryElementContent = " + countryElementContent);
                        }
                        //assertTrue(text.equals(countryElementContent));
                    }
                }
                if(eventType == XMLStreamConstants.START_ELEMENT && streamReader.getLocalName().equals("description")){
                    eventType = streamReader.next() ;
                    if(eventType == XMLStreamConstants.CHARACTERS){
                        String text = streamReader.getText() ;                        
                        if(!text.equals(descriptionElementContent)){
                            System.out.println("String dont match");
                            System.out.println("text = " + text ) ;
                            System.out.println("descriptionElementContent = " + descriptionElementContent);
                        }                        
                        assertTrue(text.equals(descriptionElementContent));
                    }
                }
                if(eventType == XMLStreamConstants.START_ELEMENT && streamReader.getLocalName().equals("foo")){
                    eventType = streamReader.next() ;
                    if(eventType == XMLStreamConstants.CHARACTERS){
                        String text = streamReader.getText() ;                        
                        if(!text.equals(fooElementContent)){
                            System.out.println("String dont match");
                            System.out.println("text = " + text ) ;
                            System.out.println("fooElementContent = " + fooElementContent);
                        }

                        assertTrue(text.equals(fooElementContent));
                    }
                }
                
            }
        }
        catch(XMLStreamException ex){

            if( ex.getNestedException() != null){
                ex.getNestedException().printStackTrace();
            }
            //ex.printStackTrace() ;
        }    
        catch(Exception ex){
            ex.printStackTrace() ;
        }    
        
    }
    
    public static void main(String [] args){
        TestRunner.run(TestCoalesce.class);
    }
}
