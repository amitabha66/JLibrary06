/*
 * Bug.java
 *
 * Created on December 30, 2005, 12:51 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6290947;

/**
 *
 * @author Sunitha Reddy
 */
import java.io.*;
import java.io.StringBufferInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSParser;
import org.w3c.dom.ls.LSSerializer;
import org.w3c.dom.ls.LSSerializerFilter;
import org.w3c.dom.traversal.NodeFilter;
import org.xml.sax.SAXException;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    private static String XML_STRING = "<?xml version=\"1.0\"?><ROOT><ELEMENT1><CHILD1/><CHILD1><COC1/></CHILD1></ELEMENT1><ELEMENT2>test1<CHILD2/></ELEMENT2></ROOT>";
    private static DOMImplementationLS implLS;
    private final String XML_FILE_INTERNAL_DTD = "note_in_dtd.xml";
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
         super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testStringSourceWithXmlDecl() {
        String result = prepare(XML_STRING, true);
        System.out.println("testStringSource: output: "+result);
        assertTrue("XML Declaration expected in output", !result.trim().equals(""));
    }
    
    public void testStringSourceWithOutXmlDecl() {
        String result = prepare(XML_STRING, false);
        System.out.println("testStringSource: output: "+result);
        assertTrue("XML Declaration is not expected in output", result.trim().equals(""));
    }
    
    public void testXmlWithInternalDTD1() {
        String result = prepare(XML_FILE_INTERNAL_DTD, true);
        System.out.println("testStringSource: output: "+result);
        assertTrue("XML Declaration and DTD are expected in output", !result.trim().equals(""));
    }
    
    public void testXmlWithInternalDTD2() {
        String result = prepare(XML_FILE_INTERNAL_DTD, false);
        System.out.println("testStringSource: output: "+result);
        assertTrue("DTD is expected in output", !result.trim().equals(""));
    }
    
    private String prepare(String source, boolean xmlDeclFlag){
        Document startDoc = null;
        DocumentBuilder domParser = null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            domParser = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }

        final StringBufferInputStream is = new StringBufferInputStream(
                XML_STRING);
        try {
            startDoc = domParser.parse(is);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        } 

        DOMImplementation impl = startDoc.getImplementation();
        implLS = (DOMImplementationLS) impl.getFeature("LS", "3.0");
        LSParser parser = implLS.createLSParser(
                DOMImplementationLS.MODE_SYNCHRONOUS,
                "http://www.w3.org/2001/XMLSchema");

        LSInput src = getXmlSource(source);

        LSSerializer writer = implLS.createLSSerializer();

        DOMConfiguration conf = writer.getDomConfig();
        conf.setParameter("xml-declaration", Boolean.valueOf(xmlDeclFlag));

        // set filter
        writer.setFilter(new LSSerializerFilter(){
            public short acceptNode(Node enode) {
                return FILTER_REJECT;
		
            }

            public int getWhatToShow() {
                return NodeFilter.SHOW_ELEMENT;
            }
        });

        Document doc = parser.parse(src);
        return writer.writeToString(doc);
    }
    
    private LSInput getXmlSource(String xml1) {
        LSInput src = implLS.createLSInput();
        try{
            if (xml1.endsWith(".xml"))
                src.setByteStream(this.getClass().getResourceAsStream(XML_FILE_INTERNAL_DTD));
            else
                src.setStringData(xml1);
        }catch(Exception e){
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }
        return src;
    }
}
