/*
 * Bug.java
 *
 * Created on December 30, 2005, 1:19 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6354955;

/**
 *
 * @author Sunitha Reddy
 */
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;


import org.w3c.dom.*;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testTextNode(){
      try{
          Document xmlDocument = createNewDocument();

          String whitespace = "\r\n    ";
          Text textNode = xmlDocument.createTextNode(whitespace);

          System.out.println("original text is:\r\n\"" + whitespace + "\"");
          String outerXML = getOuterXML(textNode);
          System.out.println("OuterXML Text Node is:\r\n\"" + outerXML + "\"");

      }catch(Exception e){
          e.printStackTrace();
          fail("Exception occured: "+e.getMessage());
      }
    }
    
    public void testCommentNode(){
      try{
          Document xmlDocument = createNewDocument();
          String commentStr = "This is a comment node";
          Comment cmtNode = xmlDocument.createComment(commentStr);
          String outerXML = getOuterXML(cmtNode);
          System.out.println("OuterXML of Comment Node is:" + outerXML );

      }catch(Exception e){
          e.printStackTrace();
          fail("Exception occured: "+e.getMessage());
      }
    }
    
    public void testPINode(){
      try{
          Document xmlDocument = createNewDocument();
          ProcessingInstruction piNode = xmlDocument.createProcessingInstruction("execute","test");
          String outerXML = getOuterXML(piNode);
          System.out.println("OuterXML of Comment Node is:" + outerXML );

      }catch(Exception e){
          e.printStackTrace();
          fail("Exception occured: "+e.getMessage());
      }
    }
    
    public void testCDATA(){
      try{
          Document xmlDocument = createNewDocument();
          CDATASection cdataNode = xmlDocument.createCDATASection("See Data!!");
          String outerXML = getOuterXML(cdataNode);
          System.out.println("OuterXML of Comment Node is:" + outerXML );

      }catch(Exception e){
          e.printStackTrace();
          fail("Exception occured: "+e.getMessage());
      }
    }
    
    public void testEntityReference(){
      try{
          Document xmlDocument = createNewDocument();
          EntityReference erefNode = xmlDocument.createEntityReference("entityref");
          String outerXML = getOuterXML(erefNode);
          System.out.println("OuterXML of Comment Node is:" + outerXML );

      }catch(Exception e){
          e.printStackTrace();
          fail("Exception occured: "+e.getMessage());
      }
    }
    
    private String getOuterXML (Node node) {
        DOMImplementationLS domImplementation = (DOMImplementationLS) node.getOwnerDocument().getImplementation();
        LSSerializer lsSerializer = domImplementation.createLSSerializer();
        if (!(node instanceof Document)) {
          lsSerializer.getDomConfig().setParameter("xml-declaration", false);
        }
        return lsSerializer.writeToString(node);
   }
    
    private Document createNewDocument() throws Exception{
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      documentBuilderFactory.setNamespaceAware(true);
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      return documentBuilder.newDocument();
    }
}
