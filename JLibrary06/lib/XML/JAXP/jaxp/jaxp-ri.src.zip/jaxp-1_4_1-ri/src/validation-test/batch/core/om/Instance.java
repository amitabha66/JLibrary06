/*
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package batch.core.om;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.net.URL;
import java.util.Iterator;
import java.util.Properties;

import org.dom4j.Element;

import bsh.Interpreter;
import bsh.TargetError;

/**
 * Represents an instance document to be used for testing.
 * An instance contains an XML instance document and a bunch
 * of properties.
 */
public class Instance {
    public final URL document;
    public final Properties properties = new Properties();

    /** Creates a test instance without any property value. */
    public Instance( URL _document ) {
        this.document = _document;
    }

    /** Creates a test instance without any property value. */
    public Instance( File _document ) throws IOException {
        this.document = _document.toURL();
    }
    
    /** Creates a test instance from a spec meta file. */
    public Instance( URL baseUrl, Element instance ) throws IOException {
        this( new URL(baseUrl,instance.attributeValue("href")) );
            
        Iterator itr = instance.elementIterator("property");
        while(itr.hasNext()) {
            Element p = (Element)itr.next();
            properties.put(
                p.attributeValue("name"),
                p.elementText("value"));
        }
    }
    
    public Instance( URL _document, Properties params ) {
        this( _document );
        properties.entrySet().addAll( params.entrySet() );
    }
        
    public String getName() {
        return document.toExternalForm();
    }
    





    

    /**
     * Executes the specified JavaScript with this instance.
     * 
     * @param clsLoader, packageName
     *      Import this Java package into the script scope before running
     *      the script. This would make it easy for scripts to access
     *      generated classes directly.
     */
    public void runScript( Interpreter interpreter, Reader script ) throws Exception {
        // run
        try {
            interpreter.eval( script );
        } catch( TargetError e ) {
            Throwable t = e.getTarget();
            if(t instanceof Exception)
                throw (Exception)t;
            if( t instanceof Error)
                throw (Error)t;
            throw e;
        }
    }
}
