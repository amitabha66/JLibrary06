/*
 * Test.java
 *
 * Created on February 12, 2007, 10:42 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6520131;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMError;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 * Unit test for CR 6520131. This bug was actually closed as "Not a Defect".
 * However, it took me some time to figure out how to set up the DOM to
 * report the error, so I think this unit test is still useful.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {
    
    public static void main(String [] args){
        TestRunner.run(Test.class);
    }
    
    public Test() {
    }
    
    public void test()  {
        String string = new String("\u0001");
        
        try {
            // create document
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
            Document document = documentBuilder.newDocument();
            
            DOMConfiguration domConfig = document.getDomConfig();
            domConfig.setParameter("well-formed", Boolean.TRUE);
            domConfig.setParameter("error-handler", new DOMErrorHandler() {
                public boolean handleError(DOMError e) {
                    throw new RuntimeException(e.getMessage());
                }
            });
            
            // add text element
            Element textElement = document.createElementNS("", "Text");
            Text text = document.createTextNode(string);
            textElement.appendChild(text);
            document.appendChild(textElement);
            
            // normalize document
            document.normalizeDocument();            
            
            fail("Invalid character exception not thrown");
        } 
        catch (ParserConfigurationException e) {
            fail("Unable to configure parser");            
        }
        catch (RuntimeException e) {
            // This exception is expected!
        }
    }
}