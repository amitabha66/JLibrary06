/**
 * Synopsis: getNamespaceURi(index) and getNamespacePrefix(index) returns invalid values.
 */
package bug6481678;

import java.io.File;
import java.io.StringReader;
import java.io.InputStream;

import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;

import javax.xml.stream.EventFilter;
import javax.xml.stream.StreamFilter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import javax.xml.stream.XMLStreamConstants;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author joe.wang@sun.com
 */
public class Bug  extends TestCase{
    
    String rootElement = "fruits";
    String childElement = "varieties" ;
    String prefixApple = "a" ;
    String namespaceURIApple = "apple.fruit" ;
    String prefixOrange = "o" ;
    String namespaceURIOrange = "orange.fruit" ;
    String namespaceURIBanana = "banana.fruit" ;
    
    TypeFilter filter;
    XMLInputFactory factory;
    InputStream is;
    
    /** Creates a new instance of NamespaceTest */
    public Bug(java.lang.String testName) {
        super(testName) ;
        init();
    }
    
    private void init() {
        factory = XMLInputFactory.newInstance() ;
        factory.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE) ;
        is = new java.io.ByteArrayInputStream(getXML().getBytes());
        filter = createFilter(); 
    }
    String getXML(){
        StringBuffer sbuffer = new StringBuffer() ;
        sbuffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        sbuffer.append("<" + rootElement + " state=\"WA\"") ;
        sbuffer.append(" xmlns:" + prefixApple + "=\"" +  namespaceURIApple + "\"");
        sbuffer.append(" xmlns:" + prefixOrange + "=\"" +  namespaceURIOrange + "\"");
        sbuffer.append(" xmlns=\"" +  namespaceURIBanana + "\">");
        sbuffer.append("<" + prefixApple + ":" + childElement + ">");
        sbuffer.append("<" + prefixApple + ":fuji/>");
        sbuffer.append("<" + prefixApple + ":gala/>");
        sbuffer.append("</" + prefixApple + ":" + childElement + ">");            
        sbuffer.append("</" + rootElement + ">");
        //System.out.println("XML = " + sbuffer.toString()) ;
        return sbuffer.toString();
    }

    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    public TypeFilter createFilter() {

        TypeFilter f = new TypeFilter();

        f.addType(XMLEvent.START_ELEMENT);
        f.addType(XMLEvent.END_ELEMENT);
        f.addType(XMLEvent.PROCESSING_INSTRUCTION);
        f.addType(XMLEvent.CHARACTERS);
        f.addType(XMLEvent.COMMENT);
        f.addType(XMLEvent.SPACE);
        f.addType(XMLEvent.START_DOCUMENT);
        f.addType(XMLEvent.END_DOCUMENT);
        return f;
    }
    
    /* testcase for cr6481678
     * in our current impl (using cache), the reader would read from cache when getters are called before next() is. 
     * refter to testRootElementNamespace.
     */
    public void testReadingNamespace(){
        try{
            XMLStreamReader sr = factory.createFilteredReader(factory.createXMLStreamReader(is), (StreamFilter)filter);

            while(sr.hasNext()){
                int eventType = sr.getEventType();
                if(eventType == XMLStreamConstants.START_ELEMENT){
                    if(sr.getLocalName().equals(rootElement)){  
                        assertTrue(sr.getNamespacePrefix(0).equals(prefixApple) && sr.getNamespaceURI(0).equals(namespaceURIApple));
                    }
                }        
                eventType = sr.next() ;
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    
    public void testRootElementNamespace(){
        try{
            XMLStreamReader sr = factory.createFilteredReader(factory.createXMLStreamReader(is), (StreamFilter)filter);

            while(sr.hasNext()){
                int eventType = sr.next() ;
                if(eventType == XMLStreamConstants.START_ELEMENT){
                    if(sr.getLocalName().equals(rootElement)){    
                        assertTrue(sr.getNamespacePrefix(0).equals(prefixApple) && sr.getNamespaceURI(0).equals(namespaceURIApple));
                    }
                }        
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    
    public void testChildElementNamespace(){
        try{
            XMLStreamReader sr = factory.createFilteredReader(factory.createXMLStreamReader(is), (StreamFilter)filter);
            while(sr.hasNext()){
                int eventType = sr.next() ;
                if(eventType == XMLStreamConstants.START_ELEMENT){
                    if(sr.getLocalName().equals(childElement)){                    
                        QName qname = sr.getName();
                        assertTrue(qname.getPrefix().equals(prefixApple) && qname.getNamespaceURI().equals(namespaceURIApple) && qname.getLocalPart().equals(childElement));
                    }
                }        
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    
    
    public void testNamespaceContext(){
        try{
            XMLStreamReader sr = factory.createFilteredReader(factory.createXMLStreamReader(is), (StreamFilter)filter);
            while(sr.hasNext()){
                int eventType = sr.next() ;
                if(eventType == XMLStreamConstants.START_ELEMENT){
                    if(sr.getLocalName().equals(childElement)){
                    NamespaceContext context = sr.getNamespaceContext() ; 
                    assertTrue(context.getPrefix(namespaceURIApple).equals(prefixApple));
                    }
                }        
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    
    public void testNamespaceCount(){
        try{
            XMLStreamReader sr = factory.createFilteredReader(factory.createXMLStreamReader(is), (StreamFilter)filter);
            while(sr.hasNext()){
                int eventType = sr.next() ;
                if(eventType == XMLStreamConstants.START_ELEMENT){
                    if(sr.getLocalName().equals(rootElement)){
                    int count = sr.getNamespaceCount() ;                           
                    assertTrue(count == 3);
                    }
                }        
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }  
    
    class TypeFilter implements EventFilter, StreamFilter {

      protected boolean[] types= new boolean[20];

      public TypeFilter () {}

      public void addType(int type) {
        types[type]=true;
      }

      public boolean accept(XMLEvent e) {
        return types[e.getEventType()];
      }

      public boolean accept(XMLStreamReader r) {
        return types[r.getEventType()];
      }
    }    
}


    