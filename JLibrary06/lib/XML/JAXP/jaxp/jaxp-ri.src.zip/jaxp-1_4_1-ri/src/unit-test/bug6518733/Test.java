
package bug6518733;

import java.io.FileReader;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit test for CR 6518733. Make sure that the value of attribute 'q7' 
 * is "7 G". Due to a problem in Xerces, the value of attribute 'q8' 
 * was overwriting that of attribute 'q7'. 
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {
    
    public static void main(String [] args){
        TestRunner.run(Test.class);
    }
    
    public Test() {
    }
    
    public void test() {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try {
            SAXParser saxParser = factory.newSAXParser();
            saxParser.parse(new InputSource(new FileReader(
                    getClass().getResource("test.xml").getFile())),
                    new Handler());
        } 
        catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
    
    static class Handler extends org.xml.sax.helpers.DefaultHandler {        
        public void startElement(String uri, String localName, String qName,
                Attributes attrs) throws SAXException 
        {            
            // Make sure that the value of attribute q7 is "7 G"
            if (qName.equals("obj")) {
                assertTrue(attrs.getValue("", "q7").equals("7 G"));
            }            
        }        
    }
    
}