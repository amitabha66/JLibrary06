// StAX tests that are failing 

package javax.xml.stream.XMLStreamWriterTest;

import java.io.*;
import javax.xml.namespace.*;
import javax.xml.stream.*;

import junit.framework.TestCase;

public class EmptyElementTest extends TestCase {

    // expected output
    private static final String EXPECTED_OUTPUT =
            "<?xml version=\"1.0\" ?>"
            + "<hello xmlns=\"http://hello\">"
            + "<world xmlns=\"http://world\" prefixes=\"foo bar\"/>"
            + "</hello>";
    
    XMLStreamWriter xmlStreamWriter;
    ByteArrayOutputStream byteArrayOutputStream;
    XMLOutputFactory xmlOutputFactory ;

    public void testWriterOnLinux()
        throws Exception {

        // setup XMLStreamWriter
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();    
            xmlOutputFactory = XMLOutputFactory.newInstance();
            xmlOutputFactory.setProperty(xmlOutputFactory.IS_REPAIRING_NAMESPACES, new Boolean(true));
            xmlStreamWriter = xmlOutputFactory.createXMLStreamWriter(byteArrayOutputStream);
        } catch(Exception e) {
	    System.err.println("Unexpected Exception: " + e.toString());
            e.printStackTrace();
            fail(e.toString());
        }

        // create & write a document
        try {
            xmlStreamWriter.writeStartDocument();
            xmlStreamWriter.writeStartElement("hello");
            xmlStreamWriter.writeDefaultNamespace("http://hello");
            xmlStreamWriter.writeEmptyElement("world");
            xmlStreamWriter.writeDefaultNamespace("http://world");
            xmlStreamWriter.writeAttribute("prefixes", "foo bar");
            xmlStreamWriter.writeEndElement();
            xmlStreamWriter.writeEndDocument();
            xmlStreamWriter.flush();
            String actualOutput = byteArrayOutputStream.toString();
            assertEquals(EXPECTED_OUTPUT, actualOutput);
        } catch(Exception e) {
	    System.err.println("Unexpected Exception: " + e.toString());
            e.printStackTrace();
            fail(e.toString());
        }
    }
}
