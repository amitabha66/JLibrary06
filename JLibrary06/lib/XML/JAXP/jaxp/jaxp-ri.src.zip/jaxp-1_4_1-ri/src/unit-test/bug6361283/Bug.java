/*
 * Bug.java
 *
 * Created on December 9, 2005, 6:43 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6361283;

import java.io.*;
import javax.xml.parsers.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy
 */
public class Bug extends TestCase{
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testXMLVersion(){
        try{
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();
            assertTrue("use-locator2 should have value as true",factory.getFeature("http://xml.org/sax/features/use-locator2"));
            MyDefaultHandler dh = new MyDefaultHandler();
            parser.parse(this.getClass().getResourceAsStream("catalog.xml"),dh);
            assertTrue("XML Document version should be 1.1",dh.xmlVersion.equals("1.1"));
        }catch(Exception e){
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }
    }
}
