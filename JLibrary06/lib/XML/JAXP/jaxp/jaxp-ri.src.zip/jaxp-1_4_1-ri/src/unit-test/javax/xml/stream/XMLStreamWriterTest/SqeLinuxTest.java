// StAX tests that are failing 

package javax.xml.stream.XMLStreamWriterTest;

import java.io.*;
import javax.xml.namespace.*;
import javax.xml.stream.*;

import junit.framework.TestCase;

public class SqeLinuxTest extends TestCase {

    // note that expected output will have multiple declarations,
    // StAX does not do well formedness checking
    private static final String EXPECTED_OUTPUT =
            "<?xml version=\"1.0\" ?>"
            + "<?xml version=\"wStDoc_ver\"?>"
            + "<?xml version=\"wStDoc_ver2\" encoding=\"ASCII\"?>"
            + "<?xml version=\"1.0\" ?>";
    
    XMLStreamWriter xmlStreamWriter;
    ByteArrayOutputStream byteArrayOutputStream;
    XMLOutputFactory xmlOutputFactory ;

    public void testWriterOnLinux()
        throws Exception {

        // setup XMLStreamWriter
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();    
            xmlOutputFactory = XMLOutputFactory.newInstance();
            xmlOutputFactory.setProperty(xmlOutputFactory.IS_REPAIRING_NAMESPACES, new Boolean(false));
            xmlStreamWriter = xmlOutputFactory.createXMLStreamWriter(byteArrayOutputStream, "ASCII");
        } catch(Exception e) {
	    System.err.println("Unexpected Exception: " + e.toString());
            e.printStackTrace();
            fail(e.toString());
        }

        // create & write a document
        try {
            xmlStreamWriter.writeStartDocument();
            xmlStreamWriter.writeStartDocument("wStDoc_ver");
            xmlStreamWriter.writeStartDocument("ASCII", "wStDoc_ver2");
            xmlStreamWriter.writeStartDocument(null ,null);           
           
            // orignal SQE test used reset() before flush() 
            // believe this is false as reset() throws away output before flush() writes any cached output
            // it is valid for a XMLStreamWriter to write its output at any time, flush() just garuntees it
            // byteArrayOutputStream.reset();
            xmlStreamWriter.flush();
            assertEquals(EXPECTED_OUTPUT, byteArrayOutputStream.toString());
        } catch(Exception e) {
	    System.err.println("Unexpected Exception: " + e.toString());
            e.printStackTrace();
            fail(e.toString());
        }
    }
}
