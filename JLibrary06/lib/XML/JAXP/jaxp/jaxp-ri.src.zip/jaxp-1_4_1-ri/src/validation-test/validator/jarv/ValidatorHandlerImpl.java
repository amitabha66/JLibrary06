/*
 * @(#)$Id: ValidatorHandlerImpl.java,v 1.1 2005/06/10 04:23:42 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package validator.jarv;

import javax.xml.validation.TypeInfoProvider;
import javax.xml.validation.ValidatorHandler;

import org.iso_relax.verifier.Schema;
import org.iso_relax.verifier.Verifier;
import org.iso_relax.verifier.VerifierConfigurationException;
import org.iso_relax.verifier.impl.ForkContentHandler;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class ValidatorHandlerImpl extends ValidatorHandler {
    
    private final Verifier verifier;
    private ContentHandler receiver;
    private ContentHandler userReceiver;
    
    private ErrorHandler userErrorHandler;
    private LSResourceResolver userResourceResolver;
    private ErrorFilter errorFilter = new ErrorFilter();
    
    public ValidatorHandlerImpl(Schema schema) throws VerifierConfigurationException {
        verifier = schema.newVerifier();
        verifier.setErrorHandler(errorFilter);
    }

    public void setContentHandler(ContentHandler _receiver) {
        this.userReceiver = _receiver;
        try {
            if( receiver==null )
                receiver = verifier.getVerifierHandler();
            else
                receiver= new ForkContentHandler(verifier.getVerifierHandler(),userReceiver);
        } catch( SAXException e ) {
            // impossible
        }
    }
    
    public ContentHandler getContentHandler() {
        return userReceiver;
    }

    public boolean isValidSoFar() {
        return errorFilter.isValidSoFar();
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        errorFilter.setErrorHandler(errorHandler);
        userErrorHandler = errorHandler;
    }

    public ErrorHandler getErrorHandler() {
        return userErrorHandler;

    }

    public void setResourceResolver(LSResourceResolver resourceResolver) {
        userResourceResolver = resourceResolver;
    }

    public LSResourceResolver getResourceResolver() {
        return userResourceResolver;
    }

    public TypeInfoProvider getTypeInfoProvider() {
        return null;
    }
    /**
     * @param ch
     * @param start
     * @param length
     * @throws SAXException
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        receiver.characters(ch, start, length);
    }

    /**
     * @throws SAXException
     */
    public void endDocument() throws SAXException {
        receiver.endDocument();
    }

    /**
     * @param uri
     * @param localName
     * @param qName
     * @throws SAXException
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {
        receiver.endElement(uri, localName, qName);
    }

    /**
     * @param prefix
     * @throws SAXException
     */
    public void endPrefixMapping(String prefix) throws SAXException {
        receiver.endPrefixMapping(prefix);
    }

    /**
     * @param ch
     * @param start
     * @param length
     * @throws SAXException
     */
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        receiver.ignorableWhitespace(ch, start, length);
    }

    /**
     * @param target
     * @param data
     * @throws SAXException
     */
    public void processingInstruction(String target, String data) throws SAXException {
        receiver.processingInstruction(target, data);
    }

    /**
     * @param locator
     */
    public void setDocumentLocator(Locator locator) {
        receiver.setDocumentLocator(locator);
    }

    /**
     * @param name
     * @throws SAXException
     */
    public void skippedEntity(String name) throws SAXException {
        receiver.skippedEntity(name);
    }

    /**
     * @throws SAXException
     */
    public void startDocument() throws SAXException {
        receiver.startDocument();
    }

    /**
     * @param uri
     * @param localName
     * @param qName
     * @param atts
     * @throws SAXException
     */
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        receiver.startElement(uri, localName, qName, atts);
    }

    /**
     * @param prefix
     * @param uri
     * @throws SAXException
     */
    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        receiver.startPrefixMapping(prefix, uri);
    }

}
