/*
 * Bug.java
 *
 * Created on June 6, 2006, 6:20 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6350682;

import javax.xml.parsers.*;
import javax.xml.transform.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy
 */
public class Bug extends TestCase{
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
         super(name);
    }   
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testSAXParserFactory() {
        try{
            Thread.currentThread().setContextClassLoader(null);
            if (Bug.class.getClassLoader() == null)
                System.out.println("this class loader is NULL");
            else
                System.out.println("this class loader is NOT NULL");
            SAXParserFactory factory = SAXParserFactory.newInstance();
            assertTrue("Failed to get an instance of a SAXParserFactory", factory != null);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }
    }
    
     public void testTransformerFactory() {
        try{
            Thread.currentThread().setContextClassLoader(null);
            TransformerFactory factory = TransformerFactory.newInstance();
            assertTrue("Failed to get an instance of a TransformerFactory", factory != null);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        } catch (TransformerFactoryConfigurationError error){
            error.printStackTrace();
            fail(error.toString());
        }
    }
}
