/*
 * @(#)$Id: Main.java,v 1.1 2005/06/10 04:23:37 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import util.*;


/**
 * All-in-one test program.
 * 
 * <p>
 * This code simulates the typical use cases so that
 * we can test the whole scheme.
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class Main {

    public static void main(String[] args) throws Exception {
        
        if( args.length<2 ) {
            usage();
            return;
        }
        
        SchemaFactory factory = createGrammarFactory(args[0]);
        
        // create a grammar
        Schema grammar;
        if( args[1].equals("-") )       grammar = factory.newSchema();
        else                            grammar = factory.newSchema(new File(args[1]));
        
        if( args.length==2 ) {
            System.out.println("grammar parsed ("+grammar.getClass().getName()+")");
            return;            
        }
        
        // do the validation
        String mode = args[2].toUpperCase().intern();
        
        if( mode=="SAX" ) {
            doSAX(grammar,args);
            return;
        }
        if( mode=="DOM" ) {
            doDOM(grammar,args);
            return;
        }
        if( mode=="STANDALONE" ) {
            doStandalone(grammar,args);
            return;
        }
        
        usage();
    }

    private static void doStandalone(Schema grammar, String[] args) throws Exception {
        System.out.println("Using Validator for validation");
        Validator validator = grammar.newValidator();
        for( int i=3; i<args.length; i++ ) {
            System.out.println("parsing "+args[i]);
            validator.validate(new StreamSource(new File(args[i])));
        }
    }

    private static void doSAX(Schema grammar, String args[]) throws Exception {
        System.out.println("attaching grammar to SAX parser");
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setValidating(false);
        factory.setSchema(grammar);
        factory.setNamespaceAware(true);
        
        XMLReader reader = factory.newSAXParser().getXMLReader();
        reader.setErrorHandler(new ErrorReporter(System.err));
        reader.setContentHandler(new SAXWriter(System.out,"UTF-8"));
        
        for( int i=3; i<args.length; i++ ) {
            System.out.println("parsing "+args[i]);
            reader.parse(new InputSource(new File(args[i]).toURL().toExternalForm()));
        }
    }

    private static void doDOM(Schema grammar, String args[]) throws Exception {
        System.out.println("attaching grammar to DOM parser");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(false);
        factory.setSchema(grammar);
        factory.setNamespaceAware(true);
        
        DocumentBuilder parser = factory.newDocumentBuilder();
        for( int i=3; i<args.length; i++ ) {
            System.out.println("parsing "+args[i]);
            Document dom = parser.parse(new File(args[i]));
            new DOMWriter(System.out,"UTF-8").write(dom);
        }
    }

    private static SchemaFactory createGrammarFactory(String language) {
//        if( language.equals("DTD") )
//            language = "http://www.w3.org/XML/1998/namespace";
        if( language.equals("XSD") )
            language = "http://www.w3.org/2001/XMLSchema";

        return SchemaFactory.newInstance(language);
    }
    
    private static void usage() {
        System.out.println("Usage: Main <language> <schema> <mode> [<instances> ...]");
        System.out.println(
            "  <language>:\n" +
            "    either 'DTD' or 'XSD' to specify the schema language\n" +
            "  <schema>:\n" +
            "    the location of the schema file, or '-' to call newGrammar()\n" +
            "    for so-called passive grammar caching\n" +
            "  <mode>:\n" +
            "    'SAX' to attach a grammar to a SAXParser via SAXParserFactory.setGrammar\n" +
            "    'DOM' to attach a grammar to a DocumentBuilder via DBFactory.setGrammar\n" +
            "    'standalone' to use Validator from a Grammar\n" +
            "    if the mode is missing, the program just parses a schema.\n" +
            "  <instance>:\n" +
            "    instance documents that will be validated\n");
    }
}
