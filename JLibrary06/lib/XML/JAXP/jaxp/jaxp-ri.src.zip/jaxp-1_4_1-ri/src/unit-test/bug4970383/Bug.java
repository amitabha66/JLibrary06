/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:24:59 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4970383;

import javax.xml.validation.SchemaFactory;
import javax.xml.validation.ValidatorHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    public void test() throws Exception {
        SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        ValidatorHandler validatorHandler = schemaFactory.newSchema().newValidatorHandler();
        try {
            validatorHandler.setFeature(null, false);
            fail("should report an error");
        } catch (NullPointerException e) {
            ; // expected
        }
    }
}