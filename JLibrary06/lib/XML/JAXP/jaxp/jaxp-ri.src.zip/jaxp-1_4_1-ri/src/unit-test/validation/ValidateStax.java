/*
 * Validate.java
 *
 * Created on May 28, 2005, 3:02 PM
 */
package validation;

import java.util.*;
import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stax.StAXResult;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.ErrorHandler;

import javax.xml.stream.*;
import javax.xml.stream.events.* ;

/**
 *
 * @author  pv156767
 */
public class ValidateStax {
    
    /** Creates a new instance of Validate */
    public ValidateStax() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            // TODO code application logic here
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            System.out.println("schema factory instance obtained is " + sf);

            Schema schema = sf.newSchema(new File(args[0]));
            System.out.println("schema obtained is = " + schema);
            //Get a Validator which can be used to validate instance document against this grammar.
            Validator validator = schema.newValidator();
            ErrorHandler eh = new ErrorHandlerImpl();
            validator.setErrorHandler(eh);
            //Validate this instance document against the Instance document supplied   
            String fileName = args[1].toString();
            String fileName2 = args[2].toString();
            javax.xml.transform.Result xmlResult = new javax.xml.transform.stax.StAXResult(XMLOutputFactory.newInstance().createXMLStreamWriter(new FileWriter(fileName2)));
            javax.xml.transform.Source xmlSource = new javax.xml.transform.stax.StAXSource(getXMLEventReader(fileName));                                        
            //validator.validate(new StreamSource(args[1]));
            validator.validate(xmlSource, xmlResult);
        }catch(Exception ex){
            ex.printStackTrace();
            System.out.println("GET CAUSE");
            ex.getCause().fillInStackTrace();
        }
        
        
    }
    
    
    
    private static XMLEventReader getXMLEventReader(String filename){
    
    	XMLInputFactory xmlif = null ;
        XMLEventReader xmlr = null;
        try{
            xmlif = XMLInputFactory.newInstance();
            xmlif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,Boolean.FALSE);
            xmlif.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE , Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_COALESCING , Boolean.TRUE);
                        
            FileInputStream fis = new FileInputStream(filename);
            xmlr =  xmlif.createXMLEventReader(filename, fis);            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return xmlr;
    }    
    
}
