
package bug6465722;

import java.io.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import junit.framework.TestCase;

/**
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    private static final String IDENTITY_XSLT =
            "<xsl:stylesheet version='1.0' " +
            "xmlns:xsl='http://www.w3.org/1999/XSL/Transform'>" +
            "<xsl:template match='@*|node()'>" +
            "<xsl:copy>" +
            "<xsl:apply-templates select='@*|node()'/>" +
            "</xsl:copy>" +
            "</xsl:template>" +
            "</xsl:stylesheet>";
    
    public Bug() {
    }
    
    public static void main(String[] args) {
        new Bug().test();
    }
    
    public void test() {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            Document d = dbf.newDocumentBuilder().
                    getDOMImplementation().createDocument(null, "r", null);
            d.getDocumentElement().setAttributeNS("http://nowhere.net/", "id", "1");
            
            Transformer t = TransformerFactory.newInstance().newTransformer(
                    new StreamSource(new StringReader(IDENTITY_XSLT)));
            t.transform(new DOMSource(d), new StreamResult(new StringWriter()));
        } 
        catch (Throwable ex) {
            ex.printStackTrace();
        }
    }
    
}
