/*
 * @(#)$Id: Schema.java,v 1.1 2005/06/10 04:24:26 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package batch.core.om;

import java.net.URL;

/**
 * Information about the schema to be compiled.
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public final class Schema {
    
    
    /** Schema file(s) to be compiled. */
    public final URL schema;
    
    /** Schema language URI. */
    public final String language;
    
    /** True if the compilation is expected to fail. */
    public final boolean isNegativeTest;

    
    public Schema( URL schema, String language, boolean negativeTest ) {
        this.schema = schema;
        this.language = language;
        this.isNegativeTest = negativeTest;
    }
}