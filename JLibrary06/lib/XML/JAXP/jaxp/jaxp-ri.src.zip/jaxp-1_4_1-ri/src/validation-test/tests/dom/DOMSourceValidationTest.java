/*
 * @(#)$Id: DOMSourceValidationTest.java,v 1.1 2005/06/10 04:24:19 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package tests.dom;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Validator;

import junit.textui.TestRunner;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import tests.BaseTestCase;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class DOMSourceValidationTest extends BaseTestCase {
    public void testDOMSourceValidation() throws Exception {
        DocumentBuilder db = createDocumentBuilder();
        Document dom1 = db.parse(createStringSource("<root k='id'/>"));
        Document dom2 = db.parse(createStringSource("<root err='id'/>"));
        
        Validator v = loadXsdSchema("Test2.xsd").newValidator();
        v.validate(new DOMSource(dom1));
        try {
            v.validate(new DOMSource(dom2));
            fail();
        } catch( SAXException e ) {
            System.out.println(e.getMessage());
            // as expected
        }
    }

    private DocumentBuilder createDocumentBuilder() {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            return dbf.newDocumentBuilder();
        } catch( ParserConfigurationException e ) {
            e.printStackTrace();
            throw new InternalError();
        }
    }

    public static void main(String[] args) {
        TestRunner.run(DOMSourceValidationTest.class);
    }
}
