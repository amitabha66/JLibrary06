package javax.xml.parsers;

import java.io.File;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;

import org.xml.sax.helpers.DefaultHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit tests for: CR 4674384: Big value of maxOccurs of element declaration causes StackOverflowError
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 * 
 */

public class Bug4674384_MAX_OCCURS_Test extends TestCase {
		
	public static void main(String[] args) {
            
		TestRunner.run(Bug4674384_MAX_OCCURS_Test.class);
	}
	
    public final void testLargeMaxOccurs() {
        
        String XML_FILE_NAME = "./jaxp-ri/src/unit-test/javax/xml/parsers/Bug4674384_MAX_OCCURS_Test.xml";
        
        try {
            // create and initialize the parser
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(true);
            spf.setValidating(true);
            
            SAXParser parser = spf.newSAXParser();
            parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage",
                               "http://www.w3.org/2001/XMLSchema");

            File xmlFile = new File(XML_FILE_NAME);
            
            parser.parse(xmlFile, new DefaultHandler());
        } catch (Exception e) {
            System.err.println("Failure: File " + XML_FILE_NAME + " was parsed with a large value of maxOccurs.");
            e.printStackTrace();
            fail("Failure: File " + XML_FILE_NAME + " was parsed with a large value of maxOccurs.  "
                    + e.getMessage());
        }
        
        System.out.println("Success: File " + XML_FILE_NAME + " was parsed with a large value of maxOccurs.");
    }	
}