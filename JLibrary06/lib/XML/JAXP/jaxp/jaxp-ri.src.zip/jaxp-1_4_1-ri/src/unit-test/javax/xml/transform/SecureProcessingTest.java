/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: SecureProcessingTest.java,v 1.2 2007/01/28 05:04:07 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.transform;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;

import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * <p>Test SECURE_PROCESSING.</p>
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */
public class SecureProcessingTest extends TestCase {

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(SecureProcessingTest.class);
    }


    private static Document load(InputStream in)
	throws IOException {
        
        Document document = null;
        
	try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
	    DocumentBuilder db = dbf.newDocumentBuilder();
            document = db.parse(in);
	} catch (ParserConfigurationException parserConfigurationException) {
            parserConfigurationException.printStackTrace();
            fail(parserConfigurationException.toString());
	} catch (SAXException saxException) {
            saxException.printStackTrace();
            fail(saxException.toString());
	}

        return document;
    }

    
    /**
     * <p>Test stylesheet that uses a Java extension with SECURE_PROCESSING
     * turned on.</p>
     *
     */
    public final void testSecureProcessing() {

        // SECURE_PROCESSING == false

        // the style sheet
        InputStream  xslStream = this.getClass().getResourceAsStream("SecureProcessingTest.xsl");
        StreamSource xslSource = new StreamSource(xslStream);

        // the xml source
        InputStream  xmlStream = this.getClass().getResourceAsStream("SecureProcessingTest.xml");
        StreamSource xmlSource = new StreamSource(xmlStream);

        // the xml result
        StringWriter xmlResultString = new StringWriter();
        StreamResult xmlResultStream = new StreamResult(xmlResultString);

        // the transformer
        TransformerFactory transformerFactory = null;
        Transformer transformer = null;

        // transform with a non-secure Transformer
        // expect success
        try {
            transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            transformer = transformerFactory.newTransformer(xslSource);
            transformer.transform(xmlSource, xmlResultStream);
        } catch (TransformerConfigurationException ex) {
            ex.printStackTrace();
            fail(ex.toString());
        } catch (TransformerException ex) {
            ex.printStackTrace();
            fail(ex.toString());
        }

        // expected success
        // and the result is ...
        String xmlResult = xmlResultString.toString();
        System.out.println(
                "Transformation result (SECURE_PROCESSING == false) = \""
                + xmlResult
                + "\"");

        // now do same transformation but with SECURE_PROCESSING == true
        // expect Exception
        boolean exceptionCaught = false;
        
        // the style sheet
        xslStream = this.getClass().getResourceAsStream("SecureProcessingTest.xsl");
        xslSource = new StreamSource(xslStream);

        // the xml source
        xmlStream = this.getClass().getResourceAsStream("SecureProcessingTest.xml");
        xmlSource = new StreamSource(xmlStream);

        // the xml result
        xmlResultString = new StringWriter();
        xmlResultStream = new StreamResult(xmlResultString);

        // the transformer
        transformerFactory = null;
        transformer = null;

        // transform with a secure Transformer
        try {
            transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            transformer = transformerFactory.newTransformer(xslSource);
            transformer.transform(xmlSource, xmlResultStream);
        } catch (TransformerConfigurationException ex) {
            ex.printStackTrace();
            fail(ex.toString());
        } catch (TransformerException ex) {
            // expected failure
            System.out.println(
                    "expected failure: "
                    + ex.toString());
            ex.printStackTrace(System.out);
            exceptionCaught = true;
        }

        // unexpected success?
        if (!exceptionCaught) {
            // and the result is ...
            xmlResult = xmlResultString.toString();
            System.err.println(
                    "Transformation result (SECURE_PROCESSING == true) = \""
                    + xmlResult
                    + "\"");
            fail("SECURITY_PROCESSING == true, expected failure but got result: \""
                    + xmlResult
                    + "\"");
        }
    }
}
