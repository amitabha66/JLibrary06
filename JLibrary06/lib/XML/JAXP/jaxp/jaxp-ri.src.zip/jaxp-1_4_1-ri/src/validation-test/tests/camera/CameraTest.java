/*
 * @(#)$Id: CameraTest.java,v 1.1 2005/06/10 04:22:53 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package tests.camera;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParserFactory;

import junit.textui.TestRunner;

import org.apache.xerces.util.DraconianErrorHandler;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;

import tests.BaseTestCase;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class CameraTest extends BaseTestCase {
    
    public void testDomPrewire() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        dbf.setSchema(loadXsdSchema("Camera.xsd"));
        DocumentBuilder builder = dbf.newDocumentBuilder();
        builder.parse(createResourceSource("Camera.xml"));
        try {
            builder.parse(createResourceSource("Camera.err.xml"));
            fail();
        } catch( SAXParseException e ) { // as expected
            System.out.println(e.getMessage());
        }
    }
    
    public void testSaxPrewire() throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        spf.setSchema(loadXsdSchema("Camera.xsd"));
        
        XMLReader reader = spf.newSAXParser().getXMLReader();
        reader.setErrorHandler(DraconianErrorHandler.theInstance);
        
        reader.parse(createResourceSource("Camera.xml"));
        try {
            reader.parse(createResourceSource("Camera.err.xml"));
            fail();
        } catch( SAXParseException e ) { // as expected
            System.out.println(e.getMessage());
        }
    }
    
    public void testDomHintBased() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        dbf.setSchema(loadXsdSchema());
        DocumentBuilder builder = dbf.newDocumentBuilder();
        builder.parse(createResourceSource("Camera.xml"));
    }
    
    public void testSaxHintBased() throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        spf.setSchema(loadXsdSchema());
        
        XMLReader reader = spf.newSAXParser().getXMLReader();
        reader.setErrorHandler(DraconianErrorHandler.theInstance);
        
        reader.parse(createResourceSource("Camera.xml"));
        try {
            reader.parse(createResourceSource("Camera.err.xml"));
            fail();
        } catch( SAXParseException e ) { // as expected
            System.out.println(e.getMessage());
        }
    }
    
    
    public static void main(String[] args) {
    	TestRunner.run(CameraTest.class);
    }
}
