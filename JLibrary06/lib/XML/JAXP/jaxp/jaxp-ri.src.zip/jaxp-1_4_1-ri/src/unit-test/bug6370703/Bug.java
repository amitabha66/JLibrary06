/*
 * Bug.java
 *
 * Created on February 1, 2006, 11:14 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6370703;

/**
 *
 * @author Sunitha Reddy
 */
import java.io.FileInputStream;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    private static String INPUT_FILE = "sgml.xml";
    /** Creates a new instance of Bug */
    public Bug(String name) {
         super(name);
    }   
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testStartElement() {
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(this.getClass().getResource(INPUT_FILE).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE));
            
            while (xsr.hasNext()) {
                int event = xsr.next();
                if (event == XMLStreamReader.START_ELEMENT) {
                    String localName = xsr.getLocalName();
                    boolean print = "para".equals(localName);
                    int nrOfAttr = xsr.getAttributeCount();
                    if (print) { 
                        assertTrue("Default attribute declared in DTD is missing", nrOfAttr > 0);
                    }
                    
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }
    }
    
}
