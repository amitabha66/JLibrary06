/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: TransformerFactoryTest.java,v 1.1 2006/11/14 20:56:48 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.transform;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;

import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * <p>Test {@link javax.xml.transform.TransformerFactory}.</p>
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */
public class TransformerFactoryTest extends TestCase {

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(TransformerFactoryTest.class);
    }

    private static URIResolver resolver = new URIResolver() {
        
	    private int n = 0;
            
	    public Source resolve(String href, String base)
		throws TransformerException {
                
		System.out.println("resolving: " + href);
                
		if (n++ > 10) {
                    fail("Nesting too deep when resolving: " + href);
		}
                
		return new StreamSource(this.getClass().getResourceAsStream(href));
	    }
	};

    private static Document load(InputStream in)
	throws IOException {
        
        Document document = null;
        
	try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
	    DocumentBuilder db = dbf.newDocumentBuilder();
            document = db.parse(in);
	} catch (ParserConfigurationException parserConfigurationException) {
            parserConfigurationException.printStackTrace();
            fail(parserConfigurationException.toString());
	} catch (SAXException saxException) {
            saxException.printStackTrace();
            fail(saxException.toString());
	}

        return document;
    }

    
    /**
     * <p>Test stylesheets that import other stylesheets.</p>
     *
     * <p>Inspired by:
     * CR 6236727-2125981 XSLTC never stops resolving imported stylesheets
     * when outer stylesheet is a DOMSource</p>
     */
    public final void testImport() {

	TransformerFactory tff = TransformerFactory.newInstance();
	tff.setURIResolver(resolver);
	Templates tt = null;
        Transformer tf = null;
                
        // work-a-round is to use a StreamSource.
        // test should complete
        System.out.println("StreamSource: pre-Transformer creation");
        System.out.flush();  // in case import hangs
        try {
            InputStream xin = this.getClass().getResourceAsStream("outer.xsl");
            tt = tff.newTemplates(new StreamSource(xin));
            tf = tt.newTransformer();
        } catch (TransformerConfigurationException ex) {
            ex.printStackTrace();
            fail(ex.toString());
        }
        System.out.println("StreamSource: post-Transformer creation");
        
        // CR is that DOMSource never stops resolving
        System.out.println("DOMSource: pre-Transformer creation");
        System.out.flush();  // in case import hangs
        try {
            InputStream xin = this.getClass().getResourceAsStream("outer.xsl");
            tt = tff.newTemplates(new DOMSource(load(xin)));
            tf = tt.newTransformer();
        } catch (TransformerConfigurationException ex) {
            ex.printStackTrace();
            fail(ex.toString());
        } catch (IOException ioException) {
            ioException.printStackTrace();
            fail(ioException.toString());
        }
        System.out.println("DOMSource: post-Transformer creation");
    }
}
