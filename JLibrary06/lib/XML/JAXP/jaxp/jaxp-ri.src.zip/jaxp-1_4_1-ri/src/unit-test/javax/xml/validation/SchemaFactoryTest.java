/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: SchemaFactoryTest.java,v 1.2 2006/08/03 04:22:47 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.validation;

import javax.xml.XMLConstants;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import java.io.File;
import java.net.URI;

/**
 * Tests SchemaFactory.newInstance(URI).
 *
 * @author Jeff Suttor
 */
public class SchemaFactoryTest extends TestCase {

    public SchemaFactoryTest(String name) {
        super(name);
    }

    public static void main(String[] args) {

        TestRunner.run(SchemaFactoryTest.class);
    }

    /**
     * Test SchemaFactory.newInstance(URI).
     */
    public void testNewInstance() {

        // expected failure
        try {
            SchemaFactory sf = SchemaFactory.newInstance("invalidSchemaURI");

            // unexpected success
            fail("SchemaFactory "
                    + sf.getClass().getName()
                    + "created for invalid Schema URI");
        } catch (Exception ex) {
            // expected failure
            ; // nop
        }

        // expected success
        SchemaFactory sf = null;
        try {
            sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            // expected success
        } catch (Exception ex) {
            // unexpected failure
            ex.printStackTrace();

            fail("SchemaFactory "
                    + sf.getClass().getName()
                    + "could not be created for required Schema URI "
                    + XMLConstants.W3C_XML_SCHEMA_NS_URI);
        }
   }

    /**
     * Test SchemaFactory.newSchema(File).
     */
    public void testNewSchema() {

        URI schemaUri = null;
        try {
            schemaUri = SchemaFactoryTest.class.getResource(
                    "block-list-union.xsd").toURI();
        } catch (Exception e) {
            // unexpected Exception
            e.printStackTrace();
            fail(e.toString());
        }

        SchemaFactory schemaFactory =
                SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

        ErrorHandler errorHandler = new ErrorHandler();
        schemaFactory.setErrorHandler(errorHandler);

        try {
            schemaFactory.newSchema(new File(schemaUri));
        } catch (Exception e) {
            // unexpected Exception
            e.printStackTrace();
            fail(e.toString());
        }

        // 3 errors should have been registered
        if (errorHandler.errorCounter != 3) {
            fail("Invalid schema, "
                    + schemaUri.toString()
                    + ", parsed with "
                    + errorHandler.errorCounter
                    + " errors, expected 3.");
        }

        // success
    }

    /**
     * An ErrorHandler for the SchemaFactory.
     */
    protected static class ErrorHandler extends DefaultHandler {

        public int errorCounter = 0;

        public void error(final SAXParseException e) throws SAXException {
            errorCounter++;
            
            // was this expected?
            if (e.getMessage().indexOf("s4s-att-invalid-value:") == -1) {
                e.printStackTrace();
                fail("Unexpected SAXParseException: " + e.toString());
            }

            System.out.println("Expected SAXParseException: error: " + e);
        }

        public void fatalError(final SAXParseException e) throws SAXException {
            errorCounter++;

            // unexpected
            e.printStackTrace();
            fail(e.toString());
        }
    }
}
