/*
 * Bug.java
 *
 * Created on January 27, 2006, 12:56 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6367542;

/**
 *
 * @author Sunitha Reddy
 */
import org.w3c.dom.*;
import org.w3c.dom.ls.*;
import org.w3c.dom.bootstrap.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testDOMImplementationRegistry(){
        try{
        DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
        DOMImplementation domImpl = registry.getDOMImplementation("XML");
        assertTrue("Non null implementation is expected for getDOMImplementation('XML')", domImpl != null);
        }catch(Exception e){
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }
    }
}
