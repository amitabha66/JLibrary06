/*
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package batch.qa;

import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;

import junit.framework.TestCase;
import junit.framework.TestResult;
import junit.framework.TestSuite;
import batch.core.JAXPTest;
import batch.core.VersionNumber;
import batch.core.om.Instance;
import batch.util.InterpreterEx;
import bsh.EvalError;
import bsh.Interpreter;
import bsh.TargetError;


/**
 * TestCase that handles one schema and XML documents associated
 * with them.
 * 
 * @author
 * 	Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class QATestCase extends TestSuite implements JAXPTest {

    /** set to false to avoid unnecessary schema compilation. */
    public boolean forceCompile = true;
    
    protected final QATestDescriptor desc;
    
    private CompileTest compileTest;
    
    /**
     * Builds a test case.
     */
    public QATestCase( QATestDescriptor description ) {
        desc = description;
        
        compileTest = new CompileTest(description.schema);
        addTest(compileTest);
        
        // then run sciprts with "run='once'" attribute.
        for( int i=0; i<desc.runOnceScripts.length; i++ ) {
            addTest(new ScriptTest(null,desc.runOnceScripts[i]));
        }
        
        // finally run per-instance scripts.
        for( int i=0; i<desc.instances.length; i++ ) {
            for( int j=0; j<desc.perInstanceScripts.length; j++ ) {
                addTest(new ScriptTest(desc.instances[i],desc.perInstanceScripts[j]));
            }
        }
    }
    

    
    /**
     * Set up a script interpreter for "per-document" tests. 
     * This method can be overrided by derived classes.
     * 
     * @param instance
     *      null if the interpreter is for the schema.
     */
    protected Interpreter createInterpreter( Instance instance ) throws Exception {
        try {
            Interpreter engine = new InterpreterEx();
            
            // import the package
            engine.eval( "import javax.xml.parsers.*;");
            engine.eval( "import javax.xml.validation.*;");
            engine.eval( "import org.xml.sax.*;");

            engine.set( "schema", compileTest.getCompiledSchema() );
            engine.set( "instance", instance );
            
            // define helper methods
            engine.eval(
                "fail(msg) { throw new Exception(msg); }" );
    
            engine.eval(
                "assert(b) { if(!b) fail(\"assertion failed\"); }" );

            engine.eval(
                "assert(b,msg) { if(!b) fail(msg); }" );
        
            return engine;
        } catch( EvalError e ) {
            throw new Error(e); // impossible
        }
    }

    
    
    /**
     * {@link Test} that runs a script.
     */
    private class ScriptTest extends TestCase {
        private final Instance instance;
        private final URL script;
        
        ScriptTest( Instance instance, URL script ) {
            super(
                instance==null
                    ?"running: "+script.toExternalForm()
                    :"running: "+instance.getName()+" with "+script.toExternalForm());
            this.instance = instance;
            this.script = script;
        }
        
        
        public void runTest() throws Exception {
            System.out.println("running "+super.getName());
            
            Reader scriptReader = new InputStreamReader(script.openStream());
            
            if( instance==null ) {
                System.out.println("running: "+script.toExternalForm());
                Interpreter interpreter = createInterpreter(null);
                try {
                    interpreter.eval(scriptReader);
                } catch( TargetError e ) {
                    Throwable t = e.getTarget();
                    if(t instanceof Exception)
                        throw (Exception)t;
                    else
                        throw (Error)t;
                }
            } else {
                System.out.println("running: "+instance.getName()+" with "+script.toExternalForm());
                
                instance.runScript( createInterpreter(instance), scriptReader );
            }
        }
        
        public String toString() {
            return getName();
        }
    }
    
    /**
     * This test is valid against the JAXB RI of this version or later.
     */
    public boolean isApplicable(VersionNumber v) {
        return desc.isApplicable(v);
    }
    
    public String toString() {
        return desc.testSpecUrl.toString();
    }

    public void run(TestResult result) {
        super.run(result);
        compileTest.dispose();  // release memory ASAP
    }

}
