/*
 * @(#)$Id: ValidatorImpl.java,v 1.1 2005/06/10 04:25:01 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package validator;

import java.io.IOException;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Validator;
import javax.xml.validation.ValidatorHandler;

import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;

/**
 * <b>(For Implementors)</b> Default implementation of {@link Validator}.
 * 
 * <p>
 * This class is intended to be used in conjunction with
 * {@link AbstractSchemaImpl} to promote consistent
 * behaviors among {@link Schema} implementations.
 * 
 * <p>
 * This class wraps a {@link javax.xml.validation.ValidatorHandler}
 * object and implements the {@link Validator} semantics. 
 * 
 * @author <a href="mailto:Kohsuke.Kawaguchi@Sun.com">Kohsuke Kawaguchi</a>
 * @version $Revision: 1.1 $, $Date: 2005/06/10 04:25:01 $
 * @since 1.5
 */
public class ValidatorImpl extends Validator {
    
    /**
     * The actual validation will be done by this object.
     */
    private final ValidatorHandler handler;
    
    /**
     * Lazily created identity transformer.
     */
    private Transformer identityTransformer = null;
    
    public ValidatorImpl( ValidatorHandler _handler ) {
        this.handler = _handler;
    }

    public LSResourceResolver getResourceResolver() {
        return handler.getResourceResolver();
    }


    public ErrorHandler getErrorHandler() {
        return handler.getErrorHandler();
    }

    public void setResourceResolver(LSResourceResolver resolver) {
        handler.setResourceResolver(resolver);
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        handler.setErrorHandler(errorHandler);
    }

    public void validate(Source source, Result result) throws SAXException, IOException {
        if( source instanceof DOMSource ) {
            if( result!=null && !(result instanceof DOMResult) )
                throw new IllegalArgumentException(result.getClass().getName());
            process( (DOMSource)source, (DOMResult)result );
            return;
        }
        if( source instanceof SAXSource ) {
            if( result!=null && !(result instanceof SAXResult) )
                throw new IllegalArgumentException(result.getClass().getName());
            process( (SAXSource)source, (SAXResult)result );
            return;
        }
        if( source instanceof StreamSource ) {
            if( result!=null )  
                throw new IllegalArgumentException(result.getClass().getName());
            StreamSource ss = (StreamSource)source;
            InputSource is = new InputSource();
            is.setByteStream(ss.getInputStream());
            is.setCharacterStream(ss.getReader());
            is.setPublicId(ss.getPublicId());
            is.setSystemId(ss.getSystemId());
            process( new SAXSource(is), null );
            return;
        }
        throw new IllegalArgumentException(source.getClass().getName());
    }

    /**
     * Parses a {@link SAXSource} potentially to a {@link SAXResult}.
     */
    private void process(SAXSource source, SAXResult result) throws IOException, SAXException {
        if( result!=null ) {
            handler.setContentHandler(result.getHandler());
        }
        
        try {
            XMLReader reader = source.getXMLReader();
            if( reader==null ) {
                // create one now
                SAXParserFactory spf = SAXParserFactory.newInstance();
                spf.setNamespaceAware(true);
                try {
                    reader = spf.newSAXParser().getXMLReader();
                } catch( Exception e ) {
                    // this is impossible, but better safe than sorry
                    throw new FactoryConfigurationError(e);
                }
            }
            
            reader.setErrorHandler(errorForwarder);
            reader.setEntityResolver(resolutionForwarder);
            reader.setContentHandler(handler);
            
            InputSource is = source.getInputSource();
            reader.parse(is);
        } finally {
            // release the reference to user's handler ASAP
            handler.setContentHandler(null);
        }
    }
    
    /**
     * Parses a {@link DOMSource} potentially to a {@link DOMResult}.
     */
    private void process( DOMSource source, DOMResult result ) throws SAXException {
        if( identityTransformer==null )
            try {
                identityTransformer = TransformerFactory.newInstance().newTransformer();
            } catch (TransformerConfigurationException e) {
                // this is impossible, but again better safe than sorry
                throw new TransformerFactoryConfigurationError(e);
            }
        
        // TODO: what does it mean to have a DOMResult?
        try {
            identityTransformer.transform( source, new SAXResult(handler) );
        } catch (TransformerException e) {
            if( e.getException() instanceof SAXException )
                throw (SAXException)e.getException();
            throw new SAXException(e);
        }
    }
    
    /**
     * Forwards the error to the {@link ValidatorHandler}.
     * If the {@link ValidatorHandler} doesn't have its own
     * {@link ErrorHandler}, behave draconian.
     */
    private final ErrorHandler errorForwarder = new ErrorHandler() {
        public void warning(SAXParseException exception) throws SAXException {
            ErrorHandler realHandler = handler.getErrorHandler();
            if( realHandler!=null )
                realHandler.warning(exception);
        }

        public void error(SAXParseException exception) throws SAXException {
            ErrorHandler realHandler = handler.getErrorHandler();
            if( realHandler!=null )
                realHandler.error(exception);
            else
                throw exception;
        }

        public void fatalError(SAXParseException exception) throws SAXException {
            ErrorHandler realHandler = handler.getErrorHandler();
            if( realHandler!=null )
                realHandler.fatalError(exception);
            else
                throw exception;
        }
    };
    
    /**
     * Forwards the entity resolution to the {@link ValidatorHandler}.
     * If the {@link ValidatorHandler} doesn't have its own
     * {@link DOMResourceResolver}, let the parser do the resolution.
     */
    private final EntityResolver resolutionForwarder = new EntityResolver() {
        public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
            LSResourceResolver resolver = handler.getResourceResolver();
            if( resolver==null )    return null;
            
            LSInput di = resolver.resolveResource(null,null,publicId,systemId,null);
            if(di==null)    return null;
            
            InputSource r = new InputSource();
            r.setByteStream(di.getByteStream());
            r.setCharacterStream(di.getCharacterStream());
            r.setEncoding(di.getEncoding());
            r.setPublicId(di.getPublicId());
            r.setSystemId(di.getSystemId());
            return r;
        }
    };
}
