/*
 * @(#)$Id: SchemaFactoryLoaderImpl.java,v 1.1 2005/06/10 04:23:42 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package validator.jarv;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.SchemaFactoryLoader;

import org.iso_relax.verifier.VerifierConfigurationException;
import org.iso_relax.verifier.VerifierFactory;

/**
 * {@link SchemaFactoryLoader} implementation for this library. 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class SchemaFactoryLoaderImpl extends SchemaFactoryLoader {
    public SchemaFactory newFactory(String schemaLanguage) {
        try {
            return new SchemaFactoryImpl(VerifierFactory.newInstance(schemaLanguage));
        } catch (VerifierConfigurationException e) {
            return null;
        }
    }
}
