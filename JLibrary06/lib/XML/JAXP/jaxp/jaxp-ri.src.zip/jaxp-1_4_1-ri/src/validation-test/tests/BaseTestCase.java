/*
 * @(#)$Id: BaseTestCase.java,v 1.1 2005/06/10 04:24:00 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package tests;

import java.io.StringReader;

import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import junit.framework.TestCase;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Extends {@link TestCase} and provides some utilities.
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class BaseTestCase extends TestCase {
    /**
     * Loads XML Schema as a {@link Schema} object.
     * 
     * @param schema
     *      The schema file name (no path name).
     *      The file should be placed as a resource
     *      in the same package as the caller.
     */
    protected final Schema loadXsdSchema(String schema) throws SAXException {
        SchemaFactory sf = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        assertNotNull(sf);
        return sf.newSchema(this.getClass().getResource(schema));
    }
    
    /**
     * Creates an empty XML Schema {@link Schema}.
     */
    protected final Schema loadXsdSchema() throws SAXException {
        SchemaFactory sf = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        assertNotNull(sf);
        return sf.newSchema();
    }

    /**
     * Creates an imaginary kohsuke's schema language
     * for tests.
     * 
     * @see validator.ks.ValidatorHandlerImpl
     */
    protected final Schema loadKSchema() throws SAXException {
        SchemaFactory sf = SchemaFactory.newInstance("kohsuke");
        assertNotNull(sf);
        return sf.newSchema();
    }
    
    /**
     * Creates {@link InputSource} from XML literal string.
     */
    protected final InputSource createStringSource( String xml ) {
        return new InputSource(new StringReader(xml));
    }
    
    /**
     * Creates {@link InputSource} from the resource file.
     * 
     * @param fileName
     *      The instance file name (no path name).
     *      The file should be placed as a resource
     *      in the same package as the caller.
     */
    protected final InputSource createResourceSource( String fileName ) {
        return new InputSource(this.getClass().getResource(fileName).toExternalForm());
    }
    
    /**
     * XML Schema positive validation test.
     * 
     * Validates the specified instance by using the specified schema,
     * and checks if all goes well. 
     * 
     * @param schemaFile
     *      Passed to {@link #loadXsdSchema(String)}
     * @param instanceFile
     *      Passed to {@link #createResourceSource(String)}
     */
    protected final void doXmlSchemaPositiveTest(String schemaFile,String instanceFile) throws Exception {
        Schema s = loadXsdSchema(schemaFile);
        try {
            s.newValidator().validate(
                new StreamSource(this.getClass().getResourceAsStream(instanceFile)));
        } catch( SAXException e ) {
            fail(e.getMessage()); // error unexpected
        }
    }
    
    /**
     * XML Schema negative validation test.
     * 
     * Validates the specified instance by using the specified schema,
     * and expects a validation error. 
     * 
     * @param schemaFile
     *      Passed to {@link #loadXsdSchema(String)}
     * @param instanceFile
     *      Passed to {@link #createResourceSource(String)}
     */
    protected final void doXmlSchemaNegativeTest(String schemaFile,String instanceFile) throws Exception {
        // FIXME: we should probably make sure if the error message is
        // indeed what we are expected.
        Schema s = loadXsdSchema(schemaFile);
        try {
            s.newValidator().validate(
                new StreamSource(this.getClass().getResourceAsStream(instanceFile)));
            fail(); // error expected
        } catch( SAXException e ) {
            System.out.println(e.getMessage());
            // as expected
        }
    }
}
