/*
 * cr6361860.java
 *
 * Created on March 13, 2007, 7:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package xsltc;

import java.io.StringReader;
import java.io.StringWriter;
import java.io.InputStream;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.dom.DOMResult;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit test for CR 6361860
 *
 * @author Joe.Wang@sun.com
 */
public class CR6361860 extends TestCase {
    
    public static void main(String [] args){
        TestRunner.run(CR6361860.class);
    }
    
    public CR6361860() {
    }
    
    final TransformerFactory newInstance = TransformerFactory.newInstance();
    
    public void testOOMonjdk5() throws Exception {
        Source xml = new StreamSource (this.getClass().getResourceAsStream("cr6361860.xml"));
        Source xsl = new StreamSource (this.getClass().getResourceAsStream("cr6361860.xsl"));
        Transformer transformer = newInstance.newTransformer(xsl);
        transformer.transform(xml, new DOMResult());
    }
    
}