/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: LSSerializerTest.java,v 1.3 2006/11/09 17:30:20 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.w3c.dom.ls;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.Writer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import com.sun.org.apache.xerces.internal.impl.Constants;

import org.w3c.dom.DOMConfiguration;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import org.w3c.dom.DOMError;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Test LSSerializer format-pretty-print.
 *
 * Motivated by CR 6439439 Support format-pretty-print in LSSerializer.
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */
public class LSSerializerTest extends TestCase {

    /**
     * Creates a new instance of LSSerializerTest.
     *
     * @param name Name of test.
     */
    public LSSerializerTest(String name) {
         super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(LSSerializerTest.class);
    }

    /**
     * Implement DOMErrorHandler to use in testDOMErrorHandler().
     */
    class DOMErrorHandlerImpl implements DOMErrorHandler {

        boolean NoOutputSpecifiedErrorReceived = false;

        public boolean handleError(final DOMError error) {
            // consume "no-output-specified" errors
            if ("no-output-specified".equalsIgnoreCase(error.getType())) {
                NoOutputSpecifiedErrorReceived = true;
            return true;
            }

            // unexpected error
            fail("Unexpected Error Type: " + error.getType()
                + " @ (" + error.getLocation().getLineNumber()
                + ", " + error.getLocation().getColumnNumber() + ")"
                + ", " + error.getMessage());
            
            return false;
        }
    }

    /**
     * Implement LSOutput to use in testDOMErrorHandler().
     */
    class Output implements LSOutput {
        public OutputStream getByteStream() {
            return null;
        }
        public void setByteStream(final OutputStream byteStream) {
        }
        public Writer getCharacterStream() {
            return null;
        }
        public void setCharacterStream(final Writer characterStream) {
        }
        public String getSystemId() {
            return null;
        }
        public void setSystemId(final String systemId) {
        }
        public String getEncoding() {
            return "UTF8";
        }
        public void setEncoding(final String encoding) {
        }
    }

    /**
     * Test LSSerializer's DOMErrorHandler.
     *
     * Inspired by CR 4935107 Method DOMSerializer.write()
     *   raise an error without error type as specified in A
     *
     * Test should pass.
     */
    public void testDOMErrorHandler() {

        final String XML_DOCUMENT =
                "<?xml version=\"1.0\"?>"
                + "<hello>"
                + "world"
                + "</hello>";

        StringReader stringReader = new StringReader(XML_DOCUMENT);
        InputSource inputSource = new InputSource(stringReader);
        Document doc = null;
        try {
            DocumentBuilderFactory documentBuilderFactory =
                    DocumentBuilderFactory.newInstance();
            // LSSerializer defaults to Namespace processing
            // so parsing must also
            documentBuilderFactory.setNamespaceAware(true);
            DocumentBuilder parser =
                    documentBuilderFactory.newDocumentBuilder();
            doc = parser.parse(inputSource);

        } catch (Throwable e) {
            e.printStackTrace();
            fail(e.toString());
        }

        DOMImplementation impl = doc.getImplementation();
        DOMImplementationLS implLS =
                (DOMImplementationLS) impl.getFeature("LS", "3.0");
        LSSerializer writer = implLS.createLSSerializer();
        DOMErrorHandlerImpl eh = new DOMErrorHandlerImpl();
        writer.getDomConfig().setParameter("error-handler", eh);

        boolean serialized =  false;
        try {
            serialized = writer.write(doc, new Output());

            // unexpected success
            fail("Serialized without raising an LSException due to "
                    + "'no-output-specified'.");
        } catch (LSException lsException) {
            // expected exception
            System.out.println(
                    "Expected LSException: " + lsException.toString());
            // continue processing
        }

        assertFalse("Expected writer.write(doc, new Output()) == false",
                serialized);

        assertTrue("'no-output-specified' error was expected",
                eh.NoOutputSpecifiedErrorReceived);
    }

    /**
     * Test LSSerializer with format-pretty-print.
     *
     * Test should pass.
     */
    public void testFormatPrettyPrint() {

        final String XML_DOCUMENT =
                "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\n"
                + "<hello>"
                + "world"
                + "<child><children/><children/></child>"
                + "</hello>";

        final String XML_DOCUMENT_PRETTY_PRINT =
                "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\n"
                + "<hello>"
                + "world"
                + "<child>"
                + "\n"
                + "        "
                + "<children/>"
                + "\n"
                + "        "
                + "<children/>"
                + "\n"
                + "    "
                + "</child>"
                + "\n"
                + "</hello>"
                + "\n";

        // it all begins with a Document
        DocumentBuilderFactory documentBuilderFactory =
                DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = null;
        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException parserConfigurationException) {
            parserConfigurationException.printStackTrace();
            fail(parserConfigurationException.toString());
        }
        Document document = null;

        StringReader stringReader = new StringReader(XML_DOCUMENT);
        InputSource inputSource = new InputSource(stringReader);
        try {
            document = documentBuilder.parse(inputSource);
        } catch (SAXException saxException) {
            saxException.printStackTrace();
            fail(saxException.toString());
        } catch (IOException ioException) {
            ioException.printStackTrace();
            fail(ioException.toString());
        }

        // query DOM Interfaces to get to a LSSerializer
        DOMImplementation domImplementation =
                documentBuilder.getDOMImplementation();
        DOMImplementationLS domImplementationLS =
                (DOMImplementationLS) domImplementation;
        LSSerializer lsSerializer = domImplementationLS.createLSSerializer();

        // get configuration
        DOMConfiguration domConfiguration = lsSerializer.getDomConfig();

        // query current configuration
        Boolean defaultFormatPrettyPrint =
                (Boolean) domConfiguration.getParameter(
                Constants.DOM_FORMAT_PRETTY_PRINT);
        Boolean canSetFormatPrettyPrintFalse =
                (Boolean) domConfiguration.canSetParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT,
                    Boolean.FALSE);
        Boolean canSetFormatPrettyPrintTrue =
                (Boolean) domConfiguration.canSetParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT,
                    Boolean.TRUE);

        System.out.println(Constants.DOM_FORMAT_PRETTY_PRINT
                + " default/can set false/can set true = "
                + defaultFormatPrettyPrint
                + "/"
                + canSetFormatPrettyPrintFalse
                + "/"
                + canSetFormatPrettyPrintTrue);

        // test values
        assertEquals(
                "Default value of "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + " should be "
                + Boolean.FALSE,
                defaultFormatPrettyPrint,
                Boolean.FALSE);

        assertEquals(
                "Can set "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + " to "
                + Boolean.FALSE
                + " should be "
                + Boolean.TRUE,
                canSetFormatPrettyPrintFalse,
                Boolean.TRUE);

        assertEquals(
                "Can set "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + " to "
                + Boolean.TRUE
                + " should be "
                + Boolean.TRUE,
                canSetFormatPrettyPrintTrue,
                Boolean.TRUE);

        // get default serialization
        String prettyPrintDefault = lsSerializer.writeToString(document);
        System.out.println(
                "(default) "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + "=="
                + (Boolean) domConfiguration.getParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT)
                + ": \n\""
                + prettyPrintDefault
                + "\"");

        assertEquals(
                "Invalid serialization with default value, "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + "=="
                + (Boolean) domConfiguration.getParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT),
                XML_DOCUMENT, prettyPrintDefault);

        // configure LSSerializer to not format-pretty-print
        domConfiguration.setParameter(
                Constants.DOM_FORMAT_PRETTY_PRINT,
                Boolean.FALSE);
        String prettyPrintFalse = lsSerializer.writeToString(document);
        System.out.println(
                "(FALSE) "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + "=="
                + (Boolean) domConfiguration.getParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT)
                + ": \n\""
                + prettyPrintFalse
                + "\"");

        assertEquals(
                "Invalid serialization with FALSE value, "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + "=="
                + (Boolean) domConfiguration.getParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT),
                XML_DOCUMENT, prettyPrintFalse);

        // configure LSSerializer to format-pretty-print
        domConfiguration.setParameter(
                Constants.DOM_FORMAT_PRETTY_PRINT,
                Boolean.TRUE);
        String prettyPrintTrue = lsSerializer.writeToString(document);
        System.out.println(
                "(TRUE) "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + "=="
                + (Boolean) domConfiguration.getParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT)
                + ": \n\""
                + prettyPrintTrue
                + "\"");

        assertEquals(
                "Invalid serialization with TRUE value, "
                + Constants.DOM_FORMAT_PRETTY_PRINT
                + "=="
                + (Boolean) domConfiguration.getParameter(
                    Constants.DOM_FORMAT_PRETTY_PRINT),
                XML_DOCUMENT_PRETTY_PRINT, prettyPrintTrue);
    }

    /**
     * Test LSSerializer with XML 1.1 document.
     * Inspired by CR 4892774: Tiger: XML 1.1 doc parsed in by DocumentBuilder
     * is serialized as XML 1.0 doc
     *
     * Test should pass.
     */
    public void testXML11() {

        /**
         * XML 1.1 document to parse.
         */
        final String XML11_DOCUMENT =
                "<?xml version=\"1.1\" encoding=\"UTF-16\"?>\n"
                + "<hello>"
                + "world"
                + "<child><children/><children/></child>"
                + "</hello>";

        // it all begins with a Document
        DocumentBuilderFactory documentBuilderFactory =
                DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = null;
        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException parserConfigurationException) {
            parserConfigurationException.printStackTrace();
            fail(parserConfigurationException.toString());
        }
        Document document = null;

        StringReader stringReader = new StringReader(XML11_DOCUMENT);
        InputSource inputSource = new InputSource(stringReader);
        try {
            document = documentBuilder.parse(inputSource);
        } catch (SAXException saxException) {
            saxException.printStackTrace();
            fail(saxException.toString());
        } catch (IOException ioException) {
            ioException.printStackTrace();
            fail(ioException.toString());
        }

        // query DOM Interfaces to get to a LSSerializer
        DOMImplementation domImplementation =
                documentBuilder.getDOMImplementation();
        DOMImplementationLS domImplementationLS =
                (DOMImplementationLS) domImplementation;
        LSSerializer lsSerializer = domImplementationLS.createLSSerializer();

        // get default serialization
        String defaultSerialization = lsSerializer.writeToString(document);
        
        System.out.println("XML 1.1 serialization = \"" + defaultSerialization + "\"");

        // output should == input
        assertEquals(
                "Invalid serialization of XML 1.1 document: ",
                XML11_DOCUMENT, defaultSerialization);
    }
}
