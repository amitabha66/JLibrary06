/*
 * @(#)$Id: ErrorFilter.java,v 1.1 2005/06/10 04:23:42 jeffsuttor Exp $
 * 
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc. Use
 * is subject to license terms.
 *  
 */
package validator.jarv;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * @author Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
class ErrorFilter implements ErrorHandler {
    private ErrorHandler errorHandler;
    
    private boolean hadError = false;
    
    public boolean isValidSoFar() { return !hadError; }
    public void reset() { hadError = false; }
    
    /**
     * @param exception
     * @throws SAXException
     */
    public void error(SAXParseException exception) throws SAXException {
        hadError = true;
        errorHandler.error(exception);
    }

    /**
     * @param exception
     * @throws SAXException
     */
    public void fatalError(SAXParseException exception) throws SAXException {
        hadError = true;
        errorHandler.fatalError(exception);
    }

    /**
     * @param exception
     * @throws SAXException
     */
    public void warning(SAXParseException exception) throws SAXException {
        errorHandler.warning(exception);
    }

    /**
     * @return Returns the errorHandler.
     */
    public ErrorHandler getErrorHandler() {
        return errorHandler;
    }

    /**
     * @param errorHandler The errorHandler to set.
     */
    public void setErrorHandler(ErrorHandler errorHandler) {
        this.errorHandler = errorHandler;
    }

}