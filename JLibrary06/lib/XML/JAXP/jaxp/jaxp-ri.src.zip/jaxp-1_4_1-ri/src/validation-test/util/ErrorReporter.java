/*
 * @(#)$Id: ErrorReporter.java,v 1.1 2005/06/10 04:23:31 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package util;
import java.io.PrintStream;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;


/**
 * {@link ErrorHandler} that dumps info to console.
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class ErrorReporter implements ErrorHandler {
    
    private final PrintStream out;
    
    public ErrorReporter( PrintStream out ) {
        this.out = out;
    }
    
    public void error(SAXParseException e) throws SAXException {
        print(e);
    }

    private void print(SAXParseException e) {
        out.println(e.getMessage());
        out.println("line "+e.getLineNumber()+" column "+e.getColumnNumber()+" of file "+e.getSystemId());
    }

    public void fatalError(SAXParseException e) throws SAXException {
        print(e);
    }

    public void warning(SAXParseException e) throws SAXException {
        print(e);
    }

}
