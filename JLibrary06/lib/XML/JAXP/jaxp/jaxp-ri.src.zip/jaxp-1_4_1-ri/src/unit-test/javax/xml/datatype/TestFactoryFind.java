package javax.xml.datatype;

import java.net.URL;
import java.net.URLClassLoader;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * @author  Santiago.PericasGeertsen@sun.com
 */
public class TestFactoryFind extends TestCase {
    
    boolean myClassLoaderUsed = false;
    
    public TestFactoryFind(String name) {
        super(name);
    }
    
    public void testFactoryFind(){
        try {
            // System.setProperty("jaxp.debug", "true");
            
            DatatypeFactory factory = DatatypeFactory.newInstance();
            assertTrue(factory.getClass().getClassLoader() == null);
            
            Thread.currentThread().setContextClassLoader(null);
            factory = DatatypeFactory.newInstance();
            assertTrue(factory.getClass().getClassLoader() == null);
            
            Thread.currentThread().setContextClassLoader(new MyClassLoader());
            factory = DatatypeFactory.newInstance();
            assertTrue(myClassLoaderUsed);               
        }
        catch (Exception ex) {
        }    
        
    }
    
    public static void main(String [] args){
        TestRunner.run(TestFactoryFind.class);
    }
    
    class MyClassLoader extends URLClassLoader {
        
        public MyClassLoader() {
            super(new URL[0]);
        }
        
        public Class loadClass(String name) throws ClassNotFoundException {
            myClassLoaderUsed = true;
            return super.loadClass(name);
        }
    }
}
