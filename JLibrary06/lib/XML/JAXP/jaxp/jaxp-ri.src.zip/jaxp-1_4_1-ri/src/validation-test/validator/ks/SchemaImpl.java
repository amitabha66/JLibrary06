/*
 * @(#)$Id: SchemaImpl.java,v 1.1 2005/06/10 04:23:10 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package validator.ks;

import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import javax.xml.validation.ValidatorHandler;

import validator.ValidatorImpl;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
class SchemaImpl extends Schema {
    public ValidatorHandler newValidatorHandler() {
        return new ValidatorHandlerImpl();
    }
    
    public Validator newValidator() {
        return new ValidatorImpl(newValidatorHandler());
    }
}
