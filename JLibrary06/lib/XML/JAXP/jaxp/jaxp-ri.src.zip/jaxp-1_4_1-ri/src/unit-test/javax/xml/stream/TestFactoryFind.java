package javax.xml.stream;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.Properties;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import java.io.*;

/**
 * @author  Santiago.PericasGeertsen@sun.com
 */
public class TestFactoryFind extends TestCase {
    
    boolean myClassLoaderUsed = false;
    
    final static String FACTORY_KEY = "javax.xml.stream.XMLInputFactory";
    
    public TestFactoryFind(String name) {
        super(name);
    }
    
    public void testFactoryFindUsingStaxProperties() {
        // If property is defined, will take precendence so this test 
        // is ignored :(
        if (System.getProperty(FACTORY_KEY) != null) {
            return;
        }
        
        Properties props = new Properties();
        String configFile = System.getProperty("java.home") + 
                File.separator + "lib" + File.separator + "stax.properties";

        File f = new File(configFile);
        if (f.exists()) {
            try {
                FileInputStream fis = new FileInputStream(f);
                props.load(fis);
                fis.close();
            }
            catch (FileNotFoundException e) {                
                return;
            }
            catch (IOException e) {                
                return;
            }
        }            
        else {
            props.setProperty(FACTORY_KEY,
                "com.sun.xml.internal.stream.XMLInputFactoryImpl");
            try {
                FileOutputStream fos = new FileOutputStream(f);
                props.store(fos, null);
                fos.close();
                f.deleteOnExit();
            }
            catch (FileNotFoundException e) {                
                return;
            }
            catch (IOException e) {                
                return;
            }            
        }

        XMLInputFactory factory = XMLInputFactory.newInstance();
        assertTrue(factory.getClass().getName().equals(props.getProperty(FACTORY_KEY)));
    }
        
    public void testFactoryFind(){
        try {
            // System.setProperty("jaxp.debug", "true");
            
            XMLInputFactory factory = XMLInputFactory.newInstance();
            assertTrue(factory.getClass().getClassLoader() == null);
            
            Thread.currentThread().setContextClassLoader(null);
            factory = XMLInputFactory.newInstance();
            assertTrue(factory.getClass().getClassLoader() == null);
            
            Thread.currentThread().setContextClassLoader(new MyClassLoader());
            factory = XMLInputFactory.newInstance();
            assertTrue(myClassLoaderUsed);               
            
            XMLOutputFactory ofactory = XMLOutputFactory.newInstance();
            assertTrue(ofactory.getClass().getClassLoader() == null);
            
            Thread.currentThread().setContextClassLoader(null);
            ofactory = XMLOutputFactory.newInstance();
            assertTrue(ofactory.getClass().getClassLoader() == null);
            
            Thread.currentThread().setContextClassLoader(new MyClassLoader());
            ofactory = XMLOutputFactory.newInstance();
            assertTrue(myClassLoaderUsed);                        
        }
        catch (Exception ex) {
            throw new RuntimeException(ex);
        }            
    }
    
    public static void main(String [] args){
        TestRunner.run(TestFactoryFind.class);
    }
    
    class MyClassLoader extends URLClassLoader {
        
        public MyClassLoader() {
            super(new URL[0]);
        }
        
        public Class loadClass(String name) throws ClassNotFoundException {
            myClassLoaderUsed = true;
            return super.loadClass(name);
        }
    }
}
