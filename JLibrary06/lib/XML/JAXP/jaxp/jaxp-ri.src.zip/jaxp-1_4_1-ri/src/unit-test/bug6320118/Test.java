
package bug6320118;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import java.io.*;
import java.util.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Test for XML Schema errata
 *
 * http://www.w3.org/2001/05/xmlschema-errata#e2-45
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {
    
    DatatypeFactory df;
    
    public Test(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Test.class);
    }
        
    public void test1(){        
        try {
            df = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            fail(e.getMessage());
        }
        
        try {
            XMLGregorianCalendar calendar = df.newXMLGregorianCalendar(1970, 1, 1, 24, 0, 0, 0, 0);
        } catch (IllegalArgumentException e) {
            fail(e.getMessage());
        }
    }    
    
    public void test2(){        
        try {
            df = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            fail(e.getMessage());
        }
        
        try {
            XMLGregorianCalendar calendar = df.newXMLGregorianCalendarTime(24, 0, 0, 0);
        } catch (IllegalArgumentException e) {
            fail(e.getMessage());
        }
    }
    
    public void test3(){        
        try {
            df = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            fail(e.getMessage());
        }
        try {
            XMLGregorianCalendar calendar = df.newXMLGregorianCalendar();
            // Must fail as other params are not 0 but undefined
            calendar.setHour(24);
            fail("test3() - Expected IllegalArgumentException not thrown");
        } catch (IllegalArgumentException e) {
            // falls through
        }
    }
    
    public void test4(){        
        try {
            df = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            fail(e.getMessage());
        }
        
        try {
            XMLGregorianCalendar calendar = df.newXMLGregorianCalendar();
            calendar.setTime(24, 0, 0, 0);
        } catch (IllegalArgumentException e) {
            fail(e.getMessage());
        }
    }
    
}
