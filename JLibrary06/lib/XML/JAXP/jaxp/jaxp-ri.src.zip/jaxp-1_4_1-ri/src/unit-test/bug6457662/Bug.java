/*
 * Main.java
 *
 * Created on August 4, 2006, 10:46 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6457662;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }

    /** XML */
    public static final String xml = "<ACL xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>"+
            "<Tokens access=\"full\">"+
            "<Token>CheetahTech</Token>"+
            "<Token>CheetahView</Token>"+
            "</Tokens>"+
            "</ACL>";
    /** Schema */
    public static final String schema = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
            "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" elementFormDefault=\"qualified\" attributeFormDefault=\"unqualified\">"+
            "<xs:element name=\"ACL\">"+
            "<xs:complexType mixed=\"false\">"+
            "<xs:sequence><xs:element ref=\"Tokens\" maxOccurs=\"3\"/></xs:sequence>"+
            "<xs:attribute name=\"ACL\" type=\"xs:string\" use=\"optional\"/>"+
            "</xs:complexType>"+
            "</xs:element><xs:element name=\"Tokens\">"+
            "<xs:complexType mixed=\"false\">"+
            "<xs:sequence><xs:element ref=\"Token\" maxOccurs=\"unbounded\"/></xs:sequence>"+
            "<xs:attribute name=\"access\" type=\"xs:string\" use=\"required\"/>"+
            "</xs:complexType></xs:element><xs:element name=\"Token\"/>"+
            "</xs:schema>";
    /** Schema factory */
    private static final SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    
    
    /** Creates a new instance of Main */
    public Bug() {
    }
    
    public static void main(String[] args) {
        new Bug().test();
    }
    
    public void test() {
        try {
            final Schema sc = factory.newSchema(writeSchema());
            final Validator validator = sc.newValidator();
            validator.validate(new StreamSource(new StringReader(xml)));
            validator.validate(new StreamSource(new StringReader(xml)));
            validator.validate(new StreamSource(new StringReader(xml)));
            validator.validate(new StreamSource(new StringReader(xml)));
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
    }
    
    private File writeSchema() throws IOException {
        final File rtn = File.createTempFile("scheam", "xsd");
        final OutputStream out = new FileOutputStream(rtn);
        final OutputStreamWriter writer = new OutputStreamWriter(out, "UTF-8");
        writer.write(schema);
        writer.close();
        out.close();
        return rtn;
    }
}
