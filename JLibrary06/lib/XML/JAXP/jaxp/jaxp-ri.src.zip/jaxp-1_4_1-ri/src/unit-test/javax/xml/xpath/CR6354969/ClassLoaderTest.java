/*
 * ClassLLoaderTest.java
 *
 * Created on March 15, 2007, 11:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javax.xml.xpath.CR6354969;

import javax.xml.namespace.NamespaceContext;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author joe.wang@sun.com
 */
public class ClassLoaderTest extends TestCase {

    /**
     * Creates a new instance of XPathTest.
     *
     * @param name Name of test.
     */
    public ClassLoaderTest(String name) {
         super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(ClassLoaderTest.class);
    }

    /**
     * Test XPath NamespaceContext support.
     *
     * Test should pass.
     */
    public void testClassLoader() {
        MyClassLoader cl = new MyClassLoader();
        Thread.currentThread().setContextClassLoader(cl);
        XPathFactory xPathFactory = XPathFactory.newInstance();
        
        if (!cl.isCalled()) {
            fail("Context class loader should be used.");
        }


    }
}
