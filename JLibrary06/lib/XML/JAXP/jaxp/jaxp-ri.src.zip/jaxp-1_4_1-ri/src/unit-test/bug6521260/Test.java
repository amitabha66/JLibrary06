/*
 * Test.java
 *
 * Created on February 5, 2007, 10:42 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6521260;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

/**
 * Unit test for CR 6521260. Make sure that changing the namespace prefix of
 * an attribute doesn't result in an unsorted internal list.
 *
 * @author Norman.Walsh@Sun.COM
 */
public class Test extends TestCase {
    
    public static void main(String [] args){
        TestRunner.run(Test.class);
    }
    
    public Test() {
    }
    
    public void test() throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();

        String docStr = "<system systemId='http://www.w3.org/2001/rddl/rddl-xhtml.dtd'"
                      + " uri='/cache/data/xrc36316.bin'"
                      + " xmlns:xr='urn:oasis:names:tc:entity:xmlns:xml:catalog'"
                      + " xr:systemId='http://www.w3.org/2001/rddl/rddl-xhtml.dtd'"
                      + " xmlns:NS1='http://xmlresolver.org/ns/catalog'"
                      + " NS1:time='1170267571097'/>";


        ByteArrayInputStream bais = new ByteArrayInputStream(docStr.getBytes());
        
        Document doc = builder.parse(bais);
        
        Element root = doc.getDocumentElement();

        String systemId = root.getAttribute("systemId");
        
        // Change the prefix on the "time" attribute so that the list would become unsorted
        // before my fix to xml-xerces/java/src/com/sun/org/apache/xerces/internal/dom/ElementImpl.java
        root.setAttributeNS("http://xmlresolver.org/ns/catalog", "xc:time", "100");
        
        String systemId2 = root.getAttribute("systemId");
        
        assertEquals(systemId, systemId2);
    }
}