/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:25:02 jeffsuttor Exp $
 * 
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc. Use
 * is subject to license terms.
 *  
 */
package bug4970380;

import javax.xml.validation.SchemaFactory;
import javax.xml.validation.ValidatorHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.xml.sax.SAXNotRecognizedException;

/**
 * @author Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    public void test1() throws Exception {
        SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        ValidatorHandler validatorHandler = schemaFactory.newSchema().newValidatorHandler();

        try {
            validatorHandler.getFeature("unknown1234");
            fail("SAXNotRecognizedException was not thrown.");
        } catch (SAXNotRecognizedException e) {
            ; // expected
        }

        if (!validatorHandler.getFeature("http://xml.org/sax/features/namespace-prefixes")) {
            // as expected
            System.out.println("getFeature(namespace-prefixes): OK");
        } else {
            fail("Expected false, returned true.");
        }
    }
}