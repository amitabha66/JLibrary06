/*
 * Bug.java
 *
 * Created on October 22, 2005, 10:33 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6309988;

/**
 *
 * @author Sunitha Reddy
 */

import java.io.*;

import javax.xml.parsers.*;
import org.xml.sax.*;
import org.w3c.dom.Document;
import javax.xml.XMLConstants;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    DocumentBuilderFactory dbf = null;
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    /* Given XML document has more than 10000 attributes. Exception is expected
     */
    public void testDOMParserElementAttributeLimit()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest.xml"));
            fail("SAXParserException is expected, as given XML document contains more than 10000 attributes");
        }catch(SAXParseException e){
            System.out.println(e.getMessage());
        }catch(Exception e){
            fail("Exception " + e.getMessage());
        }
    }

    /* Given XML document has more than 10000 attributes. 
     * It should report an error.
     */
    public void testDOMNSParserElementAttributeLimit()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest.xml"));
            fail("SAXParserException is expected, as given XML document contains more than 10000 attributes");
        }catch(SAXParseException e){
            System.out.println(e.getMessage());
        }catch(Exception e){
            fail("Exception " + e.getMessage());
	}
    }
    
    /* Given XML document has more than 10000 attributes. Parsing this XML document
     * in non-secure mode, should not report any error.
     */
    public void testDOMNSParserElementAttributeLimitWithoutSecureProcessing()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,false);
            dbf.setNamespaceAware(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest.xml"));
            
        }catch(SAXParseException e){
            fail(e.getMessage());
        }catch(Exception e){
            fail("Exception " + e.getMessage());
	}
    }
    
    /* Given XML document has 3 attributes and System property is set to 2. Parsing this XML document
     * in non-secure mode, should report an error.
     */
    public void testSystemElementAttributeLimitWithoutSecureProcessing()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,false);
            dbf.setNamespaceAware(true);
            System.setProperty("elementAttributeLimit", "2");
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest3.xml"));
            
        }catch(SAXParseException e){
            e.printStackTrace();
            fail("SAXParserException is not expected " + e.getMessage());
        }catch(Exception e){
            e.printStackTrace();
            fail("SAXParserException is not expected "+ e.getMessage());
	}finally{
            System.setProperty("elementAttributeLimit", "");
        }
    }
    
    /* Given XML document has 3 attributes and System property is set to 2. Parsing this XML document
     * in secure mode, should report an error.
     */
    public void testSystemElementAttributeLimitWithSecureProcessing()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            System.setProperty("elementAttributeLimit", "2");
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest3.xml"));
            fail("SAXParserException is expected, as given XML document contains more than 2 attributes");
        }catch(SAXParseException e){
            System.out.println(e.getMessage());
        }catch(Exception e){
            fail("Exception " + e.getMessage());
	}finally{
            System.setProperty("elementAttributeLimit", "");
        }
    }
    
    /* Default value for secure processing feature should be false.
     */
    public void testDOMSecureProcessingDefaultValue(){
        try{
            dbf = DocumentBuilderFactory.newInstance();
            assertTrue("Default value for secureProcessing feature should be true",dbf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING));
            
        }catch(Exception e){
            fail("Exception " + e.getMessage());
        }
    }
    
    /* Default value for secure processing feature should be false.
     */
    public void testSAXSecureProcessingDefaultValue(){
       try{
            SAXParserFactory spf = SAXParserFactory.newInstance();
            assertTrue("Default value for secureProcessing feature should be true",spf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING));
            
        }catch(Exception e){
            fail("Exception " + e.getMessage());
        } 
    }
    
    /* This method sets system property for maxOccurLimit=2 and secure process 
     * feature is off. Given doument contains more than 2 elements and hence 
     * an error should be reported.
     */
    public void testSystemMaxOccurLimitWithoutSecureProcessing()
    {
        try{
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,false);
            spf.setValidating(true);
            System.setProperty("maxOccurLimit","2");
            // Set the properties for Schema Validation
            String SCHEMA_LANG ="http://java.sun.com/xml/jaxp/properties/schemaLanguage";
            String SCHEMA_TYPE="http://www.w3.org/2001/XMLSchema"; 
            //Get the Schema location as a File object
            File schemaFile=new File(this.getClass().getResource("toys.xsd").toURI());
            //Get the parser
            SAXParser parser = spf.newSAXParser();
            parser.setProperty(SCHEMA_LANG, SCHEMA_TYPE);
            parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource",schemaFile);
            
            InputStream is = this.getClass().getResourceAsStream("toys.xml");
            MyErrorHandler eh = new MyErrorHandler();
            parser.parse(is,eh);
            assertFalse("Not Expected Error ",eh.errorOccured);
            System.setProperty("maxOccurLimit","");
        }catch(Exception e){
            fail("Exception occured: " + e.getMessage());
        } 
    }
    
    /* This method sets system property for maxOccurLimit=2 and secure process 
     * feature is ON. Given doument contains more than 2 elements and hence 
     * an error should be reported.
     *
     * THIS RESTRICTION HAS BEEN LIFTED AFTER THE IMPLEMENTATION OF A 
     * CONSTANT SPACE ALGORITHM TO VALIDATE THESE TYPES OF SCHEMAS. FOR
     * NOW, WE ARE COMMENTING OUT THIS UNIT TEST.
     *
    public void testSystemMaxOccurLimitWithSecureProcessing()
    {
        try{
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setValidating(true);
            System.setProperty("maxOccurLimit","2");
            // Set the properties for Schema Validation
            String SCHEMA_LANG ="http://java.sun.com/xml/jaxp/properties/schemaLanguage";
            String SCHEMA_TYPE="http://www.w3.org/2001/XMLSchema"; 
            //Get the Schema location as a File object
            File schemaFile=new File(this.getClass().getResource("toys.xsd").toURI());
            //Get the parser
            SAXParser parser = spf.newSAXParser();
            parser.setProperty(SCHEMA_LANG, SCHEMA_TYPE);
            parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource",schemaFile);
            
            InputStream is = this.getClass().getResourceAsStream("toys.xml");
            MyErrorHandler eh = new MyErrorHandler();
            parser.parse(is,eh);
            assertTrue("Expected Error as maxOccurLimit is exceeded",eh.errorOccured);
            System.setProperty("maxOccurLimit","");
        }catch(Exception e){
            fail("Exception occured: " + e.getMessage());
        } 
    }
     */
       
     /* This test will take longer time to execute( abt 120sec).
     * This method tries to validate a document. This document contains an 
     * element whose maxOccur is '3002'. Since secure processing feature is off,
     * document should be parsed without any errors.
     */
    public void testValidMaxOccurLimitWithOutSecureProcessing()
    {
        try{
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,false);
            spf.setValidating(true);
            // Set the properties for Schema Validation
            String SCHEMA_LANG ="http://java.sun.com/xml/jaxp/properties/schemaLanguage";
            String SCHEMA_TYPE="http://www.w3.org/2001/XMLSchema"; 
            //Get the Schema location as a File object
            File schemaFile=new File(this.getClass().getResource("toys3002.xsd").toURI());
            //Get the parser
            SAXParser parser = spf.newSAXParser();
            parser.setProperty(SCHEMA_LANG, SCHEMA_TYPE);
            parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource",schemaFile);
            
            InputStream is = this.getClass().getResourceAsStream("toys.xml");
            MyErrorHandler eh = new MyErrorHandler();
            parser.parse(is,eh);
            assertFalse("Expected Error as maxOccurLimit is exceeded",eh.errorOccured);
            
        }catch(Exception e){
            fail("Exception occured: " + e.getMessage());
        } 
    }
    
    /* System property is set to 2. Given XML document has more than 2 entity references.
     * Parsing this document in non-secure mode, should *not* report an error.
     */
    public void testSystemEntityExpansionLimitWithOutSecureProcessing()
    {
        try {
            System.setProperty("entityExpansionLimit","2");
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,false);
            dbf.setValidating(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity.xml"));
            // expected sucess
        } catch(SAXParseException e) {
            fail("SAXParseException not expected, secure processing is false: "
                    + e.toString());
        } catch(Exception e) {
            fail("Exception not expected: " + e.toString());
        } finally {
            System.setProperty("entityExpansionLimit","");
        }
    }
    
    /* System property is set to 2. Given XML document has more than 2 entity references.
     * Parsing this document in secure mode, should report an error.
     */
    public void testSystemEntityExpansionLimitWithSecureProcessing()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(true);
            System.setProperty("entityExpansionLimit","2");
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity.xml"));
            fail("SAXParserException is expected, as given XML document contains more 2 entity references");
            
        }catch(SAXParseException e){
            System.out.println(e.getMessage());
        }catch(Exception e){
            fail("Exception " + e.getMessage());
        }finally{
            System.setProperty("entityExpansionLimit","");
        }
    }
    
    /* Given XML document has more than 64000 entity references.
     * Parsing this document in secure mode, should report an error.
     */
    public void testEntityExpansionLimitWithSecureProcessing()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity64K.xml"));
            fail("SAXParserException is expected, as given XML document contains more 2 entity references");
            
        }catch(SAXParseException e){
            System.out.println(e.getMessage());
        }catch(Exception e){
            fail("Exception " + e.getMessage());
        }finally{
            System.setProperty("entityExpansionLimit","");
        }
    }
    
    /* Given XML document has more than 64000 entity references.
     * Parsing this document in non-secure mode, should not report any error.
     */
    public void testEntityExpansionLimitWithOutSecureProcessing()
    {
        try{
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,false);
            dbf.setValidating(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity64K.xml"));
                        
        }catch(SAXParseException e){
            fail("Exception "+e.getMessage());
        }catch(Exception e){
            fail("Exception " + e.getMessage());
        }finally{
            System.setProperty("entityExpansionLimit","");
        }
    }
}
