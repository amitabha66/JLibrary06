/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */

/*
 * $Id: DomUtilTester.java,v 1.1 2006/08/07 20:07:39 lindstro Exp $
 * %W% %E%
 *
 * Copyright 2006 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.stream.XMLStreamWriterTest;


import javax.xml.stream.XMLStreamWriterTest.DOMUtil;
import junit.framework.TestCase;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.URL;

import junit.textui.TestRunner;

/**
 * This test case was initiated by CR 6454111 (Test case fails and exception generated
 * at service when we enable Message logging at service side.)
 *
 * @author Rama Pulavarthi
 * @author Ana Lindstrom-Tamer
 */

public class DomUtilTester extends TestCase {

    private XMLOutputFactory staxOut;
    final File folder = new File(System.getProperty("tempdir") + "/classes/soapmessages");
    private static final String INPUT_FILE1 = "message_12.xml";
    
    public static void main(String[] args) {
    	TestRunner.run(DomUtilTester.class);
    }
     


    public void setup() {
        this.staxOut = XMLOutputFactory.newInstance();
        staxOut.setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES, true);    
    }


    public void testSOAPEnvelope1() throws Exception {
        setup();
        
        File f = new File(this.getClass().getResource(INPUT_FILE1).getFile());
        System.out.println("***********"+ f.getName() + "***********");
        DOMSource src = makeDomSource(f);
        Node node = src.getNode();
        XMLStreamWriter writer = staxOut.createXMLStreamWriter(new PrintStream(System.out));
        DOMUtil.serializeNode((Element) node.getFirstChild(), writer);
        writer.close();
        assert(true);
        System.out.println("*****************************************");

    }



    public static DOMSource makeDomSource(File f) throws Exception {
        InputStream is = new FileInputStream(f);
        DOMSource domSource = new DOMSource(createDOMNode(is));
        return domSource;
    }

    public static void printNode(Node node) {
        DOMSource source = new DOMSource(node);
        String msgString = null;
        try {
            Transformer xFormer = TransformerFactory.newInstance().newTransformer();
            xFormer.setOutputProperty("omit-xml-declaration", "yes");
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            Result result = new StreamResult(outStream);
            xFormer.transform(source, result);
            outStream.writeTo(System.out);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static Node createDOMNode(InputStream inputStream) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        dbf.setValidating(false);
        try {
            DocumentBuilder builder = dbf.newDocumentBuilder();
            try {
                return builder.parse(inputStream);
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (ParserConfigurationException pce) {
            IllegalArgumentException iae = new IllegalArgumentException(pce.getMessage());
            iae.initCause(pce);
            throw iae;
        }
        return null;
    }


}
