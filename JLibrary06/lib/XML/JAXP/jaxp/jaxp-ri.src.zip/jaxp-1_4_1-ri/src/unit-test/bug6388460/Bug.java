/*
 * Bug.java
 *
 * Created on March 29, 2006, 7:46 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6388460;

/**
 *
 * @author Sunitha Reddy
 */

import java.net.*;
import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.stream.*;
import org.xml.sax.InputSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
 
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void test(){
        try{
        
        Source source = new StreamSource(this.getClass().getResourceAsStream("Hello.wsdl"), 
                this.getClass().getResource("Hello.wsdl").toExternalForm());
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer();
        transformer.transform(source, new StreamResult(baos));
        System.out.println(new String(baos.toByteArray()));
        ByteArrayInputStream bis = new ByteArrayInputStream(baos.toByteArray());
        InputSource inSource = new InputSource(bis);
        
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        xmlInputFactory.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE);
        XMLStreamReader reader = xmlInputFactory.createXMLStreamReader(
                inSource.getSystemId(), inSource.getByteStream());
        while(reader.hasNext()) {
            reader.next();
        }
        }catch(Exception ex){
            ex.printStackTrace(System.err);
            fail("Exception occured: "+ex.getMessage());
        }
    }
}
