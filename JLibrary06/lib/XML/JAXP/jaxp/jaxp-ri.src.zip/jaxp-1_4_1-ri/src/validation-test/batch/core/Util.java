/*
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package batch.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;

/**
 * Misc utilitiy methods.
 */
public class Util
{
    
    /** Recursively deletes all the files/folders inside a folder. */
    public static void recursiveDelete( File f ) {
        if(f.isDirectory()) {
            String[] files = f.list();
            for( int i=0; i<files.length; i++ )
                recursiveDelete( new File(f,files[i]) );
        } else {
            f.delete();
        }
    }
    
    /**
     * Reads an input stream and copies them into System.out.
     */
    private static class ProcessReader implements Runnable {
        ProcessReader( InputStream is ) {
            reader = new BufferedReader(new InputStreamReader(is));
        }
        
        private final BufferedReader reader;
        
        public void run() {
            try {
                while(true) {
                    String s = reader.readLine();
                    if(s==null) {
                        reader.close();
                        return;
                    }
                    System.out.println(s);
                }
            } catch( Exception e ) {
                e.printStackTrace();
                throw new Error();
            }
        }
    }
    
    
    private static boolean warned = false;
    
    /**
     * Compiles source files in the specified directory
     * and returns a ClassLoader that can be used to load classes from there.
     * 
     * @return
     *      if the compilation fails, return null.
     */
    public static ClassLoader compile( File dir ) throws IOException, InterruptedException, InvocationTargetException {
        ArrayList args = new ArrayList();
        args.add("-d");
        args.add(dir.getPath());
        args.add("-g");
        Util.appendJavaFiles(dir,args);
        
        try {
            // try to load javac in the same VM.
            // use reflection just to make it easy to compile this file
            Method m = Class.forName("com.sun.tools.javac.Main").getMethod("compile",
                new Class[]{String[].class});
            m.invoke(null,new Object[]{args.toArray(new String[0])});
        } catch( Throwable e ) {
            // if it fails, try to run javac as a separate process
            
            if(!warned) {
                System.out.println(
                    "************************************************\n"+
                    "Unable to run javac in the same VM. Make sure you have it in your classpath.\n"+
                    "************************************************\n" );
                e.printStackTrace(System.out);
                System.out.println(
                    "************************************************");
            }
            warned = true;
                    
            
            StringBuffer buf = new StringBuffer();
            // add system classpaths for reference
            buf.append("javac");
            buf.append(" -classpath ");
            buf.append('\"');
            buf.append(System.getProperty("java.class.path"));
            buf.append("\" ");
            for( int i=0; i<args.size(); i++ ) {
                buf.append(args.get(i));
                buf.append(' ');
            }
                
    //      this helps debugging, sometimes.
    //      System.err.println(buf.toString());
            if( execProcess(Runtime.getRuntime().exec(buf.toString()))!=0 )
                return null;    // fail to compile
        }
        /* catch( IllegalAccessException e ) {
            // no way to handle this error.
            throw new IllegalAccessError(e.toString());
        } catch( NoSuchMethodException e ) {
            throw new NoSuchMethodError(e.toString());
        }*/
            
        return createClassLoader(dir);
    }
    
    /**
     * Waits for the given process to complete, and return its exit code.
     */
    public static int execProcess( Process proc ) throws IOException, InterruptedException {
        // is this a correct handling?
        proc.getOutputStream().close();
        new Thread(new ProcessReader(proc.getInputStream())).start();
        new Thread(new ProcessReader(proc.getErrorStream())).start();
            
        return proc.waitFor();
    }
     
    /**
     * Returns a class loader that loads classes from the specified directory.
     */
    public static ClassLoader createClassLoader( File dir ) throws IOException {
        return URLClassLoader.newInstance(new URL[]{dir.getCanonicalFile().toURL()});
    }
    
    /**
     * Collects Java files recursively from the specified directory
     */
    public static void appendJavaFiles( File dir, ArrayList buf ) {
        String[] files = dir.list();
        for( int i=0; i<files.length; i++ ) {
            File f = new File(dir,files[i]);
        
            if( files[i].endsWith(".java") ) {
                buf.add(f.getPath());
            }
            if( f.isDirectory() )
                appendJavaFiles(f,buf);
        }
    }
    
        
    /** Parses an XML file into a dom4j tree. */
    public static Document loadXML( File file ) throws Exception {
        return new SAXReader(false).read(file);
    }
}
