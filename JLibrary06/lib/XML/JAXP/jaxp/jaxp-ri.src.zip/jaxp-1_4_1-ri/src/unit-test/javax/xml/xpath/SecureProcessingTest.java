/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: SecureProcessingTest.java,v 1.1 2007/01/29 05:52:12 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.xpath;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.List;
import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;

import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * <p>Test SECURE_PROCESSING.</p>
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */
public class SecureProcessingTest extends TestCase {

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(SecureProcessingTest.class);
    }

    /**
     * <p>Test stylesheet that uses a Java extension with SECURE_PROCESSING
     * turned on.</p>
     *
     */
    public final void testSecureProcessing() {

        final String XPATH_EXPRESSION = "ext:helloWorld()";

        // the xml source
        InputStream  xmlStream = this.getClass().getResourceAsStream("SecureProcessingTest.xml");

        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = null;
        Document document = null;

        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.parse(xmlStream);
        } catch (ParserConfigurationException parserConfigurationException) {
            parserConfigurationException.printStackTrace();
            fail(parserConfigurationException.toString());
        } catch (SAXException saxException) {
            saxException.printStackTrace();
            fail(saxException.toString());
        } catch (IOException ioException) {
            ioException.printStackTrace();
            fail(ioException.toString());
        }

        // the XPath
        XPathFactory xPathFactory = null;
        XPath xPath = null;
        String xPathResult = null;

        // SECURE_PROCESSING == false
        // evaluate an expression with a user defined function with a non-secure XPath
        // expect success
        try {
            xPathFactory = xPathFactory.newInstance();
            xPathFactory.setXPathFunctionResolver(new MyXPathFunctionResolver());
            xPathFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);

            xPath = xPathFactory.newXPath();
            xPath.setNamespaceContext(new MyNamespaceContext());

            xPathResult = xPath.evaluate(XPATH_EXPRESSION, document);
        } catch (XPathFactoryConfigurationException xPathFactoryConfigurationException) {
            xPathFactoryConfigurationException.printStackTrace();
            fail(xPathFactoryConfigurationException.toString());
        } catch (XPathExpressionException xPathExpressionException) {
            xPathExpressionException.printStackTrace();
            fail(xPathExpressionException.toString());
        }

        // expected success
        System.out.println(
                "XPath result (SECURE_PROCESSING == false) = \""
                + xPathResult
                + "\"");

        // now try with SECURE_PROCESSING == true
        // evaluate an expression with a user defined function with a secure XPath
        // expect Exception
        boolean securityException = false;
        try {
            xPathFactory = xPathFactory.newInstance();
            xPathFactory.setXPathFunctionResolver(new MyXPathFunctionResolver());
            xPathFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            xPath = xPathFactory.newXPath();
            xPath.setNamespaceContext(new MyNamespaceContext());
            
            xPathResult = xPath.evaluate(XPATH_EXPRESSION, document);
        } catch (XPathFactoryConfigurationException xPathFactoryConfigurationException) {
            xPathFactoryConfigurationException.printStackTrace();
            fail(xPathFactoryConfigurationException.toString());
        } catch (XPathFunctionException xPathFunctionException) {
            // expected security exception
            securityException = true;
            xPathFunctionException.printStackTrace(System.out);
        } catch (XPathExpressionException xPathExpressionException) {
            xPathExpressionException.printStackTrace();
            fail(xPathExpressionException.toString());
        }

        // expected Exception
        if (!securityException) {
            fail(
                    "XPath result (SECURE_PROCESSING == true) = \""
                    + xPathResult
                    + "\"");
        }
    }

    public class MyXPathFunctionResolver
            implements XPathFunctionResolver {
        
         public XPathFunction 	resolveFunction(QName functionName, int arity) {
             
             // not a real ewsolver, always return a default XPathFunction
             return new MyXPathFunction();             
         }
    }
    
    public class MyXPathFunction
            implements XPathFunction {
        
        public Object evaluate(List list) throws XPathFunctionException {
            
            return "Hello World";
        }
    }
    
    public class MyNamespaceContext implements NamespaceContext {
        
          public String getNamespaceURI(String prefix) {
              if (prefix == null) {
                throw new IllegalArgumentException("The prefix cannot be null.");
              }

              if (prefix.equals("ext")) {
                  return "http://ext.com";
              } else {
                  return null;
              }
          }

          public String getPrefix(String namespace) {
              
              if (namespace == null) {
                throw new IllegalArgumentException("The namespace uri cannot be null.");
              }
              
              if (namespace.equals("http://ext.com")) {
                return "ext";
              } else {
                return null;
              }
          }

          public Iterator getPrefixes(String namespace) {
              return null;
          }
      }
}
