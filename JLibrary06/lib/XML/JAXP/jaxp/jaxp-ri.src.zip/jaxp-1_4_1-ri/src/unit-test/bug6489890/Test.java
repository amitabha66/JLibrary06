
package bug6489890;

import javax.xml.stream.XMLEventReader;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * An XMLEventReader should start in an undefined state, and
 * move to a START_DOCUMENT state. A call to peek() should
 * return the same event as a call to nextEvent(). It follows
 * that the first call to peek() should return START_DOCUMENT
 * as explained in CR 6489890.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {
    
    public static void main(String [] args){
        TestRunner.run(Test.class);
    }
    
    public void test0() {
        try {   
            XMLInputFactory xif = XMLInputFactory.newInstance();
            
            XMLStreamReader xsr = xif.createXMLStreamReader(
                    getClass().getResource("sgml.xml").toString(),
                    getClass().getResourceAsStream("sgml.xml"));
            
            XMLEventReader xer = xif.createXMLEventReader(xsr);
            
            assertTrue(xer.peek().getEventType() == XMLEvent.START_DOCUMENT);
            assertTrue(xer.peek() == xer.nextEvent());
            xsr.close();
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }    
    
    public void test1() {
        try {   
            XMLInputFactory xif = XMLInputFactory.newInstance();
            
            XMLStreamReader xsr = xif.createXMLStreamReader(
                    getClass().getResource("sgml.xml").toString(),
                    getClass().getResourceAsStream("sgml.xml"));
            
            XMLEventReader xer = xif.createXMLEventReader(xsr);
            
            assertTrue(xer.nextEvent().getEventType() == XMLEvent.START_DOCUMENT);
            xsr.close();
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }    
    
}
