/*
 * Bug.java
 *
 * Created on November 11, 2005, 12:05 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6348377;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.regex.Pattern;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy
 */
public class Bug extends TestCase{
    
    String fileName = "TypeMapper.xml";
    final String REGEX_STR = "textRegularExpression";
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
 
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testWithOneThread(){
        try{
            InputStream fis = this.getClass().getResourceAsStream(fileName);
            RunnableTwo r2 = new RunnableTwo(fis);
            Thread t2 = new Thread(r2);
            t2.start();
            t2.join();
        }catch ( Exception ex ) {
            ex.printStackTrace(System.err);
            fail("Exception occured: "+ex.getMessage());
        }
    }
    
    /* This test takes longer time to execute.
     */
    public void testWithTwoThreads(){
        try{
            PipedOutputStream pos = new PipedOutputStream();
            PipedInputStream pis = new PipedInputStream(pos); 
            RunnableOne r1 = new RunnableOne(fileName, pos);
            RunnableTwo r2 = new RunnableTwo(pis);
            Thread t1 = new Thread(r1);
            Thread t2 = new Thread(r2);
            t1.start();
            t2.start();
            t2.join();
        }catch ( Exception ex ) {
            ex.printStackTrace(System.err);
            fail("Exception occured: "+ex.getMessage());
        }
    }
    
    public class RunnableOne implements Runnable {
      private OutputStream os;
      InputStream fis;
      public RunnableOne(String fileName, OutputStream os) {
         try {
            fis = this.getClass().getResourceAsStream(fileName);
         } catch ( Exception e ) {
            e.printStackTrace(System.err);
         }
         this.os = os;
      }
      
      public void run() {
         try {
            int c;
            while ( (c = fis.read()) != -1 )
                os.write(c);
            fis.close();
            os.flush();
            os.close();
					
         } catch ( Exception e ) {
            e.printStackTrace(System.err);
         }
      }
   }
   
   public class RunnableTwo implements Runnable {
      private InputStream is;
      public RunnableTwo(InputStream is) {
         this.is = is;
      }
      
      public void run() {
        int cnt = 0;
        String regex = null;
         try {
            
            XMLInputFactory staxFactory = XMLInputFactory.newInstance(); 
            staxFactory.setProperty(XMLInputFactory.IS_COALESCING , Boolean.TRUE);
            Package pkg = staxFactory.getClass().getPackage();
            XMLStreamReader staxReader = staxFactory.createXMLStreamReader(is);
					
            while ( staxReader.hasNext()  ) {
               int event = staxReader.next();
               if ( event == XMLStreamConstants.END_DOCUMENT )
                  break; 
               else if ( event == XMLStreamConstants.START_ELEMENT ) {
                  String localName = staxReader.getLocalName();
                  if ( localName.equals(REGEX_STR) ) {
                     event = staxReader.next(); 
                     assertTrue("expected XMLStreamConstants.CHARACTERS event", event == XMLStreamConstants.CHARACTERS);
                     regex = staxReader.getText();
                     ++cnt;
                     Pattern pattern = Pattern.compile(regex);
                  }
               }
            }
         } catch ( Exception ex ) {
            System.out.println("regex: "+regex);
            fail("Exception: "+ex.getMessage());
            ex.printStackTrace(System.err);
         }    
      }
   }   
}
