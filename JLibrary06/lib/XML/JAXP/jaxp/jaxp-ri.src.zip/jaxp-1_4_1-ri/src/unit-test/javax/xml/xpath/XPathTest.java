/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: XPathTest.java,v 1.2 2006/08/10 22:51:31 lindstro Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package javax.xml.xpath;

import javax.xml.namespace.NamespaceContext;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Test XPath and NamespaceContext support.
 *
 * Motivated by CR 6376058 JAXP is missing an implementation of
 * NamespaceContext which is required by XPath and other core func.
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */
public class XPathTest extends TestCase {

    /**
     * Creates a new instance of XPathTest.
     *
     * @param name Name of test.
     */
    public XPathTest(String name) {
         super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(XPathTest.class);
    }

    /**
     * Test XPath NamespaceContext support.
     *
     * Test should pass.
     */
    public void testNamespaceContext() {

        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();

        NamespaceContext namespaceContext = xPath.getNamespaceContext();


// FOR NOW: comment this out until we decide what the correct behavior is
//        if (namespaceContext == null) {
//            fail("namespaceContext is null");
//        }
    }
}
