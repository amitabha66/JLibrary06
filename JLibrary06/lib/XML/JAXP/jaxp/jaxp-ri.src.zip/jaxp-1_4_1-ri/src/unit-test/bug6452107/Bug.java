
package bug6452107;

import java.io.*;
import javax.xml.stream.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    /**
     * Ensure that charset aliases are checked. The encoding ISO-8859-1 is 
     * returned as ISO8859_1 by the underlying writer. Thus, if alias are
     * not inspected, this test throws an exception.
     */
    public void test() {
        final String ENCODING = "ISO-8859-1";
    
        try {
            OutputStream out = new ByteArrayOutputStream();
            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter writer = factory.createXMLStreamWriter(out, ENCODING);
            writer.writeStartDocument(ENCODING, "1.0");
        }
        catch (XMLStreamException e) {
            fail("Exception occured: " + e.getMessage());
        }
    }
}
