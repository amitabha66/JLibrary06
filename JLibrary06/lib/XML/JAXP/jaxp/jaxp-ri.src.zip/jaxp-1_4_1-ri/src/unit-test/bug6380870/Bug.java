/*
 * Bug.java
 *
 * Created on February 6, 2006, 11:53 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6380870;

/**
 *
 * @author Sunitha Reddy
 */
import javax.xml.stream.*;
import java.io.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase{
    
    private static String INPUT_FILE = "basic-form.vxml";
    /** Creates a new instance of Bug */
    public Bug(String name) {
         super(name);
    }   
    
    public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
    
    public void testStreamReader(){
        try {
		XMLInputFactory xif = XMLInputFactory.newInstance();
		XMLStreamReader reader = xif.createXMLStreamReader(this.getClass().getResource(INPUT_FILE).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE));
		while (reader.hasNext())
			reader.next();

	} catch (Exception e) {
      		e.printStackTrace();
                fail("Exception occured: "+e.getMessage());
    	}
    }
}
