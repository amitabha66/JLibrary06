package bug6449797;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.validation.SchemaFactory;

/**
 * @author Kohsuke Kawaguchi
 */
public class Bug extends TestCase {

    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    public void test() throws SAXException {
        // this shouldn't fail
        SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI).newSchema(
            getClass().getResource("test.xsd"));
    }
}
