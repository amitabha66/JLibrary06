/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:24:45 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4992793;

import java.io.StringReader;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.xml.sax.InputSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    protected static SAXParser createParser() throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        spf.setValidating(true);
        SAXParser parser = spf.newSAXParser();
        parser.setProperty(
                "http://java.sun.com/xml/jaxp/properties/schemaLanguage",
        "http://www.w3.org/2001/XMLSchema");

        return parser;
    }

    // test for XPath.evaluate(java.lang.String expression, InputSource source) - default returnType is String
    // source is null , should throw NPE
    public void testXPath24() throws Exception {
        try {
            createXPath().evaluate(null, new InputSource(new StringReader("<root/>")));
            fail();
        } catch( NullPointerException e ) {
            ; // as expected
        }
    }

    // test for XPath.evaluate(java.lang.String expression, InputSource source, QName returnType)
    //  source is null , should throw NPE
    public void testXPath29() throws Exception {
        try {
            createXPath().evaluate(null, new InputSource(new StringReader("<root/>")), XPathConstants.STRING);
            fail();
        } catch( NullPointerException e ) {
            ; // as expected
        }
    }

    private XPath createXPath() throws XPathFactoryConfigurationException {
        XPathFactory xpathFactory = XPathFactory.newInstance();
        assertNotNull(xpathFactory);
        XPath xpath = xpathFactory.newXPath();
        assertNotNull(xpath);
        return xpath;
    }
}