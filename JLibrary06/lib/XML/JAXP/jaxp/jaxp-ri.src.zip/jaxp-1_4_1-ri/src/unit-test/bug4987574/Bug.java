/*
 * @(#)$Id: Bug.java,v 1.1 2005/06/10 04:24:47 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package bug4987574;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import javax.xml.validation.SchemaFactory;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {
    
    public Bug(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    public void test1() throws Exception {
        SchemaFactory schemaFactory =
            SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        File tmpFile = File.createTempFile("jaxpri","bug");
        tmpFile.deleteOnExit();
        {
            PrintWriter pw = new PrintWriter(new FileWriter(tmpFile));
            pw.println("<schema xmlns='http://www.w3.org/2001/XMLSchema'/>");
            pw.close();
        }
        
        schemaFactory.newSchema(tmpFile);
    }
}