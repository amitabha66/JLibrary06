package javax.xml.stream.XMLStreamWriterTest;

import junit.framework.TestCase;

import javax.xml.stream.XMLOutputFactory;

/**
 * Base class for {@link XMLStreamWriter} tests
 * @author Kohsuke Kawaguchi
 */
abstract class Base extends TestCase {
    XMLOutputFactory xof = XMLOutputFactory.newInstance();
}
