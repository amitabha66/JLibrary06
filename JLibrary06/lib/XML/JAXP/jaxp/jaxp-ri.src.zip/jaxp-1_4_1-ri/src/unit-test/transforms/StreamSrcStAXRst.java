
package transforms;

import java.util.*;
import java.io.*;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Attr;
import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.FactoryConfigurationError; 
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stax.StAXResult;

import javax.xml.stream.*;
import javax.xml.stream.events.* ;
import javax.xml.namespace.QName;

/**
* Padmaja Vedula
*/

public class StreamSrcStAXRst {
    
    static String fileName ;
    public static void main(String[] args){
	if(args.length!=3){
 		System.out.println("Usage: java "+StreamSrcStAXRst.class.getName()
		+ " <XML that needs to be transformed>"
		+ " <XSLT file>" 
		+ " <Output file>");
		System.exit(1);
	}
        try{
            transform(args);
        }catch(Exception e){
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void transform(String[] args) throws Exception{
        fileName = args[2].toString();
        FileInputStream xmlIn=new FileInputStream(args[0]);
        FileInputStream xsltIn=new FileInputStream(args[1]);
        FileOutputStream out=new FileOutputStream(args[2]);
        transform(xmlIn, xsltIn, out);
    }

    public static void transform(InputStream xmlIn, InputStream xsltIn, OutputStream out) throws Exception{
        javax.xml.transform.Source xmlSource =
                new javax.xml.transform.stream.StreamSource(xmlIn);
	javax.xml.transform.Result xmlResult = new javax.xml.transform.stax.StAXResult(XMLOutputFactory.newInstance().createXMLStreamWriter(new FileWriter(fileName)));


        javax.xml.transform.Source xsltSource =
                new javax.xml.transform.stream.StreamSource(xsltIn);
        javax.xml.transform.Source source =
                new javax.xml.transform.stream.StreamSource(xmlIn);
 
        // create an instance of TransformerFactory
        javax.xml.transform.TransformerFactory transFact =
                javax.xml.transform.TransformerFactory.newInstance(  );
        transFact.setAttribute("debug", new String("true"));
        transFact.setAttribute("translet-name", new String("suresh"));
        transFact.setAttribute("generate-translet", new String("true"));
        transFact.setAttribute("jar-name", new String("transletjar"));
        

        javax.xml.transform.Transformer trans =
                transFact.newTransformer(xsltSource);
 
        trans.transform(source, xmlResult);
    }
    
    
    private static XMLEventReader getXMLEventReader(String filename){
    
    	XMLInputFactory xmlif = null ;
        XMLEventReader xmlr = null;
        try{
            xmlif = XMLInputFactory.newInstance();
            xmlif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,Boolean.FALSE);
            xmlif.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE , Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_COALESCING , Boolean.TRUE);
                        
            FileInputStream fis = new FileInputStream(filename);
            xmlr =  xmlif.createXMLEventReader(filename, fis);            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return xmlr;
    }
}
