/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jaxp.dev.java.net/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jaxp.dev.java.net/CDDLv1.0.html
 * If applicable add the following below this CDDL HEADER
 * with the fields enclosed by brackets "[]" replaced with
 * your own identifying information: Portions Copyright
 * [year] [name of copyright owner]
 */

/*
 * $Id: LSParserTest.java,v 1.1 2006/08/02 05:26:31 jeffsuttor Exp $
 * %W% %E%
 *
 * Copyright 2005 Sun Microsystems, Inc. All Rights Reserved.
 */

package org.w3c.dom.ls;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMError;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSParser;
import org.w3c.dom.ls.LSResourceResolver;

/**
 * Test LSParser's DOMConfiguration for supported properties.
 *
 * Motivated by CR 4963567 DOMConfiguration:
 *   some required LSParser properties are not supported.
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */
public class LSParserTest extends TestCase {

    /**
     * Creates a new instance of LSParserTest.
     *
     * @param name Name of test.
     */
    public LSParserTest(String name) {
         super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(LSParserTest.class);
    }

    /**
     * Test LSParser's DOMConfiguration for supported properties.
     *
     * Test should pass.
     */
    public void testDOMConfiguration() {

        final DOMErrorHandler handler = new DOMErrorHandler() {
            public boolean handleError(final DOMError error) {
                return false;
            }
        };

        final LSResourceResolver resolver = new LSResourceResolver() {
            public LSInput resolveResource(final String type,
                            final String namespaceURI,
                            final String publicId,
                            final String systemId,
                            final String baseURI) {
                return null;
            }
        };

        /**
         * list of all required parameter/value pairs for
         * LSParser configuration
         */
        final Object [][] values = {
            // parameter, value
            {"canonical-form",                 Boolean.FALSE},
            {"cdata-sections",                 Boolean.FALSE},
            {"cdata-sections",                 Boolean.TRUE},
            {"check-character-normalization",  Boolean.FALSE},
            {"comments",                       Boolean.FALSE},
            {"comments",                       Boolean.TRUE},
            {"datatype-normalization",         Boolean.FALSE},
            {"entities",                       Boolean.FALSE},
            {"entities",                       Boolean.TRUE},
            {"error-handler",                  handler},
            {"infoset",                        Boolean.TRUE},
            {"namespaces",                     Boolean.TRUE},
            {"namespace-declarations",         Boolean.TRUE},
            {"namespace-declarations",         Boolean.FALSE},
            {"normalize-characters",           Boolean.FALSE},
            {"split-cdata-sections",           Boolean.TRUE},
            {"split-cdata-sections",           Boolean.FALSE},
            {"validate",                       Boolean.FALSE},
            {"validate-if-schema",             Boolean.FALSE},
            {"well-formed",                    Boolean.TRUE},
            {"element-content-whitespace",     Boolean.TRUE},

            {"charset-overrides-xml-encoding", Boolean.TRUE},
            {"charset-overrides-xml-encoding", Boolean.FALSE},
            {"disallow-doctype",               Boolean.FALSE},
            {"ignore-unknown-character-denormalizations",
                                               Boolean.TRUE},
            {"resource-resolver",              resolver},
            {"resource-resolver",              null},
            {"supported-media-types-only",     Boolean.FALSE},
        };

        DOMImplementation domImpl = null;
        try {
            domImpl = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .getDOMImplementation();
        } catch (ParserConfigurationException parserConfigurationException) {
            parserConfigurationException.printStackTrace();
            fail(parserConfigurationException.toString());
        }

        DOMImplementationLS lsImpl =
                (DOMImplementationLS) domImpl.getFeature("LS", "3.0");

        LSParser lsParser = lsImpl.createLSParser(
             DOMImplementationLS.MODE_SYNCHRONOUS,
             null);

        DOMConfiguration config = lsParser.getDomConfig();

        for (int i = values.length; --i >= 0;) {
            Object val = values[i][1];
            String param = (String) values[i][0];
            try {
                config.setParameter(param, val);
                Object returned = config.getParameter(param);
                assertEquals("'" + param + "' is set to "
                        + returned + ", but expected " + val,
                        val,
                        returned);
                System.out.println("set '" + param + "'"
                        + " to '" + val + "'"
                        + " and returned '" + returned + "'");
            } catch (DOMException e) {
                String settings = "setting '" + param + "' to " + val;
                System.err.println(settings);
                e.printStackTrace();
                fail(settings + ", " + e.toString());
            }
        }
    }
}
