/*
 * Bug.java
 *
 * Created on December 14, 2005, 6:46 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6355326;

import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.w3c.dom.ls.*;
import org.xml.sax.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy
 */

public class Bug extends TestCase{
    
    DOMImplementationLS implLS = null;  
    String encodingXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><encodingXML/>";
    
    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }
    
     public static void main(String[] args) {
    	TestRunner.run(Bug.class);
    }
     
     protected void setUp(){
        Document doc = null;
        DocumentBuilder parser = null;
        String xml1 = "<?xml version=\"1.0\"?><ROOT></ROOT>";
        try {
                parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
                e.printStackTrace();
        }
        StringBufferInputStream is = new StringBufferInputStream(xml1);
        try {
                doc = parser.parse(is);
        } catch (SAXException e) {
                e.printStackTrace();
        } catch (IOException e) {
                e.printStackTrace();
        }
        DOMImplementation impl = doc.getImplementation();
        implLS = (DOMImplementationLS) impl.getFeature("LS","3.0"); 
     }
     
     public void testExternalEncoding() {
        
         try{
            LSInput src = null;
            LSParser dp = null;

            src = createLSInputEncoding();
            dp = createLSParser();

            src.setEncoding("UTF-16");
            Document doc = dp.parse(src);
            assertTrue("XML document is not parsed correctly", "encodingXML".equals(doc.getDocumentElement().getNodeName()));
         
         } catch(Exception e){
             e.printStackTrace();
             fail("Exception occured: "+e.getMessage());
         }
     }
     
     private LSInput createLSInputEncoding(){
            LSInput src = implLS.createLSInput();
            assertFalse("Could not create LSInput from DOMImplementationLS", src==null);
            
            try {
                src.setByteStream(new ByteArrayInputStream(encodingXML.getBytes("UTF-16")));
            } catch(UnsupportedEncodingException e) {
                e.printStackTrace();
                fail("Exception occured: "+e.getMessage());
            }
            return src;
    }

    private LSParser createLSParser () {
            LSParser p = implLS.createLSParser(DOMImplementationLS.MODE_SYNCHRONOUS,"http://www.w3.org/2001/XMLSchema");
            assertFalse("Could not create Synchronous LSParser from DOMImplementationLS", p==null);
            return p;
    }
}
