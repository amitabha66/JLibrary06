/*
 * Test.java
 *
 * Created on February 20, 2007, 10:42 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6526547;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 * Unit test for CR 6526547.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {
    
    public static void main(String [] args){
        TestRunner.run(Test.class);
    }
    
    public Test() {
    }
    
    public void test()  {
        try {
            // parse an XML document into a DOM tree
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = dbf.newDocumentBuilder();
            assertFalse(parser.isNamespaceAware());
            Document document = parser.parse(getClass().getResourceAsStream("test.xml"));
            
            // create a SchemaFactory capable of understanding WXS schemas
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            
            // load a WXS schema, represented by a Schema instance
            Source schemaFile = new StreamSource(getClass().getResourceAsStream("test.xsd"));
            Schema schema = factory.newSchema(schemaFile);
            
            // create a Validator instance, which can be used to validate an instance document
            Validator validator = schema.newValidator();
            
            // validate the DOM tree
            try {
                validator.validate(new DOMSource(document));
            } catch (SAXException e) {
                e.printStackTrace();
                fail("Document is reported as invalid but it is not!");
            }
        } catch (Exception e) {
            fail("Unable to configure validator");
        }
    }
}