/*
 * SimpleJUnitTest.java
 * JUnit based test
 *
 * Created on February 3, 2004, 1:46 PM
 */

package javax.xml.stream.ProcessingInstruction;

import java.io.InputStream;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import junit.framework.*;
import junit.textui.TestRunner;

/**
 *
 * @author neeraj
 */
public class ProcessingInstructionTest extends TestCase {
    
    public ProcessingInstructionTest(java.lang.String testName) {
        super(testName);
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(ProcessingInstructionTest.class);
        return suite;
    }
    
    // Add test methods here, they have to start with 'test' name.
    // for example:
    // public void testHello() {}
    
    public void testPITargetAndData(){
        try{
            XMLInputFactory xif = XMLInputFactory.newInstance() ;
            String PITarget = "soffice" ;
            String PIData = "WebservicesArchitecture";
            String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<?" + PITarget + " " +  PIData + "?>" + "<foo></foo>" ;            
            //System.out.println("XML = " + xml) ;
            InputStream is = new java.io.ByteArrayInputStream(xml.getBytes());
            XMLStreamReader sr = xif.createXMLStreamReader(is) ;
            while(sr.hasNext()){
                int eventType = sr.next() ;
                if(eventType == XMLStreamConstants.PROCESSING_INSTRUCTION){
                    String target = sr.getPITarget() ;                    
                    String data = sr.getPIData();                                            
                    assertTrue(target.equals(PITarget) && data.equals(PIData)) ;
                }        
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    
    public static void main(String[] args) {
        TestRunner.run(ProcessingInstructionTest.class);
    }

}
