/*
 * XMLStreamWriterTest.java
 *
 * Created on November 9, 2005, 5:17 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6347190;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import java.io.StringWriter;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Neeraj Bajaj, Sun Microsystems, inc.
 */
public class XMLStreamWriterTest extends TestCase {
    
    public XMLStreamWriterTest(String testName) {
        super(testName);
    }
    
    public static void main(String args[]){
        TestRunner.run(XMLStreamWriterTest.class);
    }
    
    protected void setUp() throws Exception {
    }
    
    protected void tearDown() throws Exception {
    }
    
    
    
    /**
     * Test of main method, of class TestXMLStreamWriter.
     */
    public void testWriteComment() {
        try{
            String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><a:html href=\"http://java.sun.com\"><!--This is comment-->java.sun.com</a:html>";
            XMLOutputFactory f = XMLOutputFactory.newInstance();
            //f.setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES, Boolean.TRUE);
            StringWriter sw = new StringWriter();
            XMLStreamWriter writer = f.createXMLStreamWriter(sw);
            writer.writeStartDocument("UTF-8","1.0");
            writer.writeStartElement("a","html", "http://www.w3.org/TR/REC-html40");
            writer.writeAttribute("href" , "http://java.sun.com");
            writer.writeComment("This is comment");
            writer.writeCharacters("java.sun.com");
            writer.writeEndElement();
            writer.writeEndDocument();
            writer.flush();
            sw.flush();
            StringBuffer sb = sw.getBuffer();
            System.out.println("sb:" + sb.toString());
            assertTrue(sb.toString().equals(xml));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    
    
}
