/*
 * @(#)$Id: SchemaImpl.java,v 1.1 2005/06/10 04:23:41 jeffsuttor Exp $
 *
 * Copyright 2001 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */
package validator.jarv;

import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import javax.xml.validation.ValidatorHandler;

import org.iso_relax.verifier.VerifierConfigurationException;

import validator.*;

/**
 * 
 * 
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class SchemaImpl extends Schema {

    private final org.iso_relax.verifier.Schema schema;

    public SchemaImpl(org.iso_relax.verifier.Schema schema) {
        this.schema = schema;
    }

    public ValidatorHandler newValidatorHandler() {
        try {
            return new ValidatorHandlerImpl(schema);
        } catch (VerifierConfigurationException e) {
            // impossible
            e.printStackTrace();
            return null;
        }
    }
    
    public Validator newValidator() {
        return new ValidatorImpl(newValidatorHandler());
    }

}
