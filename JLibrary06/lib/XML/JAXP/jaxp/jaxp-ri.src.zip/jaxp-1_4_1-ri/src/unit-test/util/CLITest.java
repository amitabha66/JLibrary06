/*
 * CLITest.java
 *
 * Created on January 17, 2007, 9:25 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package util;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * This unit test shows how to access the now hidden CLI by
 * running a transform using command line arguments.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class CLITest extends TestCase {
    
    public static void main(String[] _) {
        TestRunner.run(CLITest.class);
    }
    
    public void testCLI() {
        try {
            String[] args = new String[] {
                "-XSLTC",
                "-XSL",
                getClass().getResource("tigertest.xsl").toString(),
                "-IN",
                getClass().getResource("tigertest-in.xml").toString(),
            };
            com.sun.org.apache.xalan.internal.xslt.Process._main(args);
        } 
        catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
